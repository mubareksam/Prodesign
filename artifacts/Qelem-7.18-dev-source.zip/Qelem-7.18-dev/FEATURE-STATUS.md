# Feature status — 7.18-dev

This is a working inventory of major gaps, not a promise of Procreate or Procreate Dreams parity. Qelem is independent and runs on Android. Apple-only hardware features are not applicable.

## Added in 7.18

- Three independent destructive current-cel adjustments: RGB Levels (black, white, gamma), approximate Vibrance and artistic Temperature & Tint. Each has reset, approximate original/adjusted preview, alpha preservation, hard-selection support and undo. No skin-tone detection or calibrated white balance; not non-destructive adjustment layers or exact Procreate parity. 4 MP affected bounds / estimated 64 MiB temporary buffers, plus overhead.
- Outline layer from raw active-cel alpha: square-distance outer dilation, adjustable colour, opacity and 1–32 px width, creates a new editable top layer on the current frame, undoable and exported normally. Ignores selection, layer opacity, blend and clipping; partly transparent edges can overlap, no vector/rounded outline. Limit 4 MP and estimated 64 MiB at 32 bytes per canvas pixel, plus artwork, history and device overhead. Both features need physical Android memory, touch and performance testing.

## Added in 7.17

- Colour Balance: independently adjust RGB-axis offsets for shadows, midtones and highlights on the current raster cel and hard selection. Includes downsampled before/after preview, range/all reset, alpha preservation and undo. Tonal weights overlap by luminance; brightness may shift. Destructive, not an editable adjustment layer; not identical to Procreate. Locked/hidden and empty layers are refused. Limit 4 MP affected bounds / estimated 64 MiB temporary buffers, plus existing artwork, history and device overhead. Physical Android performance and touch testing remain needed.

## Added in 7.16

- 71 original built-in brush presets (43 added), searchable and filterable by category, with fixed-angle elliptical nibs and Brush Studio controls. Existing custom profiles remain usable. These are variants of three simple stamp engines, not Procreate's proprietary brushes; stylus tilt, direction-following tip rotation, brush import/export and full brush-engine parity are absent.
- Eight deterministic original procedural canvas/paper overlays, added as an undoable editable raster layer, for the current frame or independent cels across all frames. Colour, strength and scale are adjustable. Layer initially uses Multiply; selection is ignored. Saved and exported as regular raster cels. Not authentic Canva assets or realistic brush-surface interaction. 8 MP and estimated 64 MiB new-buffer limits, plus existing content/history and overhead. Android device memory and touch testing remain needed.

## Added in 7.15

- Animation colour effects across a range of cels on the current layer, with ten alpha-preserving effects, start/end strength ramps, four easing presets, optional skipped-frame inclusion and an approximate before/after raw-cel preview. Blank cels and other layers are untouched; current hard selection clips the edit. One undo restores all changed cels. This is destructive, not an adjustment layer; timing is based on frame numbers, not holds. 4 MP affected area and estimated 64 MiB new-buffer limit, plus existing cels, undo and device overhead. Physical Android performance/touch testing remains needed.

- Storyboard export: labelled source-frame contact sheet PNG with range, columns, three tile sizes, optional skipped frames and preview. It shows timing and labels but is not a sprite atlas or animated export and does not apply playback overlays/motion. Limit 4096 px per side and 8 MP, plus other memory needs.

## Added in 7.14

- Animated GIF import to a new editable one-layer animation, compositing transparent partial frames with disposal 0–3 and interlace/local palettes, with FPS-based rounded holds, loop detection and a thumbnail. Finite repeat counts become continuous loops; zero delays become 0.1 s; long holds may require lower FPS. It cannot recover original layers and is not video import. Unsupported text graphics and unusual LZW streams are rejected. 10 MiB file, 2 MP canvas, 60 frames and 64 MiB decoded frame pixels; extra memory required.
- Sprite-sheet import: divide a PNG/JPEG/WebP into evenly sized row-major cells, choose grid, count, FPS and hold, create a new editable animation and thumbnail. Alpha is preserved. No spacing, margins, atlas metadata or motion inference. Same file, canvas, frame and decoded-pixel limits. Both importers need physical Android picker and memory testing.

## Added in 7.13

- Editable Qelem project JSON backup of live artwork (Actions → Export project backup) and validated import as a new gallery artwork. Includes frames/layers/cels, animation metadata, audio and an optional gallery thumbnail; does not include collections, palettes, custom brushes, history or a temporary selection. CRC detects accidental damage, not malicious tampering or authenticity. Limits: 24 MiB file, 128 MiB estimated decoded cels, 512 cels, 4096 px per side; native export requires Android 10+. Large projects can fail or pause. Imported thumbnails are static and approximate. No cloud sync or PSD/Procreate interoperability; physical Android file export/picker testing remains essential.

## Added in 7.12

- One-off soft-edged fill or clear through the current selection, with radius, strength, colour and approximate mask preview. The hard selection itself is unchanged; this is not general feathered brush clipping. Alpha lock is respected, edits are undoable and blank fill cels are supported. 1–32 px box-blur radius, up to 4 MP padded area and estimated 64 MiB temporary memory. See README for safety and limitations.

## Added in 7.11

- Selection borders (inside, outside or both; square radius 1–32 px), a mask preview, and one temporary saved-selection slot. Selection changes are not undoable or persistent; painting through them is undoable. Borders are hard masks, not feathering. 4 MP / 4096 runs limit; empty results are refused. Saved slot clears when leaving artwork or on canvas resize/orientation including undo/redo.

## Added in 7.10

- Whole-artwork 90° clockwise/counterclockwise and 180° rotation, plus horizontal/vertical mirror. All frames and layers including hidden/locked cels change after confirmation; quarter turns swap dimensions. Undo/redo restores artwork and clears the temporary selection. Separate from view rotation. Animation guides and camera/layer motion keys block it because remapping is not implemented. 4096 px per side and 64 MiB estimated new-cel limit, plus existing history and memory. Drawing-guide settings are not rotated with the artwork.

## Added in 7.9

- Canvas resize across all frames and layers, including hidden and locked cels. Choose nine anchors for crop/expand or smooth/nearest resampling. Dimensions and pixels are undoable; selection is cleared. Refused for animation guides or any camera/layer motion keys (disabled keys included) because coordinates are not remapped. The limit is 1–4096 px per side and 64 MiB estimated new-cel allocation, plus existing history and memory. Drawing guides adjust to new canvas dimensions; crop can discard pixels and scaling resamples.

## Added in 7.8

- Destructive Tone Curves adjustment with five fixed input points per master/R/G/B channel, draggable graph, precise sliders, channel presets, approximate cel preview and one-step undo. It preserves alpha and respects hard selections. It is not an editable adjustment layer or Bézier curve; current frame only, 4 MP / estimated 64 MiB limit. Preview is approximate and settings are not retained for editing.

## Added in 7.7

- Per-layer straight-line assist for grid, isometric and one/two/three-point perspective guides. Brush and eraser strokes choose the nearest direction after a short drag and stay on a line through the stroke start. It does not snap the start to guide lines or intersections; smudge is not assisted. Symmetry mirroring now requires the Symmetry guide to be active. Settings persist; strokes and layer assist changes are undoable, guide changes are not. Brush and eraser only; guide settings are saved but not themselves undoable. This does not snap to intersections or deform brushes.

## Added in 7.6

- Device-local gallery collections: create, rename, delete, assign one collection per artwork, and filter together with search/pins/sort. This is not a visual stack, hierarchy or sync; collections are local metadata, not part of projects. Each artwork can belong to at most one collection; duplicates start unfiled. Delete collection keeps artwork. Limits: 50 collections, 40-character names, 1,000 assignments. Corrupt metadata is not overwritten and collection editing is disabled; artwork stays visible. Clearing app data or uninstalling can lose collections and artwork.

## Added in 7.5

- One project reference layer can be designated, saved, cleared and undone. In Fill settings, Fill, colour drop and Magic wand can sample its **raw cel for the current frame** even when hidden. This ignores its opacity, blend, clipping and playback transforms; the canvas background is not sampled. The destination fill still affects only the active layer and obeys its lock, alpha lock and selection. A reference without a cel for the current frame is refused. Sampling is bounded by the existing 4 MP / estimated 64 MiB limits and may pause the UI. Deleting the reference layer or merging it down may remove the designation; duplicating it does not copy the designation.
- Basic text can be rendered to a new raster layer on the current frame, with multiline input, system-font choice, size, position, alignment, weight, colour and an approximate preview. The text cannot be edited after creation; lines do not automatically wrap, fonts vary by device, and off-canvas text is clipped. Other frames remain blank. Limit: 500 characters, 12 lines and an 8 MP canvas. Layer creation is undoable.

## Major work still missing or partial

- Editable text objects, font import and advanced typography; text is currently raster-only.
- True layer masks, nested layer groups and non-destructive adjustments. Clipping and basic destructive effects exist but are not substitutes for these features.
- General feathered selections for brushes/effects, advanced automatic selection and full precision transforms for non-rectangular masks. Canvas transform supports hard masks, with limits.
- Snapping to guide intersections, adjustable vanishing points, advanced perspective assist, advanced liquify and perspective-correct warp, custom pivots, and wider brush controls/import/export. Existing guides, smudge, warp and brush studio are limited implementations.
- Timelapse recording, visual gallery stacks/nested folders, managed colour profiles/CMYK, print DPI workflows, PSD/Procreate import/export and most other professional interchange formats.
- Deformable rigs, morphing, live particles, multi-track audio and more advanced animation timelines. Existing layer/camera keys, baked motion and particles, and one audio track are limited; MP4/audio depend on device capabilities.
- Physical Android testing, including touch, rendering speed, audio pickers/encoding and MediaStore export. Automated desktop checks cannot verify these.

Older builds may drop newer project fields when they save; back up artwork before trying a downgrade. See README for provenance and signing cautions.
