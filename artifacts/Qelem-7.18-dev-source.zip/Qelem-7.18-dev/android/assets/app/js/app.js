/* Qalam — application shell: wires the document, viewport, UI and storage. */
(function () {
  'use strict';
  const Q = window.Q;

  const App = (Q.App = {
    doc: null,
    view: null,
    playing: false,
    playTimer: 0,
    recent: [],
    autosaveTimer: 0,
    ready: false,
    fillThreshold: 12,
    fillSource: 'active',
    fillScope: 'connected',
    previousColor: null,
    lastPaintBrush: null,
    clipboard: null,
    selectionStash: null
  });

  /* ── boot ───────────────────────────────────────────────── */

  App.init = function () {
    const canvas = Q.el('#view');
    App.view = new Q.View(canvas);

    const v = App.view;
    v.onDocChange = function () { App.markDirty(); };
    v.onFill = function (x, y) { App.fillAt(x, y); };
    v.onWand = function (x, y) { App.wandAt(x, y); };
    v.onStrokeEnd = function () { App.markDirty(); App.pushRecentColor(); };
    v.onUndo = function () { App.undo(); };
    v.onRedo = function () { App.redo(); };
    v.onQuickEdit = function () { Q.UI.closeTray(); Q.UI.quickEditDialog(); };
    v.onClearCel = function () { Q.UI.clearCelDialog(); };
    v.onDrawStart = function () {
      if (!Q.el('#tray').classList.contains('hidden')) Q.UI.closeTray();
    };
    v.onPick = function (rgb) {
      App.setColor(rgb);
      v.tool = 'brush'; Q.UI.syncBrushUi();
      Q.el('#btnEyedrop').classList.remove('on');
      Q.toast('Picked ' + Q.rgbToHex(rgb));
    };

    Q.UI.init();
    // Do not let a slow storage provider keep the launch screen on top forever.
    setTimeout(function () { Q.el('#splash').classList.add('hidden'); }, 400);

    v.gestureDelays=Q.sanitizeGestureDelays(Q.Store.meta('gestureDelays'));
    const threshold = Q.Store.meta('fillThreshold');
    if (typeof threshold === 'number') App.fillThreshold = Q.clamp(threshold, 0, 128);
    App.fillSource=['visible','reference'].includes(Q.Store.meta('fillSource')) ? Q.Store.meta('fillSource') : 'active';
    App.fillScope=Q.Store.meta('fillScope')==='all' ? 'all' : 'connected';
    const pressure=Q.Store.meta('globalPressure'), smoothing=Q.Store.meta('globalSmoothing');
    v.smudgeHardness=Q.sanitizeSmudgeHardness(Q.Store.meta('smudgeHardness'));
    v.smudgePressure=Q.Store.meta('smudgePressure')===true;
    const smudgeStrength=Q.Store.meta('smudgeStrength'); v.smudgeStrength=typeof smudgeStrength==='number' && Number.isFinite(smudgeStrength) ? Q.clamp(smudgeStrength,0.01,1) : 1;
    v.globalPressure=Number.isFinite(pressure) ? Q.clamp(pressure,0.5,2) : 1;
    v.globalSmoothing=Number.isFinite(smoothing) ? Q.clamp(smoothing,0,0.9) : 0;
    Q.restoreBrushSettings(Q.Store.meta('brushSettings'));
    Q.restoreCustomBrushes();
    const savedBrush = Q.Store.meta('brush');
    const savedRecent = Q.Store.meta('recent');
    if (savedRecent && savedRecent.length) App.recent = savedRecent;
    if (savedBrush) v.brush = Q.brushById(savedBrush);
    App.lastPaintBrush = v.brush.eraser ? Q.BRUSHES.find(b=>!b.eraser) : v.brush;
    App.previousColor = Q.hexToRgb(Q.Store.meta('previousColor'));
    v.size = v.brush.size;
    v.color = Q.hexToRgb(Q.Store.meta('color')) || [24, 24, 26];
    v.opacity = 1;

    Q.Store.init().then(function (mode) {
      App.ready = true;
      Q.UI.showGallery();
      if (mode === 'local') {
        Q.toast('Using limited local storage — export often', 3200);
      }
    }).catch(function () {
      App.ready = true;
      Q.UI.showGallery();
      Q.toast('Storage unavailable — artwork will not persist', 4000);
    });

    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'hidden') { if (App.cancelAudioExport) App.cancelAudioExport(); App.stopPlay(); App.saveNow(false); }
    });

    // 0 = the app handled the back gesture, 1 = nothing left to close
    window.qalamBack = function () {
      if (App.cancelAudioExport) { App.cancelAudioExport(); return 0; }
      if (!Q.el('#modal').classList.contains('hidden')) { Q.UI.closeModal(); return 0; }
      if (Q.UI.isFocusMode()) { Q.UI.setFocusMode(false); return 0; }
      if (!Q.el('#tray').classList.contains('hidden')) { Q.UI.closeTray(); return 0; }
      if (!Q.el('#referenceWindow').classList.contains('hidden')) { Q.UI.closeReference(); return 0; }
      if (App.playing) { App.togglePlay(); return 0; }
      if (!Q.el('#studio').classList.contains('hidden')) { App.backToGallery(); return 0; }
      return 1;
    };

    requestAnimationFrame(function () {
      Q.hint('Three-finger tap undo · pinch & twist to zoom and rotate', 4200);
    });
  };

  /* ── documents ──────────────────────────────────────────── */

  App.createDoc = function (w, h, name) {
    const doc = new Q.Doc({ width: w, height: h, name: name || 'Untitled' });
    if (w * h > 1200 * 1200) doc.onion = false;
    App.adoptDoc(doc, true);
  };

  App.openDoc = function (id) {
    Q.Store.load(id).then(function (doc) {
      if (!doc) { Q.toast('Could not open that artwork'); return; }
      App.adoptDoc(doc, false);
    });
  };

  App.adoptDoc = function (doc, isNew) {
    if (App.cancelAudioExport) App.cancelAudioExport();
    if (Q.UI.cancelCanvasTransform) Q.UI.cancelCanvasTransform();
    App.stopPlay();
    if (App.view) App.view.cancelActiveInput();
    if (Q.UI.resetReference) Q.UI.resetReference();
    // Serialize the previous artwork before switching documents, including when
    // New canvas is opened from the studio before the autosave timer fires.
    if (App.doc && App.doc.id !== doc.id) { clearTimeout(App.autosaveTimer); App.saveNow(false); }
    App.doc = doc; App.selectionStash=null;
    const v = App.view;
    v.doc = doc;
    v.locked = false;
    v.tool = 'brush'; v.selection = null; v.selectionDraft = null; v.selectionOperation='replace'; v.motionDraft = null; v.transparentPreview = false;
    Q.UI.showStudio();
    Q.el('#btnEyedrop').classList.remove('on');
    Q.el('#btnFill').classList.remove('on');
    v.resize();
    v.fit();
    v.dirty = true;
    Q.Store.meta('lastDoc', doc.id);
    // keep the page in sync when layer/frame structure changes
    doc.history.onchange = function () {
      Q.UI.syncHistory();
      App.markDirty();
    };
    if (isNew) {
      App.saveNow(false);
      Q.hint('Draw with a finger or stylus · pinch to zoom', 2600);
    }
  };

  App.backToGallery = function () {
    App.selectionStash=null;
    if (Q.UI.cancelCanvasTransform) Q.UI.cancelCanvasTransform();
    App.stopPlay();
    if (Q.UI.resetReference) Q.UI.resetReference();
    if (App.view) App.view.cancelActiveInput();
    App.saveNow(false);
    if (App.doc) Q.Store.meta('lastDoc', App.doc.id);
    Q.UI.showGallery();
  };

  /* ── editing ────────────────────────────────────────────── */

  App.undo = function () {
    App.stopPlay();
    if (!App.doc) return;
    const w=App.doc.width,h=App.doc.height,entry=App.doc.history.undoStack[App.doc.history.undoStack.length-1];
    if (App.doc.history.undo()) {
      if((entry && entry.canvasOperation) || w!==App.doc.width || h!==App.doc.height) App.canvasSizeChanged();
      App.view.dirty = true;
      Q.UI.syncDoc();
      App.markDirty();
      Q.haptic(6);
    }
  };

  App.redo = function () {
    App.stopPlay();
    if (!App.doc) return;
    const w=App.doc.width,h=App.doc.height,entry=App.doc.history.redoStack[App.doc.history.redoStack.length-1];
    if (App.doc.history.redo()) {
      if((entry && entry.canvasOperation) || w!==App.doc.width || h!==App.doc.height) App.canvasSizeChanged();
      App.view.dirty = true;
      Q.UI.syncDoc();
      App.markDirty();
      Q.haptic(6);
    }
  };

  App.canvasSizeChanged = function () {
    App.selectionStash=null;
    const v=App.view;if(!v)return;
    if(v.cancelActiveInput)v.cancelActiveInput();v.selection=null;v.selectionDraft=null;
    if(v.meshTransform){if(Q.UI.cancelCanvasTransform)Q.UI.cancelCanvasTransform();else {v.meshTransform=null;v.meshPointer=null;}}
    if(v.fit)v.fit();v.dirty=true;
  };
  App.canvasResizeTarget = function () {
    const d=App.doc,v=App.view;if(!d || !v)return null;
    return {doc:d,width:d.width,height:d.height,frames:d.frames.map(f=>({frame:f,cels:f.cels.slice()})),layers:d.layers.slice(),undo:d.history.undoStack.slice(),redo:d.history.redoStack.slice()};
  };
  App.validateCanvasTarget = function(target,allowLocked) {
    const d=App.doc,v=App.view;if(!target || !d || !v || target.doc!==d || d.width!==target.width || d.height!==target.height || d.frames.length!==target.frames.length || d.layers.length!==target.layers.length || target.layers.some((l,i)=>l!==d.layers[i]) || target.frames.some((f,i)=>f.frame!==d.frames[i] || f.cels.length!==d.frames[i].cels.length || f.cels.some((c,j)=>c!==d.frames[i].cels[j])))return {error:'Artwork changed; reopen the canvas operation'};
    const h=d.history;if(h.undoStack.length!==target.undo.length || h.redoStack.length!==target.redo.length || target.undo.some((e,i)=>e!==h.undoStack[i]) || target.redo.some((e,i)=>e!==h.redoStack[i]))return {error:'Artwork changed; reopen the canvas operation'};
    if(App.playing || (v.locked && !allowLocked) || v.stroke || v.quickShape || v.meshTransform)return {error:'Finish playback or the current operation first'};
    return {};
  };
  App.validateCanvasResize = function(target,options) {
    const state=App.validateCanvasTarget(target);return state.error ? state : Q.planCanvasResize(App.doc,options);
  };
  App.validateCanvasOrientation = function(target,mode) {
    const state=App.validateCanvasTarget(target);return state.error ? state : Q.planCanvasOrientation(App.doc,mode);
  };
  App.orientCanvas = function(target,mode) {
    const plan=App.validateCanvasOrientation(target,mode);if(plan.error)return plan;
    const result=App.doc.orientCanvas(mode);if(result.error)return result;
    App.canvasSizeChanged();Q.UI.syncDoc();App.markDirty();return result;
  };
  App.resizeCanvas = function(target,options) {
    const plan=App.validateCanvasResize(target,options);if(plan.error)return plan;
    const result=App.doc.resizeCanvas(options);if(result.error)return result;
    App.canvasSizeChanged();Q.UI.syncDoc();App.markDirty();return result;
  };

  App.setBrush = function (id) {
    const b = Q.brushById(id);
    if (!b.eraser) App.lastPaintBrush=b;
    App.view.brush = b;
    App.view.tool = 'brush';
    Q.el('#btnFill').classList.remove('on'); Q.el('#btnEyedrop').classList.remove('on');
    App.view.size = b.size;
    App.view.opacity = 1;
    Q.Store.meta('brush', id);
    Q.UI.syncBrushUi();
  };

  App.setSize = function (n) {
    App.view.size = Q.clamp(n, 1, 240);
    Q.UI.syncBrushSliders();
  };

  App.setOpacity = function (v) {
    App.view.opacity = Q.clamp(v, 0.01, 1);
    Q.UI.syncBrushSliders();
  };

  App.setColor = function (rgb) {
    const v=App.view; if (Q.rgbToHex(v.color)!==Q.rgbToHex(rgb)) { App.previousColor=v.color.slice(); Q.Store.meta('previousColor',Q.rgbToHex(App.previousColor)); }
    v.color = rgb.slice();
    Q.Store.meta('color', Q.rgbToHex(rgb));
    Q.UI.syncBrushUi();
    App.pushRecentColor();
  };

  App.swapPreviousColor = function () {
    if (!App.previousColor || Q.rgbToHex(App.previousColor)===Q.rgbToHex(App.view.color)) { Q.toast('Choose another colour first'); return false; }
    App.setColor(App.previousColor); Q.toast('Switched to previous colour'); return true;
  };
  App.useEraser = function (sync) {
    const v=App.view;
    if (sync) {
      const source=v.brush.eraser ? App.lastPaintBrush : v.brush;
      if (!source || source.eraser) { Q.toast('Choose a painting brush first'); return; }
      App.lastPaintBrush=source; v.brush={...source,eraser:true,syncedEraser:true}; Q.toast('Eraser matched to '+source.name);
    } else if (v.brush.eraser) { v.brush=App.lastPaintBrush || Q.BRUSHES.find(b=>!b.eraser); Q.toast('Painting brush'); }
    else { App.lastPaintBrush=v.brush; v.brush=Q.brushById('eraser'); Q.toast('Eraser'); }
    v.tool='brush'; Q.el('#btnFill').classList.remove('on'); Q.el('#btnEyedrop').classList.remove('on'); Q.UI.syncBrushUi();
  };
  App.toggleSolo = function (index) {
    const d=App.doc; if(!d || !d.toggleSolo(index)) return; App.view.dirty=true; Q.UI.syncDoc(); App.markDirty();
    Q.toast(d.solo && d.layer(index).clipped ? 'Solo includes the clipping base' : d.solo ? 'Layer soloed · hold eye again to restore' : 'Visibility restored',3000);
  };
  App.restoreSolo = function () { if(!App.doc || !App.doc.restoreSolo()) return; App.view.dirty=true; Q.UI.syncDoc(); App.markDirty(); Q.toast('Visibility restored'); };

  App.pushRecentColor = function () {
    const c = App.view.color;
    const key = Q.rgbToHex(c);
    App.recent = App.recent.filter(function (r) { return Q.rgbToHex(r) !== key; });
    App.recent.unshift(c);
    App.recent = App.recent.slice(0, 12);
    Q.Store.meta('recent', App.recent);
  };

  App.setLayerProp = function (i, key, value) {
    App.doc.setLayerProp(i, key, value);
    App.view.dirty = true;
    Q.UI.syncDoc();
  };

  App.setReferenceLayer = function (i,value) {
    if(!App.doc || !App.doc.setReferenceLayer(i,value)) return;
    App.view.dirty=true;Q.UI.syncDoc();App.markDirty();Q.toast(value ? 'Reference layer set' : 'Reference layer cleared');
  };

  App.setLayerClipped = function (i,value) {
    if (!App.doc || !App.doc.setLayerClipped(i,value)) { Q.toast('Add a layer below before enabling clipping',4000); return; }
    App.view.dirty=true; Q.UI.syncDoc(); App.markDirty();
  };

  App.commitLayerOpacity = function (i, before) {
    const d = App.doc;
    if (!d) return;
    const current = d.layers[i].opacity;
    d.layers[i].opacity = before == null ? 1 : before;
    d.setLayerProp(i, 'opacity', current);
    App.view.dirty = true;
    App.markDirty();
    Q.UI.syncDoc();
  };

  App.addLayer = function () {
    App.stopPlay();
    App.doc.addLayer();
    App.view.dirty = true;
    Q.UI.syncDoc();
    App.markDirty();
  };

  // Shared renderer keeps the small preview and final raster mathematically aligned.
  Q.paintFillOptions = function (options) {
    options=options || {}; const angle=options.angle == null ? 0 : Number(options.angle), alpha1=options.alpha1 == null ? 1 : Number(options.alpha1), alpha2=options.alpha2 == null ? 1 : Number(options.alpha2);
    if(!Number.isFinite(angle) || Math.abs(angle)>180 || !Number.isFinite(alpha1) || alpha1<0 || alpha1>1 || !Number.isFinite(alpha2) || alpha2<0 || alpha2>1) return null;
    return {angle,alpha1,alpha2};
  };
  Q.renderPaintFill = function (c,w,h,kind,first,second,direction,midpoint,options) {
    const a=Q.hexToRgb(first), b=Q.hexToRgb(second), o=Q.paintFillOptions(options);
    if (!a || !o || !['solid','gradient'].includes(kind) || (kind==='gradient' && (!b || !['horizontal','vertical','diagonal','radial','angle'].includes(direction)))) return false;
    const mid=midpoint == null ? 0.5 : Number(midpoint); if(!Number.isFinite(mid) || mid<0.1 || mid>0.9) return false;
    if(kind==='solid') c.fillStyle=Q.rgba(a,o.alpha1);
    else {
      let g;
      if(direction==='radial') g=c.createRadialGradient(w/2,h/2,0,w/2,h/2,Math.hypot(w,h)/2);
      else if(direction==='angle') { const t=o.angle*Math.PI/180, dx=Math.cos(t),dy=Math.sin(t), length=(Math.abs(w*dx)+Math.abs(h*dy))/2; g=c.createLinearGradient(w/2-dx*length,h/2-dy*length,w/2+dx*length,h/2+dy*length); }
      else g=c.createLinearGradient(0,0,direction==='vertical' ? 0 : w,direction==='horizontal' ? 0 : h);
      const sum=o.alpha1+o.alpha2, middle=a.map((v,i)=>sum ? (v*o.alpha1+b[i]*o.alpha2)/sum : (v+b[i])/2);
      g.addColorStop(0,Q.rgba(a,o.alpha1)); g.addColorStop(mid,Q.rgba(middle.map(Math.round),sum/2)); g.addColorStop(1,Q.rgba(b,o.alpha2)); c.fillStyle=g;
    }
    c.fillRect(0,0,w,h); return true;
  };
  // Fill a new raster layer on the current frame; prepare it before changing history.
  App.addPaintLayer = function (kind,first,second,direction,midpoint,options) {
    App.stopPlay(); const d=App.doc;
    if (!d || !Q.hexToRgb(first) || (kind==='gradient' && !Q.hexToRgb(second)) || !['solid','gradient'].includes(kind)) { Q.toast('Enter valid hex colours',4000); return false; }
    if (kind==='gradient' && !['horizontal','vertical','diagonal','radial','angle'].includes(direction)) { Q.toast('Choose a gradient direction',4000); return false; }
    if ((midpoint!=null && (!Number.isFinite(Number(midpoint)) || Number(midpoint)<0.1 || Number(midpoint)>0.9)) || !Q.paintFillOptions(options)) { Q.toast('Choose a valid midpoint, angle and opacity',4000); return false; }
    try {
      const cv=Q.canvas(d.width,d.height), c=cv.getContext('2d');
      if(!Q.renderPaintFill(c,d.width,d.height,kind,first,second,direction,midpoint,options)) return false;
      d.insertImageLayer(cv,kind==='solid' ? 'Solid colour' : 'Gradient');
      App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Layer added · Undo to remove'); return true;
    } catch(e) { Q.toast('Could not create this layer on this device',4000); return false; }
  };

  Q.validateRasterText = function (o,d) {
    if(!o || typeof o.text!=='string' || !o.text.trim() || o.text.length>500 || o.text.split('\n').length>12) return 'Enter up to 500 characters and 12 lines';
    if(!Number.isInteger(o.size) || o.size<6 || o.size>512) return 'Text size must be 6–512 pixels';
    if(!Number.isFinite(o.x) || !Number.isFinite(o.y) || o.x<0 || o.y<0 || o.x>d.width || o.y>d.height) return 'Position must be inside the canvas';
    if(!['sans-serif','serif','monospace'].includes(o.font) || !['normal','bold'].includes(o.weight) || !['left','center','right'].includes(o.align) || !Q.hexToRgb(o.color)) return 'Choose valid text options and a hex colour';
    if(d.width*d.height>8*1024*1024) return 'Text layers are limited to 8 megapixels';
    return null;
  };
  Q.renderRasterText = function(ctx,o) {
    ctx.save();ctx.fillStyle=o.color;ctx.font=o.weight+' '+o.size+'px '+o.font;ctx.textAlign=o.align;ctx.textBaseline='top';
    o.text.split('\n').forEach((line,i)=>ctx.fillText(line,o.x,o.y+i*o.size*1.2));ctx.restore();
  };
  App.addRasterText = function (o,target) {
    const d=App.doc;App.stopPlay();
    if(!d || !target || target.doc!==d || d.frames[d.activeFrame]!==target.frame || d.layer()!==target.layer) return 'Artwork, frame or layer changed; reopen this tool';
    const error=Q.validateRasterText(o,d);if(error)return error;
    try {
      const cv=Q.canvas(d.width,d.height),ctx=cv.getContext('2d');Q.renderRasterText(ctx,o);
      if(!d.insertImageLayer(cv,'Text'))return 'Could not insert text layer';
      App.view.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();App.markDirty();Q.toast('Text added as pixels · Undo to remove');return null;
    } catch(e) {return 'Could not create text on this device';}
  };

  // User-selected images only; imported pixels become a new layer in one frame.
  App.importImageFile = function (file,target) {
    if (!file || !target || !target.doc) return;
    const type=String(file.type || '').toLowerCase(), name=String(file.name || 'Imported image');
    if (!/^image\/(png|jpeg|webp|gif)$/.test(type) && !(type==='' && /\.(png|jpe?g|webp|gif)$/i.test(name))) { Q.toast('Choose a PNG, JPEG, WebP or GIF image',4000); return; }
    if (!Number.isFinite(file.size) || file.size<=0 || file.size>16*1024*1024) { Q.toast('Choose an image file smaller than 16 MiB',4000); return; }
    function valid() { return App.doc===target.doc && App.doc.frames[App.doc.activeFrame]===target.frame && App.doc.layer()===target.layer && !App.playing; }
    if (!valid()) { Q.toast('Import cancelled because the artwork, frame or layer changed',4000); return; }
    const reader=new FileReader();
    reader.onerror=function () { Q.toast('Could not read the selected image',4000); };
    reader.onload=function () {
      if (!valid()) { Q.toast('Import cancelled because the artwork, frame or layer changed',4000); return; }
      const img=new Image();
      img.onerror=function () { Q.toast('Could not decode the selected image',4000); };
      img.onload=function () {
        if (!valid()) { Q.toast('Import cancelled because the artwork, frame or layer changed',4000); return; }
        const w=img.naturalWidth || img.width, h=img.naturalHeight || img.height, d=target.doc;
        if (!w || !h || w>8192 || h>8192 || w*h>16777216) { Q.toast('Image dimensions exceed the import limit',4000); return; }
        try {
          const canvas=Q.canvas(d.width,d.height), ctx=canvas.getContext('2d');
          const scale=Math.min(1,d.width/w,d.height/h), dw=Math.max(1,Math.round(w*scale)), dh=Math.max(1,Math.round(h*scale));
          ctx.drawImage(img,Math.floor((d.width-dw)/2),Math.floor((d.height-dh)/2),dw,dh);
          const label=name.replace(/\.[^.]+$/,'').slice(0,64) || 'Imported image';
          d.insertImageLayer(canvas,label); App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty();
          Q.toast('Image imported as a layer · Undo to remove',4000);
        } catch (e) { Q.toast('Could not import this image on this device',4000); }
      };
      img.src=reader.result;
    };
    try { reader.readAsDataURL(file); } catch (e) { Q.toast('Could not read the selected image',4000); }
  };

  // The reference is a temporary UI-only bitmap, never inserted in a project.
  App.loadReferenceFile = function (file,target) {
    if (!file || !target || !Q.UI.isReferenceTarget(target)) return;
    const type=String(file.type || '').toLowerCase(), name=String(file.name || 'Reference image');
    if (!/^image\/(png|jpeg|webp|gif)$/.test(type) && !(type==='' && /\.(png|jpe?g|webp|gif)$/i.test(name))) { Q.toast('Choose a PNG, JPEG, WebP or GIF image',4000); return; }
    if (!Number.isFinite(file.size) || file.size<=0 || file.size>16*1024*1024) { Q.toast('Choose an image file smaller than 16 MiB',4000); return; }
    const reader=new FileReader(); reader.onerror=()=>Q.toast('Could not read the reference image',4000);
    reader.onload=function () {
      if (!Q.UI.isReferenceTarget(target)) return;
      const img=new Image(); img.onerror=()=>Q.toast('Could not decode the reference image',4000);
      img.onload=function () {
        if (!Q.UI.isReferenceTarget(target)) return;
        const w=img.naturalWidth || img.width,h=img.naturalHeight || img.height;
        if (!w || !h || w>8192 || h>8192 || w*h>16777216) { Q.toast('Image dimensions exceed the reference limit',4000); return; }
        try { const scale=Math.min(1,2048/w,2048/h), cv=Q.canvas(Math.max(1,Math.round(w*scale)),Math.max(1,Math.round(h*scale))); cv.getContext('2d').drawImage(img,0,0,cv.width,cv.height); Q.UI.setReferenceImage(target,cv,name); }
        catch(e) { Q.toast('Could not open the reference image on this device',4000); }
      }; img.src=reader.result;
    };
    try { reader.readAsDataURL(file); } catch(e) { Q.toast('Could not read the reference image',4000); }
  };

  App.duplicateLayer = function (idx) {
    const d = App.doc;
    const from = idx == null ? d.activeLayer : idx;
    d.addLayer(from);
    App.view.dirty = true;
    Q.UI.syncDoc();
    App.markDirty();
  };

  App.deleteLayer = function (idx) {
    App.doc.deleteLayer(idx == null ? App.doc.activeLayer : idx);
    App.view.dirty = true;
    Q.UI.syncDoc();
    App.markDirty();
  };

  App.moveLayer = function (idx, dir) {
    App.doc.moveLayer(idx, dir);
    App.view.dirty = true;
    Q.UI.syncDoc();
    App.markDirty();
  };

  App.mergeDownLayer = function (idx) {
    App.doc.mergeDown(idx);
    App.view.dirty = true;
    Q.UI.syncDoc();
    App.markDirty();
  };

  App.clearCurrentCel = function () {
    const d=App.doc; if (!d || !d.clearCurrentCel()) return false;
    App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty();
    Q.toast('Current cel cleared · Undo to restore'); return true;
  };

  App.clearLayer = function (idx) {
    App.doc.clearLayer(idx);
    App.view.dirty = true;
    App.markDirty();
  };

  /* ── frames ─────────────────────────────────────────────── */

  App.addFrame = function (duplicate) {
    App.stopPlay();
    const d = App.doc;
    if (!d) return;
    if (d.frames.length >= 60) { Q.toast('Frame limit reached (60)'); return; }
    d.addFrame(!!duplicate);
    if (d.frames.length > 1) d.onion = true;
    App.view.dirty = true;
    Q.UI.syncDoc();
    Q.UI.refreshTimeline();
    App.markDirty();
  };

  App.deleteFrame = function (idx) {
    App.stopPlay();
    const d = App.doc;
    if (!d) return;
    d.deleteFrame(idx == null ? d.activeFrame : idx);
    App.view.dirty = true;
    Q.UI.syncDoc();
    Q.UI.refreshTimeline();
    App.markDirty();
  };

  App.selectFrame = function (i) {
    App.stopPlay();
    if (!App.doc) return;
    App.doc.activeFrame = Q.clamp(i, 0, App.doc.frames.length - 1);
    App.view.dirty = true;
    Q.UI.syncDoc();
    Q.UI.refreshTimeline();
    App.markDirty();
  };

  App.moveFrame = function (i, dir) {
    App.stopPlay();
    App.doc.moveFrame(i, dir);
    App.view.dirty = true;
    Q.UI.syncDoc();
    Q.UI.refreshTimeline();
    App.markDirty();
  };

  App.moveFrameTo = function (from,to) {
    App.stopPlay(); const d=App.doc; if(!d || !d.moveFrameTo(from,to)) return false;
    App.view.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();App.markDirty();return true;
  };

  // One export cycle; ping-pong excludes duplicated endpoints.
  Q.playbackBounds = function (doc) {
    const last=Math.max(0,doc.frames.length-1), range=doc.playRange;
    const start=range ? Q.clamp(range.start,0,last) : 0;
    return {start:start,end:range ? Q.clamp(range.end,start,last) : last};
  };
  Q.animationOrder = function (count, mode, start, end) {
    if (count<=0) return [];
    start=Q.clamp(Number.isInteger(start) ? start : 0,0,count-1);
    end=Q.clamp(Number.isInteger(end) ? end : count-1,start,count-1);
    const order = [];
    for (let i=start;i<=end;i++) order.push(i);
    if (mode === 'pingpong') for (let i=end-1;i>start;i--) order.push(i);
    if (mode === 'reverse') order.reverse();
    return order;
  };
  Q.playableFrames = function (doc) {
    const bounds=Q.playbackBounds(doc), frames=[];
    for (let i=bounds.start;i<=bounds.end;i++) if (!doc.frames[i].skipped && !doc.frames[i].role) frames.push(i);
    return frames;
  };
  // Navigate source order among frames that participate in the current range.
  // A frame outside the range seeks the nearest included frame; no wrapping.
  Q.neighborPlayableFrame = function (doc, index, direction) {
    const frames=Q.playableFrames(doc);
    if (direction<0) { for(let i=frames.length-1;i>=0;i--) if(frames[i]<index) return frames[i]; }
    else if (direction>0) { for(const frame of frames) if(frame>index) return frame; }
    return -1;
  };
  Q.playbackOrder = function (doc) {
    const frames=Q.playableFrames(doc), result=frames.slice();
    if (doc.playMode === 'pingpong') for (let i=frames.length-2;i>0;i--) result.push(frames[i]);
    if (doc.playMode === 'reverse') result.reverse();
    return result;
  };
  Q.frameDelayMs = function (doc, index) {
    return 1000 * (doc.frames[index].duration || 1) / Q.clamp(doc.fps, 1, 30);
  };

  // Audio is anchored at the first included timeline frame, not the playback range.
  Q.audioFrameTime = function (doc,index) {
    let ticks=0; for (let i=0;i<index && i<doc.frames.length;i++) if (!doc.frames[i].skipped && !doc.frames[i].role) ticks+=doc.frames[i].duration || 1;
    return ticks / Q.clamp(doc.fps,1,30);
  };
  App.syncPreviewAudio = function (d,frame,restart,forceSeek) {
    const audio=App.previewAudio; if (!audio || !App.playing || App.doc!==d) return;
    const time=Q.audioFrameTime(d,frame);
    if (Number.isFinite(audio.duration) && time>=audio.duration) { audio.pause(); return; }
    try { if (restart || forceSeek || Math.abs(audio.currentTime-time)>0.2) audio.currentTime=time; }
    catch(e) { /* Metadata may not be ready; loadedmetadata will retry. */ }
    if (restart) try {
      const p=audio.play();
      if (p && p.catch) p.catch(function () { if (App.previewAudio===audio && App.playing) Q.toast('Audio playback is unavailable on this device',4000); });
    } catch(e) { if (App.previewAudio===audio && App.playing) Q.toast('Audio playback is unavailable on this device',4000); }
  };
  App.startPreviewAudio = function (d,frame) {
    if (!d.audioTrack || d.audioTrack.muted || (d.playMode==='pingpong' || d.playMode==='reverse')) return;
    try {
      const audio=new Audio(); App.previewAudio=audio;
      audio.preload='auto'; audio.src=d.audioTrack.data;
      audio.addEventListener('loadedmetadata',function () { if (App.previewAudio===audio && App.playing) App.syncPreviewAudio(d,d.activeFrame,false,true); });
      audio.addEventListener('error',function () { if (App.previewAudio===audio && App.playing) Q.toast('Audio format is not supported on this device',4000); });
      App.syncPreviewAudio(d,frame,true);
    } catch(e) { App.previewAudio=null; Q.toast('Audio playback is unavailable on this device',4000); }
  };

  App.importAudioFile = function (file,target) {
    if (!file || !target || !target.doc) return;
    const ext=String(file.name || '').toLowerCase().split('.').pop();
    const types={mp3:'mpeg',aac:'aac',m4a:'mp4',mp4:'mp4',wav:'wav',ogg:'ogg',oga:'ogg',webm:'webm'};
    const mimes={'audio/mpeg':'mpeg','audio/mp3':'mpeg','audio/x-mp3':'mpeg','audio/x-mpeg':'mpeg','audio/aac':'aac','audio/x-aac':'aac','audio/aacp':'aac','audio/mp4':'mp4','audio/m4a':'mp4','audio/x-m4a':'mp4','video/mp4':'mp4','audio/wav':'wav','audio/x-wav':'wav','audio/wave':'wav','audio/vnd.wave':'wav','audio/ogg':'ogg','application/ogg':'ogg','audio/webm':'webm'};
    const declared=String(file.type || '').toLowerCase();
    const type=mimes[declared] || types[ext] || null;
    if (!type) { Q.toast('Choose an MP3, AAC, M4A, WAV, OGG or WebM audio file',4000); return; }
    if (!Number.isFinite(file.size) || file.size<=0 || file.size>Q.MAX_AUDIO_BYTES) { Q.toast('Audio file must be 15 MiB or smaller',4000); return; }
    function valid() { return App.doc===target.doc && App.doc.audioTrack===target.track && !App.playing; }
    if (!valid()) { Q.toast('Audio import cancelled because the project changed',4000); return; }
    if (App.audioReadInProgress) { Q.toast('Wait for the current audio import to finish',4000); return; }
    App.audioReadInProgress=true;
    function readFailed() { App.audioReadInProgress=false; if (valid()) Q.toast('Could not read audio. Try a local file or a different file provider.',6000); }
    function finish(base64) {
      App.audioReadInProgress=false;
      if (!valid()) { Q.toast('Audio import cancelled because the project changed',4000); return; }
      const track={name:String(file.name || 'Audio').slice(0,100),data:'data:audio/'+type+';base64,'+base64,muted:false};
      if (!target.doc.setAudioTrack(track)) { Q.toast('Invalid audio file',4000); return; }
      Q.UI.refreshTimeline(); App.markDirty(); clearTimeout(App.autosaveTimer);
      App.saveNow(false).then(function (saved) {
        if (App.doc!==target.doc || !App.doc.audioTrack || App.doc.audioTrack.data!==track.data) return;
        Q.toast(saved ? 'Audio track added and saved · Undo to remove' : 'Audio is in memory only: save failed. Free storage or choose a smaller file.',6000);
      });
    }
    function fallback() {
      if(!valid()) { App.audioReadInProgress=false; Q.toast('Audio import cancelled because the project changed',4000); return; }
      try {
        const reader=new FileReader(); reader.onerror=reader.onabort=readFailed;
        reader.onload=function() { try {
          const bytes=new Uint8Array(reader.result); if(bytes.length!==file.size) {readFailed();return;}
          let encoded=''; const chunk=32766;
          for(let i=0;i<bytes.length;i+=chunk) {let binary='';const end=Math.min(i+chunk,bytes.length);for(let j=i;j<end;j++) binary+=String.fromCharCode(bytes[j]);encoded+=btoa(binary);}
          finish(encoded);
        } catch(e) {readFailed();} };
        reader.readAsArrayBuffer(file);
      } catch(e) {readFailed();}
    }
    try {
      const reader=new FileReader(); reader.onerror=reader.onabort=fallback;
      reader.onload=function() { const value=String(reader.result || ''), prefix=value.indexOf(','); if(prefix<0 || !/;base64$/i.test(value.slice(0,prefix))) {fallback();return;} finish(value.slice(prefix+1)); };
      reader.readAsDataURL(file);
    } catch(e) {fallback();}
  };

  App.togglePlay = function () {
    const d = App.doc;
    if (!d) return;
    if (App.playing) { App.stopPlay(); return; }
    if (d.frames.length < 2) { Q.toast('Add a frame first'); return; }
    const frames=Q.playableFrames(d);
    if (!frames.length) { Q.toast('No included frames in the playback range',4000); return; }
    App.playing = true; App.view.locked = true;
    let position=frames.indexOf(d.activeFrame), direction=1;
    if (position<0) position=d.playMode==='reverse' ? frames.length-1 : 0;
    d.activeFrame=frames[position]; App.view.dirty=true;
    App.startPreviewAudio(d,d.activeFrame);
    const step=function () {
      if (!App.playing) return;
      if (d.playMode === 'once' && position === frames.length-1) { App.stopPlay(); return; }
      let wrapped=false;
      if (d.playMode === 'pingpong') {
        if (frames.length>1) {
          if (position+direction>=frames.length || position+direction<0) direction*=-1;
          position+=direction;
        }
      } else if(d.playMode==='reverse') { wrapped=position<=0;position=wrapped ? frames.length-1 : position-1; }
      else { wrapped=position>=frames.length-1; position=wrapped ? 0 : position+1; }
      d.activeFrame=frames[position]; App.view.dirty=true; Q.UI.highlightFrame(d.activeFrame);
      App.syncPreviewAudio(d,d.activeFrame,wrapped);
      App.playTimer=setTimeout(step,Q.frameDelayMs(d,d.activeFrame));
    };
    App.playTimer=setTimeout(step,Q.frameDelayMs(d,d.activeFrame));
    Q.UI.refreshTimeline(); Q.toast(d.audioTrack && !d.audioTrack.muted && (d.playMode==='pingpong' || d.playMode==='reverse') ? 'Playing · audio muted in this mode' : 'Playing '+d.fps+' fps',4000);
  };

  App.stopPlay = function () {
    if (!App.playing) return;
    App.playing = false;
    const audio=App.previewAudio; App.previewAudio=null;
    if (audio) { try { audio.pause(); audio.removeAttribute('src'); audio.load(); } catch(e) {} }
    clearTimeout(App.playTimer);
    App.playTimer = 0;
    if (App.view) { App.view.locked = false; App.view.dirty = true; }
    Q.UI.refreshTimeline();
  };

  App.batchFrames = function (start,end,operation,value) {
    App.stopPlay(); const d=App.doc; if (!d) return false;
    try {
      if (!d.batchFrames(start,end,operation,value)) { Q.toast('Invalid range or frame limit reached'); return false; }
      App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty();
      Q.toast('Frames updated · Undo to revert'); return true;
    } catch (err) { Q.toast('Could not update frames on this device',4000); return false; }
  };

  App.retimeFrames = function(start,end,factor) {
    App.stopPlay();const d=App.doc;if(!d)return 'No document';const error=d.retimeFrames(start,end,factor);if(error)return error;
    App.view.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();App.markDirty();Q.toast('Timing changed · Undo to restore');return null;
  };
  App.distributeFrameHolds = function(start,end,total,mode) {
    App.stopPlay();const d=App.doc;if(!d)return 'No document';const error=d.distributeFrameHolds(start,end,total,mode);if(error)return error;
    App.view.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();App.markDirty();Q.toast('Holds distributed · Undo to restore');return null;
  };
  App.transformCelRange = function(start,end,dx,dy,flipX,flipY) {
    App.stopPlay();const d=App.doc;if(!d)return 'No document';
    try {const error=d.transformCelRange(start,end,dx,dy,flipX,flipY);if(error)return error;App.view.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();App.markDirty();Q.toast('Cels transformed · Undo to restore');return null;}
    catch (_) {return 'Could not transform cels on this device';}
  };
  App.insertBlankFrames = function (after,count,hold) {
    App.stopPlay(); const d=App.doc; if(!d || !d.insertBlankFrames(after,count,hold)) return false;
    App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Blank frames inserted · Undo to remove'); return true;
  };
  App.clearCelRange = function (start,end) {
    App.stopPlay(); const d=App.doc; if(!d) return 'No document';
    const error=d.clearCelRange(start,end); if(error) return error;
    App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Cels cleared · Undo to restore'); return null;
  };
  Q.findLabeledFrame = function (frames,current,label,direction) {
    if(!Array.isArray(frames) || !frames.length || !Number.isInteger(current) || current<0 || current>=frames.length || typeof label!=='string' || !label || (direction!==1 && direction!==-1)) return -1;
    for(let step=1;step<=frames.length;step++) { const index=(current+direction*step+frames.length)%frames.length; if(frames[index].group===label) return index; }
    return -1;
  };

  // A single nominal playback cycle from its first frame, not wall-clock time.
  Q.playbackSchedule = function (doc) {
    let tick=0;
    return Q.playbackOrder(doc).map(function (frame) {
      const start=tick, duration=doc.frames[frame].duration || 1;
      tick+=duration;
      return {frame:frame,startTick:start,endTick:tick,duration:duration};
    });
  };
  Q.playbackStats = function (doc) {
    const schedule=Q.playbackSchedule(doc), ticks=schedule.length ? schedule[schedule.length-1].endTick : 0;
    return {frames:Q.playableFrames(doc).length, ticks:ticks, seconds:ticks/Q.clamp(doc.fps,1,30)};
  };
  App.copyCelToRange = function (source,start,end) {
    App.stopPlay(); const d=App.doc; if (!d) return 'No document';
    try {
      const error=d.copyCelToRange(source,start,end); if (error) return error;
      App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Cels copied · Undo to revert'); return null;
    } catch (err) { return 'Could not copy cels on this device'; }
  };
  App.dissolveCels = function (start,end,easing) {
    App.stopPlay();const d=App.doc;if(!d)return 'No document';
    try {const err=d.dissolveCels(start,end,easing);if(err)return err;App.view.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();App.markDirty();Q.toast('Dissolve generated · Undo to restore');return null;}
    catch (_) {return 'Could not generate dissolve on this device';}
  };
  App.bakeMotionPath = function (source,start,end,easing,reverse) {
    App.stopPlay(); const d=App.doc; if (!d) return 'No document';
    try {
      const error=d.bakeMotionPath(source,start,end,easing,reverse); if (error) return error;
      App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Motion generated · Undo to restore'); return null;
    } catch (err) { return 'Could not generate motion on this device'; }
  };
  App.applyTwoBoneIK = function (options) {
    App.stopPlay(); const d=App.doc; if (!d) return {error:'No document'};
    try {
      const result=d.applyTwoBoneIK(options); if (result.error) return result;
      App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty();
      Q.toast(result.clamped ? 'IK keys created · '+result.clamped+' frame(s) clamped to reach' : 'IK keys created · Undo to revert',4000); return result;
    } catch (err) { return {error:'Could not generate IK keys on this device'}; }
  };
  App.generateParticles = function (options) {
    App.stopPlay(); const d=App.doc; if (!d) return 'No document';
    try {
      const error=d.generateParticles(options); if (error) return error;
      App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Particle layer created · Undo to remove'); return null;
    } catch (err) { return 'Could not generate particles on this device'; }
  };
  App.bakeTransform = function (source,start,end,easing,first,last,pivot) {
    App.stopPlay(); const d=App.doc; if (!d) return 'No document';
    try {
      const error=d.bakeTransform(source,start,end,easing,first,last,pivot); if (error) return error;
      App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Transform frames generated · Undo to restore'); return null;
    } catch (err) { return 'Could not generate transform frames on this device'; }
  };
  App.deleteFrameRange = function (start,end) {
    App.stopPlay(); const d=App.doc; if (!d || !d.deleteFrameRange(start,end)) return false;
    App.view.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Frames deleted · Undo to restore'); return true;
  };

  // Legacy programmatic flip retains its lock guard and shares the safe path.
  App.flipCanvas = function () {
    const d=App.doc;if(!d)return;
    if(d.layers.some(l=>l.locked || l.alphaLocked)){Q.toast('Unlock all layers and alpha before flipping the canvas');return;}
    const result=App.orientCanvas(App.canvasResizeTarget(),'horizontal');
    if(result.error)Q.toast(result.error,4000);else Q.toast('Canvas flipped · Undo to restore');
  };

  /* ── saving / exporting ─────────────────────────────────── */

  App.markDirty = function (immediate) {
    Q.UI.syncHistory();
    Q.UI.refreshReference();
    if (immediate) { App.saveNow(false); return; }
    clearTimeout(App.autosaveTimer);
    App.autosaveTimer = setTimeout(function () { App.saveNow(false); }, 2500);
  };

  App.saveNow = function (announce) {
    const d = App.doc;
    if (!d) return Promise.resolve(false);
    let thumb = null;
    try {
      thumb = d.thumbnail(d.activeFrame, 320).toDataURL('image/jpeg', 0.72);
    } catch (e) { thumb = null; }
    let save;
    try { save=Q.Store.save(d,thumb); }
    catch(err) { console.warn('save failed',err); if(announce) Q.toast('Could not save'); return Promise.resolve(false); }
    return save.then(function () {
      if (announce) Q.toast('Saved');
      return true;
    }).catch(function (err) {
      console.warn('save failed', err);
      if (announce) Q.toast('Could not save');
      return false;
    });
  };


  // Rectangle operations affect only the selected layer and current animation frame.
  App.editSelection = function (operation) {
    const d=App.doc, v=App.view;
    if (!d) return;
    const layer=d.layer();
    if (!layer || !layer.visible) { Q.toast('This layer is hidden'); return; }
    if (layer.locked) { Q.toast('This layer is locked'); return; }
    if (layer.alphaLocked && operation !== 'fill') { Q.toast('Turn off alpha lock for this edit'); return; }
    const sel=v.selection;
    if (sel && Q.complexSelection(sel) && (operation === 'flipH' || operation === 'flipV' || operation === 'rotate180')) {
      if(v.meshTransform) {Q.toast('Finish the current transform first');return;}
      const prepared=App.beginCanvasTransform();if(prepared.error){Q.toast(prepared.error,4000);return;}
      const t=v.meshTransform;t.sampling='nearest';t.flipX=operation!=='flipV';t.flipY=operation!=='flipH';
      const result=App.applyCanvasTransform();v.meshTransform=null;v.dirty=true;
      if(result.error) Q.toast(result.error,4000);else Q.toast('Selection flipped · Undo restores pixels',3000);return;
    }
    if (!sel && (operation === 'clear' || operation === 'fill')) { Q.toast('Draw a rectangle or select all first'); return; }
    const r=sel || {x:0,y:0,w:d.width,h:d.height};
    const cel=d.activeCel(operation === 'fill');
    if (!cel) { Q.toast('Draw on this layer first'); return; }
    const ctx=cel.getContext('2d');
    try {
      let image=null;
      if (operation === 'flipH' || operation === 'flipV' || operation === 'rotate180') {
        image=ctx.getImageData(r.x,r.y,r.w,r.h);
        Q.flipImage(image, operation !== 'flipV', operation !== 'flipH');
      } else if (operation !== 'clear' && operation !== 'fill') return;
      d.history.beginPixels(cel);
      if (image) ctx.putImageData(image,r.x,r.y);
      else {
        ctx.save(); ctx.setTransform(1,0,0,1,0,0); ctx.globalAlpha=1; ctx.globalCompositeOperation=layer.alphaLocked ? 'source-atop' : 'source-over';
        if (sel) { Q.selectionPath(ctx,sel); ctx.clip(); }
        if (operation === 'clear') ctx.clearRect(r.x,r.y,r.w,r.h);
        else { ctx.fillStyle=Q.rgbToHex(v.color); ctx.fillRect(r.x,r.y,r.w,r.h); }
        ctx.restore();
      }
      d.history.endPixels(r); v.dirty=true; App.markDirty(); Q.toast('Edit applied · Undo to revert');
    } catch (err) { Q.toast('Could not edit this area on this device',4000); }
  };

  App.copySelectionToLayer = function () {
    const d=App.doc, v=App.view; if (!d) return;
    if (!v.selection) { Q.toast('Draw a rectangle or select all first'); return; }
    if (!d.activeCel(false)) { Q.toast('Draw on this layer first'); return; }
    try {
      d.copyRegionToLayer(v.selection); v.dirty=true; Q.UI.syncDoc(); App.markDirty();
      Q.toast('Selection copied to a new layer · Undo to revert');
    } catch (err) { Q.toast('Could not copy selection on this device',4000); }
  };

  // Session-only clipboard of pixels from one layer and one frame, never the OS clipboard.
  App.copyOrCut = function (cut) {
    const d=App.doc,v=App.view; if(!d || App.playing || v.locked) return {error:'Stop playback or the current operation first'};
    const layer=d.layer(), cel=d.activeCel(false), sel=v.selection;
    if(!layer || !cel) return {error:'Draw on this layer first'};
    if(cut && !layer.visible) return {error:'This layer is hidden'};
    if(cut && layer.locked) return {error:'This layer is locked'};
    if(cut && layer.alphaLocked) return {error:'Turn off alpha lock before cutting'};
    const r=sel ? {x:sel.x,y:sel.y,w:sel.w,h:sel.h} : {x:0,y:0,w:d.width,h:d.height};
    if (![r.x,r.y,r.w,r.h].every(Number.isInteger) || r.x<0 || r.y<0 || r.w<1 || r.h<1 || r.x+r.w>d.width || r.y+r.h>d.height) return {error:'Choose a valid selection'};
    if (r.w*r.h*4*(cut ? 4 : 1)> (cut ? 64 : 32)*1024*1024) return {error:cut ? 'Cut exceeds the 64 MiB temporary-memory limit' : 'Copy exceeds the 32 MiB clipboard limit'};
    try {
      const copy=Q.canvas(r.w,r.h), cc=copy.getContext('2d'); cc.save();
      if(sel) { cc.translate(-r.x,-r.y); Q.selectionPath(cc,sel); cc.clip(); cc.drawImage(cel,r.x,r.y,r.w,r.h,r.x,r.y,r.w,r.h); }
      else cc.drawImage(cel,r.x,r.y,r.w,r.h,0,0,r.w,r.h); cc.restore();
      if(cut) {
        const stage=Q.canvas(r.w,r.h), sc=stage.getContext('2d'), ctx=cel.getContext('2d'); sc.drawImage(cel,r.x,r.y,r.w,r.h,0,0,r.w,r.h);
        if(sel) { sc.save(); sc.translate(-r.x,-r.y); sc.globalCompositeOperation='destination-out'; Q.selectionPath(sc,sel); sc.fillStyle='#000'; sc.fill(); sc.restore(); }
        else sc.clearRect(0,0,r.w,r.h);
        const before=ctx.getImageData(r.x,r.y,r.w,r.h), after=sc.getImageData(0,0,r.w,r.h);
        ctx.putImageData(after,r.x,r.y); d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:r,before:before}); v.dirty=true; App.markDirty();
      }
      App.clipboard={canvas:copy,x:r.x,y:r.y,w:r.w,h:r.h}; Q.toast(cut ? 'Cut · Undo restores the pixels' : 'Copied to Qelem clipboard',3000); return {};
    } catch(err) { return {error:'Could not '+(cut ? 'cut' : 'copy')+' this area on this device'}; }
  };
  App.pasteClipboard = function () {
    const d=App.doc,v=App.view, clip=App.clipboard;
    if(!d || App.playing || v.locked) return {error:'Stop playback or the current operation first'};
    if(!clip) return {error:'Copy or cut pixels first'};
    if(clip.x>=d.width || clip.y>=d.height) return {error:'Copied area is outside this canvas'};
    if(d.width*d.height*4>64*1024*1024) return {error:'Paste exceeds the 64 MiB new-cel limit'};
    try {
      const cv=Q.canvas(d.width,d.height); cv.getContext('2d').drawImage(clip.canvas,clip.x,clip.y);
      d.insertPastedLayer(cv); v.dirty=true; Q.UI.syncDoc(); Q.UI.refreshTimeline(); App.markDirty(); Q.toast('Pasted as a new top layer · Undo to remove',3500);
      return {cropped:clip.x+clip.w>d.width || clip.y+clip.h>d.height};
    } catch(err) { return {error:'Could not paste this area on this device'}; }
  };
  App.clearClipboard = function () { App.clipboard=null; };

  App.moveScaleSelection = function (dx, dy, scale) {
    const d=App.doc, v=App.view; if (!d) return;
    const layer=d.layer(), cel=d.activeCel(false);
    if (!layer || !layer.visible) { Q.toast('This layer is hidden'); return; }
    if (layer.locked) { Q.toast('This layer is locked'); return; }
    if (layer.alphaLocked) { Q.toast('Turn off alpha lock to transform'); return; }
    if (!cel) { Q.toast('Draw on this layer first'); return; }
    if (!Number.isInteger(dx) || !Number.isInteger(dy) || Math.abs(dx)>d.width*2 || Math.abs(dy)>d.height*2 || !Number.isFinite(scale) || scale<0.25 || scale>4) { Q.toast('Invalid transform'); return; }
    if (v.selection && Q.complexSelection(v.selection)) { Q.toast('Non-rectangular transforms are not yet supported; use a rectangle'); return; }
    const src=v.selection || {x:0,y:0,w:d.width,h:d.height};
    const dst={x:src.x+dx,y:src.y+dy,w:Math.max(1,Math.round(src.w*scale)),h:Math.max(1,Math.round(src.h*scale))};
    if (dx===0 && dy===0 && dst.w===src.w && dst.h===src.h) { Q.toast('Nothing changed'); return; }
    const x=Math.min(src.x,dst.x), y=Math.min(src.y,dst.y);
    const right=Math.max(src.x+src.w,dst.x+dst.w), bottom=Math.max(src.y+src.h,dst.y+dst.h);
    const rect=Q.intersectRect({x:x,y:y,w:right-x,h:bottom-y},{x:0,y:0,w:d.width,h:d.height});
    try {
      const copy=Q.canvas(src.w,src.h), temp=copy.getContext('2d'), ctx=cel.getContext('2d');
      temp.drawImage(cel,src.x,src.y,src.w,src.h,0,0,src.w,src.h);
      d.history.beginPixels(cel);
      ctx.save(); ctx.setTransform(1,0,0,1,0,0); ctx.globalAlpha=1; ctx.globalCompositeOperation='source-over';
      ctx.clearRect(src.x,src.y,src.w,src.h);
      ctx.drawImage(copy,0,0,src.w,src.h,dst.x,dst.y,dst.w,dst.h); ctx.restore();
      d.history.endPixels(rect);
      if (v.selection) v.selection=Q.intersectRect(dst,{x:0,y:0,w:d.width,h:d.height});
      v.dirty=true; App.markDirty(); Q.toast('Transform applied · Undo to revert');
    } catch (err) { Q.toast('Could not transform this area on this device',4000); }
  };

  // Render to a bounded staging canvas and prepare undo pixels before touching the cel.
  App.preciseTransform = function (o,target) {
    const d=App.doc,v=App.view; if(!d || !target || target.doc!==d || d.frames[d.activeFrame]!==target.frame || d.layer()!==target.layer || d.activeCel(false)!==target.cel || v.selection!==target.selection) return {error:'Artwork, frame, layer or selection changed; reopen the transform'};
    if(App.playing || v.locked) return {error:'Stop playback or the current operation first'};
    const layer=d.layer(),cel=d.activeCel(false); if(!layer.visible) return {error:'This layer is hidden'};
    if(layer.locked) return {error:'This layer is locked'}; if(layer.alphaLocked) return {error:'Turn off alpha lock to transform'};
    if(!cel) return {error:'Draw on this layer first'}; if(v.selection && Q.complexSelection(v.selection)) return {error:'Use a rectangular selection for this transform'};
    const src=v.selection || {x:0,y:0,w:d.width,h:d.height};
    if (src.x!==target.src.x || src.y!==target.src.y || src.w!==target.src.w || src.h!==target.src.h) return {error:'Selection changed; reopen the transform'};
    const plan=Q.planPreciseTransform(src,d.width,d.height,o); if(plan.error) return plan; if(plan.unchanged) return {error:'Nothing changed'};
    const r=plan.rect;
    try {
      const copy=Q.canvas(src.w,src.h), stage=Q.canvas(r.w,r.h), c=stage.getContext('2d'), ctx=cel.getContext('2d');
      copy.getContext('2d').drawImage(cel,src.x,src.y,src.w,src.h,0,0,src.w,src.h);
      c.drawImage(cel,r.x,r.y,r.w,r.h,0,0,r.w,r.h); c.clearRect(src.x-r.x,src.y-r.y,src.w,src.h);
      c.save(); c.translate(plan.cx-r.x,plan.cy-r.y); c.rotate(plan.theta); c.imageSmoothingEnabled=o.resampling==='smooth'; c.drawImage(copy,0,0,src.w,src.h,-o.width/2,-o.height/2,o.width,o.height); c.restore();
      const before=ctx.getImageData(r.x,r.y,r.w,r.h), after=c.getImageData(0,0,r.w,r.h);
      ctx.putImageData(after,r.x,r.y); d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:r,before:before});
      if(v.selection) v.selection=Q.intersectRect(plan.bounds,{x:0,y:0,w:d.width,h:d.height});
      v.dirty=true; App.markDirty(); Q.toast('Transform applied · Undo to revert',3000); return {clipped:plan.clipped};
    } catch(err) { return {error:'Could not transform this area on this device'}; }
  };

  // Canvas mesh transform stages output before changing the cel. The session
  // keeps no artwork changes until Apply; the mesh itself is temporary.
  App.beginCanvasTransform = function () {
    const d=App.doc,v=App.view; if(!d || !v || App.playing || v.locked) return {error:'Stop playback or the current operation first'};
    const layer=d.layer(),cel=d.activeCel(false),sel=v.selection;
    if(!layer || !layer.visible || layer.locked || layer.alphaLocked) return {error:'Show and unlock the layer and turn off alpha lock'};
    if(!cel) return {error:'Draw on this layer first'};
    const src=sel ? {x:sel.x,y:sel.y,w:sel.w,h:sel.h} : {x:0,y:0,w:d.width,h:d.height};
    if(![src.x,src.y,src.w,src.h].every(Number.isInteger) || src.x<0 || src.y<0 || src.w<1 || src.h<1 || src.x+src.w>d.width || src.y+src.h>d.height) return {error:'Invalid selection bounds'};
    if(src.w*src.h>2*1024*1024) return {error:'Select an area up to 2 megapixels'};
    try {
      const mask=sel && Q.complexSelection(sel) ? Q.selectionMask(sel) : null;
      if(mask && !mask.some(Boolean)) return {error:'Selection is empty'};
      v.meshTransform={doc:d,frame:d.frames[d.activeFrame],layer:layer,cel:cel,selection:sel,selectionSignature:sel ? JSON.stringify(sel) : null,mask:mask,src:src,points:Q.transformGrid(src),mode:'uniform',sampling:'smooth',flipX:false,flipY:false,undo:d.history.undoStack.slice(),redo:d.history.redoStack.slice()}; v.dirty=true; return {};
    } catch(err) {return {error:'Could not prepare the selection on this device'};}
  };
  App.applyCanvasTransform = function () {
    const d=App.doc,v=App.view,t=v && v.meshTransform;
    if(!t || !d || t.doc!==d || d.frames[d.activeFrame]!==t.frame || d.layer()!==t.layer || d.activeCel(false)!==t.cel || v.selection!==t.selection || App.playing || v.locked || !t.layer.visible || t.layer.locked || t.layer.alphaLocked || (t.selection && JSON.stringify(t.selection)!==t.selectionSignature) || t.undo.length!==d.history.undoStack.length || t.redo.length!==d.history.redoStack.length || t.undo.some((e,i)=>d.history.undoStack[i]!==e) || t.redo.some((e,i)=>d.history.redoStack[i]!==e)) return {error:'Artwork changed; cancel and reopen transform'};
    const plan=Q.planMeshTransform(t.src,t.points,d.width,d.height,t.flipX || t.flipY); if(plan.error) return plan;
    const r=plan.rect,src=t.src,ctx=t.cel.getContext('2d');
    try {
      const result=t.selection ? Q.meshSelection(src,t.mask,t.points,r,{x:t.flipX,y:t.flipY}) : null;
      if(result && result.error) return result;
      const image=ctx.getImageData(src.x,src.y,src.w,src.h);
      if(t.mask) for(let n=0;n<t.mask.length;n++) if(!t.mask[n]) {const i=n*4;image.data[i]=image.data[i+1]=image.data[i+2]=image.data[i+3]=0;}
      const warped=Q.rasterMesh(image,t.points,r,t.sampling,{x:t.flipX,y:t.flipY}), warp=Q.canvas(r.w,r.h), wc=warp.getContext('2d'), output=wc.createImageData(r.w,r.h); output.data.set(warped); wc.putImageData(output,0,0);
      const before=ctx.getImageData(r.x,r.y,r.w,r.h),stage=Q.canvas(r.w,r.h),sc=stage.getContext('2d');sc.putImageData(before,0,0);
      if(t.mask) {
        const base=sc.getImageData(0,0,r.w,r.h),data=base.data;
        for(let y=0;y<src.h;y++) for(let x=0;x<src.w;x++) if(t.mask[y*src.w+x]) {const i=((src.y+y-r.y)*r.w+src.x+x-r.x)*4;data[i]=data[i+1]=data[i+2]=data[i+3]=0;}
        sc.putImageData(base,0,0);
      } else sc.clearRect(src.x-r.x,src.y-r.y,src.w,src.h);
      sc.drawImage(warp,0,0);
      const after=sc.getImageData(0,0,r.w,r.h);
      try {ctx.putImageData(after,r.x,r.y);} catch(err) {try {ctx.putImageData(before,r.x,r.y);} catch(ignore) {} throw err;}
      d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:r,before:before}); if(result) v.selection=result.selection; v.dirty=true; App.markDirty(); return {};
    } catch(err) { return {error:'Could not transform this area on this device'}; }
  };

  // Visible composite samples ignore the canvas background and playback-only
  // transforms, but honor layer visibility, opacity, blend modes and clipping.
  function fillSourceImage(d,frame,cel,bounds,source) {
    if(source==='active') return cel ? cel.getContext('2d').getImageData(bounds.x,bounds.y,bounds.w,bounds.h) : Q.canvas(bounds.w,bounds.h).getContext('2d').getImageData(0,0,bounds.w,bounds.h);
    if(source==='reference') { const index=d.layers.findIndex(l=>l.reference), ref=index<0 ? null : d.cel(frame,index,false); if(!ref) throw new Error('Reference layer has no cel in this frame');return ref.getContext('2d').getImageData(bounds.x,bounds.y,bounds.w,bounds.h); }
    const cv=Q.canvas(bounds.w,bounds.h), ctx=cv.getContext('2d'); ctx.translate(-bounds.x,-bounds.y); d.composite(ctx,frame); ctx.setTransform(1,0,0,1,0,0); return ctx.getImageData(0,0,bounds.w,bounds.h);
  }
  function fillMemoryAllowed(d,bounds,source,scope,selection) {
    if(source==='active' && scope==='connected') return true; // Keep the legacy default available for large artworks.
    const docPixels=d.width*d.height, area=bounds.w*bounds.h;
    if(area>4*1024*1024 || (source==='visible' && docPixels>4*1024*1024)) return false;
    const clip=source==='visible' && d.layers.some(l=>l.clipped && l.visible) ? 4*docPixels : 0;
    // Conservative allowance for sampled and destination canvases, image data,
    // queues, undo, transient readbacks and a newly-created full-size cel.
    return area*32+(selection && Q.complexSelection(selection) ? 9*area : 0)+clip+4*docPixels<=64*1024*1024;
  }
  function captureFillState(d,frame,source) {
    const f=d.frames[frame]; return {undo:d.history.undoStack.slice(),redo:d.history.redoStack.slice(),layers:source!=='active' ? d.layers.map((l,i)=>({id:l.id,visible:l.visible,opacity:l.opacity,blend:l.blend,clipped:l.clipped,reference:!!l.reference,cel:f.cels[i]})) : null};
  }
  function fillStateUnchanged(d,frame,state) {
    const h=d.history; if(state.undo.length!==h.undoStack.length || state.redo.length!==h.redoStack.length || state.undo.some((e,i)=>h.undoStack[i]!==e) || state.redo.some((e,i)=>h.redoStack[i]!==e)) return false;
    return !state.layers || (state.layers.length===d.layers.length && state.layers.every((s,i)=>{const l=d.layers[i]; return l.id===s.id && l.visible===s.visible && l.opacity===s.opacity && l.blend===s.blend && l.clipped===s.clipped && !!l.reference===s.reference && d.frames[frame].cels[i]===s.cel;}));
  }
  function closeFillProgress(node) { if(!node || document.getElementById('progressCard')===node) Q.UI.endProgress(); }

  // Select alpha from the active cel only; visibility/opacity of other layers and
  // the canvas background do not alter the mask. No artwork pixels are modified.
  App.selectLayerContents = function(operation) {
    const d=App.doc,v=App.view; if(!d || !v || v.locked) return;
    const layer=d.layer(),cel=d.activeCel(false),frame=d.activeFrame,index=d.activeLayer,frameObj=d.frames[frame],selection=v.selection,snapshot=JSON.stringify(selection);
    if(!layer || !layer.visible) {Q.toast('This layer is hidden');return;}
    if(!cel) {Q.toast('Layer has no nontransparent pixels');return;}
    if(!['replace','add','subtract','intersect'].includes(operation)) {Q.toast('Invalid selection operation');return;}
    if(operation!=='replace' && !selection) {Q.toast('Make a selection first');return;}
    if(d.width*d.height>4*1024*1024) {Q.toast('Canvas exceeds the 4 megapixel selection limit',4000);return;}
    const state=captureFillState(d,frame,'active');v.locked=true;Q.UI.progress('Selecting','Reading layer contents…',0);
    const progressNode=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try {
      if(App.doc!==d || App.view!==v || d.frames[frame]!==frameObj || d.activeFrame!==frame || d.activeLayer!==index || d.layer()!==layer || d.activeCel(false)!==cel || !layer.visible || v.selection!==selection || JSON.stringify(v.selection)!==snapshot || !fillStateUnchanged(d,frame,state)) {Q.toast('Selection cancelled');return;}
      const result=Q.selectionFromAlpha(cel.getContext('2d').getImageData(0,0,d.width,d.height));
      if(result.error) {Q.toast(result.error,4000);return;}
      const combined=operation==='replace' ? {selection:result} : Q.combineSelections(selection,result,operation,d.width,d.height);
      if(combined.error) {Q.toast(combined.error,4000);return;} v.selection=combined.selection;v.selectionDraft=null;v.dirty=true;Q.toast('Layer contents selected',2500);
    } catch(e) {Q.toast('Could not select layer contents',4000);} finally {closeFillProgress(progressNode);if(App.view===v && App.doc===d && !App.playing)v.locked=false;}},40);
  };

  App.resizeSelection = function(mode,radius) {
    const d=App.doc,v=App.view; if(!d || !v || v.locked) return;
    const selection=v.selection,snapshot=JSON.stringify(selection); if(!selection) {Q.toast('Make a selection first');return;}
    v.locked=true;Q.UI.progress('Updating selection','Adjusting selection edges…',0);const progressNode=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try {
      if(App.doc!==d || App.view!==v || v.selection!==selection || JSON.stringify(v.selection)!==snapshot) {Q.toast('Selection cancelled');return;}
      const result=Q.resizeSelectionMask(selection,d.width,d.height,radius,mode);
      if(result.error) {Q.toast(result.error,4000);return;} v.selection=result.selection;v.selectionDraft=null;v.dirty=true;Q.toast('Selection updated',2500);
    } catch(e) {Q.toast('Could not resize selection',4000);} finally {closeFillProgress(progressNode);if(App.view===v && App.doc===d && !App.playing)v.locked=false;}},40);
  };

  // One ephemeral selection slot; deliberately never stored in the project.
  App.hasSavedSelection = function () {const s=App.selectionStash,d=App.doc;return !!(s && d && s.doc===d && s.width===d.width && s.height===d.height);};
  App.saveSelection = function () {
    const d=App.doc,v=App.view;if(!d || !v || !v.selection)return {error:'Make a selection first'};
    if(v.locked || v.stroke || v.quickShape || v.meshTransform || App.playing)return {error:'Finish the current operation first'};
    try{const json=JSON.stringify(v.selection);if(!json || json.length>512*1024)return {error:'Selection is too large to save temporarily'};JSON.parse(json);App.selectionStash={doc:d,width:d.width,height:d.height,json:json};return {};}
    catch(e){return {error:'Could not save selection temporarily'};}
  };
  App.restoreSelection = function () {
    const v=App.view;if(!App.hasSavedSelection() || !v)return {error:'No saved selection for this artwork'};
    if(v.locked || v.stroke || v.quickShape || v.meshTransform || App.playing)return {error:'Finish the current operation first'};
    try {const selection=JSON.parse(App.selectionStash.json);v.selection=selection;v.selectionDraft=null;v.selectionOperation='replace';v.dirty=true;return {};}
    catch(e){return {error:'Could not restore selection'};}
  };
  App.borderSelection = function(side,radius) {
    const d=App.doc,v=App.view;if(!d || !v || v.locked || App.playing || v.stroke || v.quickShape || v.meshTransform)return {error:'Finish the current operation first'};
    const selection=v.selection;if(!selection)return {error:'Make a selection first'};
    const snapshot=JSON.stringify(selection),width=d.width,height=d.height;v.locked=true;Q.UI.progress('Selection border','Building the hard-edged border…',0);const node=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try{
      if(App.doc!==d || App.view!==v || d.width!==width || d.height!==height || v.selection!==selection || JSON.stringify(v.selection)!==snapshot || App.playing){Q.toast('Selection changed; border cancelled',4000);return;}
      const result=Q.selectionBorder(selection,width,height,radius,side);if(result.error){Q.toast(result.error,4000);return;}v.selection=result.selection;v.selectionDraft=null;v.selectionOperation='replace';v.dirty=true;Q.toast('Border selected · dashed box shows bounds',3000);
    }catch(e){Q.toast('Could not build selection border',4000);}finally{closeFillProgress(node);if(App.view===v && App.doc===d && !App.playing)v.locked=false;}},40);return {started:true};
  };

  App.wandAt = function (x,y) {
    const d=App.doc, v=App.view; if(!d || v.locked || x<0 || y<0 || x>=d.width || y>=d.height) return;
    const layer=d.layer(), cel=d.activeCel(false), frame=d.activeFrame, layerIndex=d.activeLayer, frameObj=d.frames[frame], source=['visible','reference'].includes(App.fillSource) ? App.fillSource : 'active', scope=App.fillScope==='all' ? 'all' : 'connected', tolerance=App.fillThreshold;
    if(!layer || !layer.visible) { Q.toast('This layer is hidden'); return; }
    const bounds={x:0,y:0,w:d.width,h:d.height}, selection=v.selection, selectionSnapshot=JSON.stringify(v.selection), operation=v.selectionOperation || 'replace'; v.selectionOperation='replace';
    if(operation!=='replace' && !selection) { Q.toast('Make a selection first'); return; }
    if(operation!=='replace' && d.width*d.height>4*1024*1024) { Q.toast('Canvas exceeds the 4 megapixel selection-combine limit',4000); return; }
    if(!fillMemoryAllowed(d,bounds,source,scope,null)) { Q.toast('Selection exceeds the sampling memory limit',4000); return; }
    if(source==='reference' && !d.layers.some((l,i)=>l.reference && !!d.cel(frame,i,false))) { Q.toast('Set a reference layer with a cel on this frame',4000); return; }
    const state=captureFillState(d,frame,source); v.locked=true; Q.UI.progress('Selecting',source==='visible' ? 'Sampling visible layers…' : source==='reference' ? 'Sampling reference layer…' : 'Finding matching pixels…',0);
    const progressNode=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function () { try {
      if(App.doc!==d || App.view!==v || d.frames[frame]!==frameObj || d.activeFrame!==frame || d.activeLayer!==layerIndex || d.layer()!==layer || d.activeCel(false)!==cel || v.selection!==selection || JSON.stringify(v.selection)!==selectionSnapshot || !layer.visible || !fillStateUnchanged(d,frame,state)) { Q.toast('Selection cancelled'); return; }
      const image=fillSourceImage(d,frame,cel,bounds,source);
      const result=source==='active' && scope==='connected' ? Q.floodSelect(image,x,y,tolerance) : Q.selectionFromRegion(Q.matchColorRegion(image,x,y,tolerance,scope,null,null),d.width,d.height,0,0);
      if(result && result.error) { Q.toast(result.error,4000); return; }
      if(result) { const combined=operation==='replace' ? {selection:result} : Q.combineSelections(selection,result,operation,d.width,d.height); if(combined.error) {Q.toast(combined.error,4000);return;} v.selection=combined.selection; v.dirty=true; Q.toast('Matching area selected · Menu → Selection & transform',3000); }
      else Q.toast('No matching pixels selected');
    } catch(e) { Q.toast('Could not select this area',4000); } finally { closeFillProgress(progressNode); if(App.view===v && App.doc===d && !App.playing) v.locked=false; } },40);
  };

  App.fillAt = function (x, y, droppedColor) {
    const d=App.doc,v=App.view; if(!d || !v || v.locked || x<0 || y<0 || x>=d.width || y>=d.height) return;
    const layer=d.layer(); if(!layer || !layer.visible) { Q.toast('This layer is hidden'); return; } if(layer.locked) { Q.toast('This layer is locked'); return; }
    const selection=v.selection, selectionSignature=selection ? JSON.stringify(selection) : null, bounds=selection ? {...selection} : {x:0,y:0,w:d.width,h:d.height};
    if(x<bounds.x || y<bounds.y || x>=bounds.x+bounds.w || y>=bounds.y+bounds.h) { Q.toast('Tap inside the selection'); return; }
    const source=['visible','reference'].includes(App.fillSource) ? App.fillSource : 'active', scope=App.fillScope==='all' ? 'all' : 'connected';
    if(!fillMemoryAllowed(d,bounds,source,scope,selection)) { Q.toast('Fill exceeds the sampling memory limit',4000); return; }
    const originalCel=d.activeCel(false), color=(droppedColor || v.color).slice(), tolerance=App.fillThreshold, alphaLocked=!!layer.alphaLocked, frame=d.activeFrame, frameObj=d.frames[frame], layerIndex=d.activeLayer;
    if(source==='reference' && !d.layers.some((l,i)=>l.reference && !!d.cel(frame,i,false))) { Q.toast('Set a reference layer with a cel on this frame',4000); return; }
    const state=captureFillState(d,frame,source); v.locked=true; Q.UI.progress('Filling',source==='visible' ? 'Sampling visible layers…' : source==='reference' ? 'Sampling reference layer…' : 'Processing the current layer…',0);
    const progressNode=document.getElementById ? document.getElementById('progressCard') : null; if(progressNode && progressNode.classList) progressNode.classList.add('fill-progress');
    function valid() {return App.doc===d && App.view===v && d.frames[frame]===frameObj && d.activeFrame===frame && d.activeLayer===layerIndex && d.layer()===layer && d.activeCel(false)===originalCel && v.selection===selection && layer.visible && !layer.locked && !!layer.alphaLocked===alphaLocked && !App.playing && fillStateUnchanged(d,frame,state);}
    setTimeout(async function () { try {
      if(!valid()) { Q.toast('Fill cancelled'); return; }
      const image=fillSourceImage(d,frame,originalCel,bounds,'active'), mask=Q.selectionMask(bounds);
      let rect;
      if(source==='active' && scope==='connected') rect=await Q.floodFillAsync(image,x-bounds.x,y-bounds.y,color,tolerance,alphaLocked,mask,valid);
      else {
        const ref=source==='active' ? image : fillSourceImage(d,frame,originalCel,bounds,source);
        const region=Q.matchColorRegion(ref,x-bounds.x,y-bounds.y,tolerance,scope,mask,alphaLocked ? image.data : null);
        rect=Q.fillColorRegion(image,region,color,alphaLocked);
      }
      if(!valid() || (selection && JSON.stringify(selection)!==selectionSignature)) { Q.toast('Fill cancelled'); return; }
      if(rect) {
        const changed={x:rect.x+bounds.x,y:rect.y+bounds.y,w:rect.w,h:rect.h};
        // Acquire undo pixels before committing. A failed read or write cannot
        // leave an unrecorded fill; no full-canvas snapshot is required.
        const before=originalCel ? originalCel.getContext('2d').getImageData(changed.x,changed.y,changed.w,changed.h) : Q.canvas(changed.w,changed.h).getContext('2d').getImageData(0,0,changed.w,changed.h);
        const cel=originalCel || d.activeCel(true), ctx=cel.getContext('2d');
        try { ctx.putImageData(image,bounds.x,bounds.y,rect.x,rect.y,rect.w,rect.h); } catch(err) { if(!originalCel) frameObj.cels[layerIndex]=null; else try { ctx.putImageData(before,changed.x,changed.y); } catch(ignore) {} throw err; }
        d.history.push({type:'pixels',f:frame,l:layerIndex,rect:changed,before:before}); v.dirty=true; App.markDirty();
      }
      Q.toast(rect ? 'Filled · Undo to revert' : 'Nothing to fill');
    } catch (err) { Q.toast(err && err.message==='fill cancelled' ? 'Fill cancelled' : 'Could not fill this canvas',4000); }
    finally { closeFillProgress(progressNode); if(App.view===v && App.doc===d && !App.playing) v.locked=false; }
    },40);
  };

  // Recolour raw pixels of one current cel, bounded by selection and memory.
  App.validateRecolor = function (target, source, replacement, tolerance) {
    const d=App.doc, v=App.view;
    if(!d || !target || target.doc!==d || d.frames[d.activeFrame]!==target.frame || d.layer()!==target.layer || d.activeCel(false)!==target.cel || v.selection!==target.selection || App.playing) return {error:'Artwork, frame, layer or selection changed; reopen recolour'};
    if(!target.cel) return {error:'Draw on this layer first'};
    if(!target.layer.visible || target.layer.locked) return {error:'Show and unlock this layer first'};
    if(!Array.isArray(source) || !Array.isArray(replacement) || source.length!==3 || replacement.length!==3 || !source.concat(replacement).every(n=>Number.isInteger(n) && n>=0 && n<=255) || !Number.isInteger(tolerance) || tolerance<0 || tolerance>128) return {error:'Enter valid colours and tolerance'};
    const r=target.bounds, s=v.selection;
    if(!r || ![r.x,r.y,r.w,r.h].every(Number.isInteger) || r.x<0 || r.y<0 || r.w<1 || r.h<1 || r.x+r.w>d.width || r.y+r.h>d.height || (s && (s.x!==r.x || s.y!==r.y || s.w!==r.w || s.h!==r.h))) return {error:'Selection changed; reopen recolour'};
    const complex=!!(s && Q.complexSelection(s));
    if(4*d.width*d.height+(complex ? 13 : 8)*r.w*r.h>64*1024*1024) return {error:'Recolour exceeds the 64 MiB temporary-memory limit'};
    if(target.undo.length!==d.history.undoStack.length || target.redo.length!==d.history.redoStack.length || target.undo.some((e,i)=>e!==d.history.undoStack[i]) || target.redo.some((e,i)=>e!==d.history.redoStack[i])) return {error:'Artwork changed; reopen recolour'};
    return {};
  };
  App.recolorMatching = function (target,source,replacement,tolerance) {
    const check=App.validateRecolor(target,source,replacement,tolerance); if(check.error) return check;
    const d=App.doc,v=App.view, r=target.bounds; v.locked=true; Q.UI.progress('Recolouring','Processing the current layer…',0);
    const progressNode=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function() {
      try {
        const valid=App.validateRecolor(target,source,replacement,tolerance); if(valid.error) { Q.toast(valid.error,4000); return; }
        const ctx=target.cel.getContext('2d'), image=ctx.getImageData(r.x,r.y,r.w,r.h), mask=target.selection ? Q.selectionMask(target.selection) : null;
        const rect=Q.recolorMatching(image,source,replacement,tolerance,mask);
        if(rect) {
          // Acquire undo data before touching the cel, so an allocation failure
          // cannot leave an unrecorded edit.
          const changed={x:r.x+rect.x,y:r.y+rect.y,w:rect.w,h:rect.h};
          d.history.beginPixels(target.cel);
          const before=d.history.snapCtx.getImageData(changed.x,changed.y,changed.w,changed.h);
          try { ctx.putImageData(image,r.x,r.y,rect.x,rect.y,rect.w,rect.h); }
          catch(err) { try { ctx.putImageData(before,changed.x,changed.y); } catch(ignored) {} throw err; }
          d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:changed,before:before});
          v.dirty=true; Q.UI.syncDoc(); App.markDirty();
        }
        Q.toast(rect ? 'Recoloured · Undo to restore' : 'No matching pixels changed');
      } catch(err) { Q.toast('Could not recolour on this device',4000); }
      finally { if(!progressNode || document.getElementById('progressCard')===progressNode) Q.UI.endProgress(); if(App.view===v && App.doc===d && !App.playing) v.locked=false; }
    },40);
    return {started:true};
  };

  App.paperTextureTarget = function(){const target=App.canvasResizeTarget();if(target)target.frameIndex=App.doc.activeFrame;return target;};
  App.validatePaperTexture = function(target,o,allowLocked){
    const valid=App.validateCanvasTarget(target,allowLocked);if(valid.error)return valid;const d=App.doc;
    if(target.frameIndex!==d.activeFrame)return {error:'Frame changed; reopen texture'};
    if(!o || !Q.PAPER_TEXTURES.some(t=>t[0]===o.type) || !Array.isArray(o.color) || o.color.length!==3 || o.color.some(n=>!Number.isInteger(n)||n<0||n>255) || !Number.isFinite(o.strength) || o.strength<=0 || o.strength>1 || ![.5,1,2,4].includes(o.scale) || !['current','all'].includes(o.scope))return {error:'Choose valid texture settings and strength'};
    if(d.layers.length>=128)return {error:'Texture would exceed the 128-layer limit'};
    const count=o.scope==='all' ? d.frames.length : 1, pixels=d.width*d.height;
    if(pixels>8*1024*1024 || pixels*4*(count+1)>64*1024*1024)return {error:'Texture exceeds 8 MP or estimated 64 MiB new-buffer limit'};
    return {count:count};
  };
  App.addPaperTexture = function(target,options){
    const valid=App.validatePaperTexture(target,options,false);if(valid.error)return valid;const d=App.doc,v=App.view,o={...options,color:options.color.slice()};
    v.locked=true;Q.UI.progress('Creating texture','Preparing independent texture cels…',0);const node=document.getElementById('progressCard');
    setTimeout(async function(){try{
      let check=App.validatePaperTexture(target,o,true);if(check.error)throw Error(check.error);
      const tile=Q.makePaperTile(o.type,o.color,o.strength),template=Q.canvas(d.width,d.height);Q.fillPaperTexture(template.getContext('2d'),tile,d.width,d.height,o.scale);
      const layer=Q.makeLayer(Q.PAPER_TEXTURES.find(t=>t[0]===o.type)[1]+' texture');layer.blend='multiply';if(d.layers.some(l=>l.id===layer.id))throw Error('Could not create a unique layer ID');const cels=[];
      for(let i=0;i<d.frames.length;i++){check=App.validatePaperTexture(target,o,true);if(check.error)throw Error(check.error);cels.push(o.scope==='all'||i===target.frameIndex ? Q.copyCanvas(template) : null);if(o.scope==='all')await new Promise(resolve=>setTimeout(resolve,0));}
      check=App.validatePaperTexture(target,o,true);if(check.error)throw Error(check.error);
      d.history.struct(function(){this.layers.push(layer);this.frames.forEach((f,i)=>f.cels.push(cels[i]));this.activeLayer=this.layers.length-1;});v.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();Q.UI.refreshLayersIfOpen();App.markDirty();Q.toast('Texture layer added · Undo to remove',4000);
    }catch(e){Q.toast('Texture cancelled: '+(e.message || 'not enough memory'),5000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);return {started:true};
  };

  App.outlineTarget = function(){const t=App.canvasResizeTarget();if(t){t.frameIndex=App.doc.activeFrame;t.layerIndex=App.doc.activeLayer;}return t;};
  App.validateOutline = function(t,o,allowLocked){
    const valid=App.validateCanvasTarget(t,allowLocked);if(valid.error)return valid;const d=App.doc;
    if(d.activeFrame!==t.frameIndex||d.activeLayer!==t.layerIndex)return {error:'Frame or layer changed; reopen Outline'};
    const layer=d.layer(),cel=d.activeCel(false);if(!cel || !layer.visible)return {error:'Show a layer with artwork first'};
    if(!o || !Number.isInteger(o.radius)||o.radius<1||o.radius>32||!Array.isArray(o.color)||o.color.length!==3||o.color.some(v=>!Number.isInteger(v)||v<0||v>255)||!Number.isFinite(o.opacity)||o.opacity<=0||o.opacity>1)return {error:'Choose valid outline settings'};
    if(d.layers.length>=128)return {error:'Outline would exceed the 128-layer limit'};
    const pixels=d.width*d.height;if(pixels>4*1024*1024 || pixels*32>64*1024*1024)return {error:'Outline exceeds 4 MP or estimated 64 MiB new-buffer limit'};
    return {};
  };
  App.addOutline = function(t,options){
    const valid=App.validateOutline(t,options,false);if(valid.error)return valid;const d=App.doc,v=App.view,o={...options,color:options.color.slice()};v.locked=true;Q.UI.progress('Creating outline','Preparing the current cel…',0);const node=document.getElementById('progressCard');
    setTimeout(function(){try{
      let check=App.validateOutline(t,o,true);if(check.error)throw Error(check.error);const source=d.activeCel(false).getContext('2d').getImageData(0,0,d.width,d.height),canvas=Q.canvas(d.width,d.height),ctx=canvas.getContext('2d'),output=ctx.createImageData(d.width,d.height),changed=Q.outlineAlpha(source,output,o.radius,o.color,o.opacity);
      check=App.validateOutline(t,o,true);if(check.error)throw Error(check.error);if(!changed){Q.toast('No outline pixels fit on the canvas',4000);return;}ctx.putImageData(output,0,0);
      const layer=Q.makeLayer('Outline');if(d.layers.some(l=>l.id===layer.id))throw Error('Could not create a unique layer ID');d.history.struct(function(){this.layers.push(layer);this.frames.forEach((f,i)=>f.cels.push(i===t.frameIndex ? canvas : null));this.activeLayer=this.layers.length-1;});v.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();Q.UI.refreshLayersIfOpen();App.markDirty();Q.toast('Outline layer added · Undo to remove',4000);
    }catch(e){Q.toast('Outline cancelled: '+(e.message || 'not enough memory'),5000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);return {started:true};
  };

  // One atomic, undoable colour-effect pass across existing cels of one layer.
  Q.ANIMATION_EFFECTS=['grayscale','invert','sepia','brightness','saturation','contrast','hue','threshold','posterize','solarize'];
  App.animationEffectTarget = function () {
    const d=App.doc,v=App.view;if(!d || !v)return null;const selection=v.selection;
    return {doc:d,view:v,width:d.width,height:d.height,layer:d.layer(),layerIndex:d.activeLayer,frames:d.frames.slice(),cels:d.frames.map(f=>f.cels[d.activeLayer]),skipped:d.frames.map(f=>!!f.skipped),selection:selection,signature:selection ? JSON.stringify(selection) : null,undo:d.history.undoStack.slice(),redo:d.history.redoStack.slice()};
  };
  App.validateAnimationEffect = function(t,o,allowLocked) {
    const d=App.doc,v=App.view;if(!t || !d || !v || t.doc!==d || t.view!==v || d.width!==t.width || d.height!==t.height || d.activeLayer!==t.layerIndex || d.layer()!==t.layer || d.frames.length!==t.frames.length || t.frames.some((f,i)=>d.frames[i]!==f || f.cels[t.layerIndex]!==t.cels[i] || !!f.skipped!==t.skipped[i]) || v.selection!==t.selection || (t.selection && JSON.stringify(t.selection)!==t.signature))return {error:'Artwork, layer, frames or selection changed; reopen the dialog'};
    const h=d.history;if(h.undoStack.length!==t.undo.length || h.redoStack.length!==t.redo.length || t.undo.some((e,i)=>e!==h.undoStack[i]) || t.redo.some((e,i)=>e!==h.redoStack[i]))return {error:'Artwork changed; reopen the dialog'};
    if(App.playing || (v.locked && !allowLocked) || v.stroke || v.quickShape || v.meshTransform)return {error:'Finish playback or the current operation first'};
    if(!t.layer.visible || t.layer.locked)return {error:'Show and unlock the active layer first'};
    if(!o || !Number.isInteger(o.start) || !Number.isInteger(o.end) || o.start<0 || o.end<o.start || o.end>=d.frames.length || !Q.ANIMATION_EFFECTS.includes(o.effect) || !Number.isFinite(o.from) || !Number.isFinite(o.to) || o.from<0 || o.from>1 || o.to<0 || o.to>1 || !['linear','in','out','inout'].includes(o.easing) || typeof o.includeSkipped!=='boolean')return {error:'Choose valid range, effect and strengths'};
    if(o.from===0 && o.to===0)return {error:'Choose a nonzero strength'};
    const r=t.selection ? {x:t.selection.x,y:t.selection.y,w:t.selection.w,h:t.selection.h} : {x:0,y:0,w:d.width,h:d.height};
    if(![r.x,r.y,r.w,r.h].every(Number.isInteger) || r.x<0 || r.y<0 || r.w<1 || r.h<1 || r.x+r.w>d.width || r.y+r.h>d.height)return {error:'Invalid selection bounds'};
    const indices=[];for(let i=o.start;i<=o.end;i++)if(t.cels[i] && (o.includeSkipped || !t.skipped[i]))indices.push(i);
    if(!indices.length)return {error:'No eligible cels in the selected range'};
    const area=r.w*r.h,bytes=d.width*d.height*4*indices.length+area*24;
    if(area>4*1024*1024 || bytes>64*1024*1024)return {error:'Effect exceeds the 4 MP area or estimated 64 MiB new-buffer limit'};
    return {bounds:r,indices:indices};
  };
  App.applyAnimationEffect = function(t,o) {
    const check=App.validateAnimationEffect(t,o,false);if(check.error)return check;
    const d=t.doc,v=t.view,settings={...o},r=check.bounds,indices=check.indices;v.locked=true;Q.UI.progress('Animation effects','Preparing cels without changing the originals…',0);const node=document.getElementById('progressCard');
    setTimeout(async function(){try {
      const mask=t.selection ? Q.selectionMask(t.selection) : null,copies=[];
      for(const i of indices){const valid=App.validateAnimationEffect(t,settings,true);if(valid.error)throw Error(valid.error);
        const u=settings.end===settings.start ? 0 : (i-settings.start)/(settings.end-settings.start),strength=settings.from+(settings.to-settings.from)*Q.motionEase(u,settings.easing);if(strength<=0)continue;
        const src=t.cels[i],ctx=src.getContext('2d'),before=ctx.getImageData(r.x,r.y,r.w,r.h),stage=ctx.createImageData(r.w,r.h);stage.data.set(before.data);Q.applyPixelEffect(stage,settings.effect,strength);let changed=false;
        for(let n=0;n<r.w*r.h;n++){const k=n*4;if(!before.data[k+3] || (mask && !mask[n])){stage.data[k]=before.data[k];stage.data[k+1]=before.data[k+1];stage.data[k+2]=before.data[k+2];}stage.data[k+3]=before.data[k+3];if(stage.data[k]!==before.data[k] || stage.data[k+1]!==before.data[k+1] || stage.data[k+2]!==before.data[k+2])changed=true;}
        if(changed){const cv=Q.copyCanvas(src);cv.getContext('2d').putImageData(stage,r.x,r.y);copies.push([i,cv]);}
        await new Promise(resolve=>setTimeout(resolve,0));
      }
      const valid=App.validateAnimationEffect(t,settings,true);if(valid.error)throw Error(valid.error);
      if(copies.length){d.history.struct(function(){copies.forEach(([i,cv])=>{this.frames[i].cels[t.layerIndex]=cv;});});v.dirty=true;Q.UI.syncDoc();Q.UI.refreshTimeline();App.markDirty();}
      Q.toast(copies.length ? 'Effect applied to '+copies.length+' cels · Undo to restore' : 'No pixels changed',4000);
    }catch(e){Q.toast('Animation effect cancelled: '+(e.message || 'not enough memory'),5000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);
    return {started:true};
  };

  App.gradientMapTarget = function () {
    const d=App.doc,v=App.view;if(!d || !v) return null;const s=v.selection;
    return {doc:d,frame:d.frames[d.activeFrame],layer:d.layer(),cel:d.activeCel(false),selection:s,signature:s ? JSON.stringify(s) : null,bounds:s ? {x:s.x,y:s.y,w:s.w,h:s.h} : {x:0,y:0,w:d.width,h:d.height},undo:d.history.undoStack.slice(),redo:d.history.redoStack.slice()};
  };
  App.validateGradientMap = function (t,colors,strength) {
    const d=App.doc,v=App.view;
    if(!t || !d || !v || t.doc!==d || d.frames[d.activeFrame]!==t.frame || d.layer()!==t.layer || d.activeCel(false)!==t.cel || v.selection!==t.selection || (t.selection && JSON.stringify(t.selection)!==t.signature) || App.playing) return {error:'Artwork or selection changed; reopen Gradient Map'};
    if(!t.cel || !t.layer.visible || t.layer.locked) return {error:'Show and unlock a layer with artwork first'};
    if(!Array.isArray(colors) || colors.length!==3 || colors.some(c=>!Array.isArray(c) || c.length!==3 || c.some(n=>!Number.isInteger(n) || n<0 || n>255)) || !Number.isFinite(strength) || strength<0 || strength>1) return {error:'Enter valid HEX colours and strength'};
    const r=t.bounds;if(![r.x,r.y,r.w,r.h].every(Number.isInteger) || r.x<0 || r.y<0 || r.w<1 || r.h<1 || r.x+r.w>d.width || r.y+r.h>d.height) return {error:'Invalid selection bounds'};
    if(r.w*r.h>4*1024*1024 || (Q.complexSelection(t.selection) ? 24 : 12)*r.w*r.h>64*1024*1024) return {error:'Gradient Map exceeds the 4 MP or estimated 64 MiB limit'};
    const h=d.history;if(h.undoStack.length!==t.undo.length || h.redoStack.length!==t.redo.length || t.undo.some((e,i)=>e!==h.undoStack[i]) || t.redo.some((e,i)=>e!==h.redoStack[i])) return {error:'Artwork changed; reopen Gradient Map'};
    return {};
  };
  App.applyGradientMap = function (target,colors,strength) {
    const v=App.view;if(!v || v.locked) return {error:'Wait for the current operation'};
    const check=App.validateGradientMap(target,colors,strength);if(check.error)return check;
    const d=App.doc,r=target.bounds, chosen=colors.map(c=>c.slice());v.locked=true;Q.UI.progress('Gradient Map','Mapping colours on the current layer…',0);const node=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try {
      const valid=App.validateGradientMap(target,chosen,strength);if(valid.error){Q.toast(valid.error,4000);return;}
      const ctx=target.cel.getContext('2d'), image=ctx.getImageData(r.x,r.y,r.w,r.h),mask=target.selection ? Q.selectionMask(target.selection) : null, rect=Q.gradientMap(image,chosen,strength,mask);
      if(rect) {const changed={x:r.x+rect.x,y:r.y+rect.y,w:rect.w,h:rect.h},before=ctx.getImageData(changed.x,changed.y,changed.w,changed.h);
        try {ctx.putImageData(image,r.x,r.y,rect.x,rect.y,rect.w,rect.h);} catch(err){try {ctx.putImageData(before,changed.x,changed.y);} catch(ignore){} throw err;}
        d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:changed,before:before});v.dirty=true;App.markDirty();}
      Q.toast(rect ? 'Gradient Map applied · Undo to restore' : 'No pixels changed',3000);
    }catch(err){Q.toast('Could not apply Gradient Map on this device',4000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);
    return {started:true};
  };

  App.featherEditTarget = function () {
    const t=App.gradientMapTarget();if(t){t.width=t.doc.width;t.height=t.doc.height;}return t;
  };
  App.validateFeatherEdit = function(t,mode,radius,strength,color) {
    const d=App.doc,v=App.view;
    if(!t || !d || !v || d!==t.doc || d.width!==t.width || d.height!==t.height || d.frames[d.activeFrame]!==t.frame || d.layer()!==t.layer || d.activeCel(false)!==t.cel || v.selection!==t.selection || (t.selection && JSON.stringify(t.selection)!==t.signature) || App.playing)return {error:'Artwork or selection changed; reopen Soft selection edit'};
    if(!t.selection)return {error:'Make a selection first'};
    if(v.stroke || v.quickShape || v.meshTransform)return {error:'Finish the current operation first'};
    if(!t.layer || !t.layer.visible || t.layer.locked)return {error:'Show and unlock the layer first'};
    if(!['fill','clear'].includes(mode) || !Number.isFinite(strength) || strength<0 || strength>1 || !Array.isArray(color) || color.length!==3 || color.some(n=>!Number.isInteger(n)||n<0||n>255))return {error:'Choose valid edit settings'};
    if(mode==='clear' && t.layer.alphaLocked)return {error:'Turn off alpha lock to clear'};
    if(!t.cel && (mode==='clear' || t.layer.alphaLocked))return {error:'No pixels on this layer to edit'};
    const h=d.history;if(h.undoStack.length!==t.undo.length || h.redoStack.length!==t.redo.length || t.undo.some((e,i)=>e!==h.undoStack[i]) || t.redo.some((e,i)=>e!==h.redoStack[i]))return {error:'Artwork changed; reopen Soft selection edit'};
    return Q.planFeatherEdit(t.selection,d.width,d.height,radius,!t.cel);
  };
  App.applyFeatherEdit = function(target,mode,radius,strength,color) {
    const v=App.view;if(!v || v.locked)return {error:'Wait for the current operation'};
    let plan=App.validateFeatherEdit(target,mode,radius,strength,color);if(plan.error)return plan;
    const d=App.doc,chosen=color.slice();v.locked=true;Q.UI.progress('Soft selection edit','Preparing coverage…',0);const node=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try{
      plan=App.validateFeatherEdit(target,mode,radius,strength,chosen);if(plan.error){Q.toast(plan.error,4000);return;}
      if(strength===0){Q.toast('No pixels changed',3000);return;}
      const coverage=Q.featherSelectionCoverage(target.selection,plan),stage=Q.canvas(plan.w,plan.h),sc=stage.getContext('2d');
      if(target.cel)sc.drawImage(target.cel,plan.x,plan.y,plan.w,plan.h,0,0,plan.w,plan.h);
      const before=target.cel ? target.cel.getContext('2d').getImageData(plan.x,plan.y,plan.w,plan.h) : sc.getImageData(0,0,plan.w,plan.h),mask=Q.canvas(plan.w,plan.h),mc=mask.getContext('2d'),im=mc.createImageData(plan.w,plan.h);
      for(let n=0;n<coverage.length;n++){const i=n*4;im.data[i]=chosen[0];im.data[i+1]=chosen[1];im.data[i+2]=chosen[2];im.data[i+3]=coverage[n];}mc.putImageData(im,0,0);
      sc.globalAlpha=strength;sc.globalCompositeOperation=mode==='clear' ? 'destination-out' : target.layer.alphaLocked ? 'source-atop' : 'source-over';sc.drawImage(mask,0,0);
      const after=sc.getImageData(0,0,plan.w,plan.h);for(let n=0;n<coverage.length;n++)if(!coverage[n]){const i=n*4;for(let k=0;k<4;k++)after.data[i+k]=before.data[i+k];}let changed=false;for(let i=0;i<after.data.length;i++)if(after.data[i]!==before.data[i]){changed=true;break;}
      if(changed){
        if(!target.cel){const cel=Q.canvas(d.width,d.height),ctx=cel.getContext('2d');ctx.putImageData(after,plan.x,plan.y);d.history.struct(function(){this.frames[this.activeFrame].cels[this.activeLayer]=cel;});}
        else {const ctx=target.cel.getContext('2d');try{ctx.putImageData(after,plan.x,plan.y);}catch(e){try{ctx.putImageData(before,plan.x,plan.y);}catch(ignore){}throw e;}d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:{x:plan.x,y:plan.y,w:plan.w,h:plan.h},before:before});}
        v.dirty=true;Q.UI.syncDoc();App.markDirty();
      }Q.toast(changed ? 'Soft selection edit applied · Undo to restore' : 'No pixels changed',3000);
    }catch(e){Q.toast('Could not apply soft selection edit on this device',4000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);
    return {started:true};
  };

  App.validateColorBalance = function(target,settings) {
    if(!Q.validColorBalance(settings))return {error:'Invalid colour balance values'};
    const v=App.view;if(v && (v.stroke || v.quickShape || v.meshTransform))return {error:'Finish the current operation first'};
    const check=App.validateGradientMap(target,[[0,0,0],[0,0,0],[0,0,0]],1);
    return check.error ? {error:check.error.replace(/Gradient Map/g,'Colour Balance')} : check;
  };
  App.applyColorBalance = function(target,settings) {
    const v=App.view;if(!v || v.locked)return {error:'Wait for the current operation'};
    const check=App.validateColorBalance(target,settings);if(check.error)return check;
    const chosen={};['shadows','midtones','highlights'].forEach(k=>chosen[k]=settings[k].slice());
    const d=App.doc,r=target.bounds;v.locked=true;Q.UI.progress('Colour Balance','Adjusting the current layer…',0);const node=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try {
      const valid=App.validateColorBalance(target,chosen);if(valid.error){Q.toast(valid.error,4000);return;}
      const ctx=target.cel.getContext('2d'),image=ctx.getImageData(r.x,r.y,r.w,r.h),mask=target.selection ? Q.selectionMask(target.selection) : null,rect=Q.applyColorBalance(image,chosen,mask);
      if(rect){const changed={x:r.x+rect.x,y:r.y+rect.y,w:rect.w,h:rect.h},before=ctx.getImageData(changed.x,changed.y,changed.w,changed.h);
        try{ctx.putImageData(image,r.x,r.y,rect.x,rect.y,rect.w,rect.h);}catch(err){try{ctx.putImageData(before,changed.x,changed.y);}catch(ignore){}throw err;}
        d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:changed,before:before});v.dirty=true;App.markDirty();}
      Q.toast(rect ? 'Colour Balance applied · Undo to restore' : 'No pixels changed',3000);
    }catch(err){Q.toast('Could not apply Colour Balance on this device',4000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);
    return {started:true};
  };

  App.validateTonalAdjustment = function(target,type,values) {
    if(!Q.validTonalAdjustment(type,values))return {error:type==='levels' ? 'Black point must be below white point and values must be valid' : 'Invalid adjustment settings'};
    const check=App.validateColorBalance(target,{shadows:[0,0,0],midtones:[0,0,0],highlights:[0,0,0]});
    return check.error ? {error:check.error.replace(/Colour Balance/g,'Adjustment')} : check;
  };
  App.applyTonalAdjustment = function(target,type,values) {
    const v=App.view;if(!v || v.locked)return {error:'Wait for the current operation'};
    const check=App.validateTonalAdjustment(target,type,values);if(check.error)return check;
    const chosen={...values},d=App.doc,r=target.bounds;v.locked=true;Q.UI.progress('Adjusting colour','Preparing current cel…',0);const node=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try {
      const valid=App.validateTonalAdjustment(target,type,chosen);if(valid.error){Q.toast(valid.error,4000);return;}
      const ctx=target.cel.getContext('2d'),image=ctx.getImageData(r.x,r.y,r.w,r.h),mask=target.selection ? Q.selectionMask(target.selection) : null,rect=Q.applyTonalAdjustment(image,type,chosen,mask);
      if(rect){const changed={x:r.x+rect.x,y:r.y+rect.y,w:rect.w,h:rect.h},before=ctx.getImageData(changed.x,changed.y,changed.w,changed.h);
        try{ctx.putImageData(image,r.x,r.y,rect.x,rect.y,rect.w,rect.h);}catch(err){try{ctx.putImageData(before,changed.x,changed.y);}catch(ignore){}throw err;}
        d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:changed,before:before});v.dirty=true;App.markDirty();}
      Q.toast(rect ? 'Adjustment applied · Undo to restore' : 'No pixels changed',3000);
    }catch(err){Q.toast('Could not apply adjustment on this device',4000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);
    return {started:true};
  };

  App.validateToneCurves = function(target,curves) {
    if(!Q.validToneCurves(curves))return {error:'Invalid curve values'};
    // Use the same bounds, target and history safety checks as Gradient Map.
    const check=App.validateGradientMap(target,[[0,0,0],[0,0,0],[0,0,0]],1);
    return check.error ? {error:check.error.replace(/Gradient Map/g,'Tone Curves')} : check;
  };
  App.applyToneCurves = function(target,curves) {
    const v=App.view;if(!v || v.locked)return {error:'Wait for the current operation'};
    const check=App.validateToneCurves(target,curves);if(check.error)return check;
    const chosen={};['master','red','green','blue'].forEach(k=>chosen[k]=curves[k].slice());
    const d=App.doc,r=target.bounds;v.locked=true;Q.UI.progress('Tone Curves','Adjusting the current layer…',0);const node=document.getElementById ? document.getElementById('progressCard') : null;
    setTimeout(function(){try {
      const valid=App.validateToneCurves(target,chosen);if(valid.error){Q.toast(valid.error,4000);return;}
      const ctx=target.cel.getContext('2d'),image=ctx.getImageData(r.x,r.y,r.w,r.h),mask=target.selection ? Q.selectionMask(target.selection) : null,rect=Q.applyToneCurves(image,chosen,mask);
      if(rect){const changed={x:r.x+rect.x,y:r.y+rect.y,w:rect.w,h:rect.h},before=ctx.getImageData(changed.x,changed.y,changed.w,changed.h);
        try{ctx.putImageData(image,r.x,r.y,rect.x,rect.y,rect.w,rect.h);}catch(err){try{ctx.putImageData(before,changed.x,changed.y);}catch(ignore){}throw err;}
        d.history.push({type:'pixels',f:d.activeFrame,l:d.activeLayer,rect:changed,before:before});v.dirty=true;App.markDirty();}
      Q.toast(rect ? 'Tone Curves applied · Undo to restore' : 'No pixels changed',3000);
    } catch(err){Q.toast('Could not apply Tone Curves on this device',4000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);
    return {started:true};
  };

  App.applyEffect = function (kind, amount) {
    const d = App.doc, cel = d && d.activeCel(false);
    if (!cel) { Q.toast('Draw on this layer first'); return; }
    if (d.layer().locked) { Q.toast('This layer is locked'); return; }
    const bounds=App.view.selection ? {...App.view.selection} : {x:0,y:0,w:d.width,h:d.height}, alphaLocked=!!d.layer().alphaLocked;
    if (amount <= 0) { Q.toast('Choose an effect strength'); return; }
    Q.UI.progress('Applying effect', 'Processing the current layer…', 0);
    setTimeout(function () {
      try {
        if (App.doc !== d || d.activeCel(false) !== cel) { Q.UI.endProgress(); Q.toast('Effect cancelled'); return; }
        const ctx = cel.getContext('2d');
        const image = ctx.getImageData(bounds.x, bounds.y, bounds.w, bounds.h);
        const mask=Q.selectionMask(bounds), original=mask ? new Uint8ClampedArray(image.data) : null;
        const alpha=alphaLocked ? new Uint8Array(image.width*image.height) : null;
        if (alpha) for (let i=0; i<alpha.length; i++) alpha[i]=image.data[i*4+3];
        Q.applyPixelEffect(image, kind, amount);
        if (alpha) for (let i=0; i<alpha.length; i++) image.data[i*4+3]=alpha[i];
        if (mask) for (let i=0;i<mask.length;i++) if (!mask[i]) for (let c=0;c<4;c++) image.data[i*4+c]=original[i*4+c];
        d.history.beginPixels(cel);
        ctx.putImageData(image, bounds.x, bounds.y);
        d.history.endPixels(bounds);
        App.view.dirty = true; App.markDirty();
        Q.UI.endProgress(); Q.toast('Effect applied · Undo to revert');
      } catch (err) {
        Q.UI.endProgress(); Q.toast('Could not apply effect on this device', 4000);
      }
    }, 30);
  };

  App.setBackground = function (color) {
    const d=App.doc; if (!d || !/^#[0-9a-f]{6}$/i.test(color)) return;
    d.setBackground(color); App.view.dirty=true; Q.UI.syncDoc(); App.markDirty();
  };

  App.exportProjectBackup = function () {
    const d=App.doc,v=App.view,target=App.canvasResizeTarget();if(!d || !v || !target)return {error:'Open an artwork first'};
    const valid=App.validateCanvasTarget(target);if(valid.error)return valid;
    v.locked=true;Q.UI.progress('Export project','Preparing editable project backup…',0);const node=document.getElementById('progressCard');
    setTimeout(function(){try{
      const check=App.validateCanvasTarget(target,true);if(check.error){Q.toast(check.error,4000);return;}
      const data=Q.Store.makeProjectBackup(d),ok=Q.saveProjectBackup(data,'Qelem-'+Q.stamp()+'-project.json');
      const native=Q.native(),oldAndroid=native && native.sdk && native.sdk()<29;
      Q.toast(ok ? (native ? 'Project backup saved · check Downloads/Qelem' : 'Project backup download started') : (oldAndroid ? 'Project export requires Android 10 or newer' : 'Could not export project; check storage and try again'),5000);
    }catch(e){Q.toast('Project export failed: '+(e.message || 'not enough memory'),5000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);
    return {started:true};
  };
  // Build a new animation from row-major, evenly sized sprite-sheet tiles.
  App.importSpriteSheet = function(file,options) {
    if(App.projectImportBusy)return {error:'Wait for the current import'};
    if(!file || !Number.isFinite(file.size) || file.size<1 || file.size>10*1024*1024)return {error:'Sprite sheet must be 10 MiB or smaller'};
    const o=options || {};if(![o.columns,o.rows,o.count,o.fps,o.hold].every(Number.isInteger) || o.columns<1 || o.rows<1 || o.columns>60 || o.rows>60 || o.count<1 || o.count>60 || o.count>o.columns*o.rows || o.fps<1 || o.fps>30 || o.hold<1 || o.hold>60)return {error:'Check grid, frame count, FPS and hold'};
    App.projectImportBusy=true;Q.UI.progress('Import sprite sheet','Reading and slicing frames…',0);const node=document.getElementById('progressCard'),reader=new FileReader();
    function finish(){App.projectImportBusy=false;closeFillProgress(node);}
    function fail(message){finish();Q.toast('Sprite sheet import failed: '+message,6000);}
    reader.onerror=function(){fail('could not read image');};
    reader.onload=function(){
      const bytes=new Uint8Array(reader.result),png=bytes.length>=8 && [137,80,78,71,13,10,26,10].every((n,i)=>bytes[i]===n),jpeg=bytes.length>=3 && bytes[0]===255 && bytes[1]===216 && bytes[2]===255,webp=bytes.length>=12 && String.fromCharCode.apply(null,bytes.subarray(0,4))==='RIFF' && String.fromCharCode.apply(null,bytes.subarray(8,12))==='WEBP';
      if(!png && !jpeg && !webp){fail('choose a PNG, JPEG or WebP image');return;}
      let url;try{url=URL.createObjectURL(new Blob([bytes],{type:png ? 'image/png' : jpeg ? 'image/jpeg' : 'image/webp'}));}catch(e){fail('could not open image');return;}
      const image=new Image();image.onerror=function(){URL.revokeObjectURL(url);fail('could not decode image');};image.onload=async function(){URL.revokeObjectURL(url);try{
        const w=image.naturalWidth,h=image.naturalHeight;if(!w || !h || w>4096 || h>4096 || w*h>2*1024*1024)throw Error('sheet exceeds 2 megapixels or 4096 pixels per side');
        if(w%o.columns || h%o.rows)throw Error('sheet dimensions must divide evenly by the grid');
        const tw=w/o.columns,th=h/o.rows;if(tw*th*o.count*4>64*1024*1024)throw Error('frames exceed 64 MiB decoded pixels');
        const name=String(file.name || 'Sprite animation').replace(/\.[^.]+$/,'').slice(0,100) || 'Sprite animation',d=new Q.Doc({width:tw,height:th,fps:o.fps,name:name});d.layers[0].name='Imported sprites';d.frames=[];
        for(let i=0;i<o.count;i++){const cv=Q.canvas(tw,th),ctx=cv.getContext('2d');ctx.drawImage(image,(i%o.columns)*tw,Math.floor(i/o.columns)*th,tw,th,0,0,tw,th);d.frames.push({cels:[cv],duration:o.hold,group:'',skipped:false,role:''});if(i%4===3)await new Promise(resolve=>setTimeout(resolve,0));}
        d.activeFrame=0;d.activeLayer=0;d.onion=false;const thumb=d.thumbnail(0,320).toDataURL('image/jpeg',0.72);await Q.Store.insertNewDocument(d,thumb);
        finish();if(!Q.el('#gallery').classList.contains('hidden'))Q.UI.renderGallery();Q.toast('Sprite sheet imported as a new editable animation',5000);
      }catch(e){fail(e.message || 'not enough memory');}};image.src=url;
    };
    try{reader.readAsArrayBuffer(file);}catch(e){finish();return {error:'Could not read sprite sheet'};}return {started:true};
  };

  App.importGifFile = function(file,fps) {
    if(App.projectImportBusy)return {error:'Wait for the current import'};
    if(!file || !Number.isFinite(file.size) || file.size<1 || file.size>Q.GIF_IMPORT_MAX_BYTES)return {error:'GIF must be 10 MiB or smaller'};
    if(!Number.isInteger(fps) || fps<1 || fps>30)return {error:'Choose FPS from 1 to 30'};
    App.projectImportBusy=true;Q.UI.progress('Import GIF','Decoding animation frames…',0);const node=document.getElementById('progressCard'),reader=new FileReader();
    function finish(){App.projectImportBusy=false;closeFillProgress(node);}
    reader.onerror=function(){finish();Q.toast('Could not read GIF',5000);};
    reader.onload=async function(){try {
      const parsed=Q.parseGif(new Uint8Array(reader.result),fps),name=String(file.name || 'GIF animation').replace(/\.gif$/i,'').slice(0,100) || 'GIF animation';
      const d=new Q.Doc({width:parsed.width,height:parsed.height,fps:fps,name:name});d.layers[0].name='Imported GIF';d.frames=[];
      await Q.decodeGifFrames(parsed,function(pixels,index,frame){const cv=Q.canvas(parsed.width,parsed.height),ctx=cv.getContext('2d'),image=ctx.createImageData(parsed.width,parsed.height);image.data.set(pixels);ctx.putImageData(image,0,0);d.frames.push({cels:[cv],duration:frame.hold,group:'',skipped:false,role:''});});
      d.activeFrame=0;d.activeLayer=0;d.onion=false;d.playMode=parsed.loopCount===null ? 'once' : 'loop';const thumb=d.thumbnail(0,320).toDataURL('image/jpeg',0.72);await Q.Store.insertNewDocument(d,thumb);
      finish();if(!Q.el('#gallery').classList.contains('hidden'))Q.UI.renderGallery();Q.toast('GIF imported as a new editable animation',5000);
    }catch(e){finish();Q.toast('GIF import failed: '+(e.message || 'not enough memory'),6000);}};
    try{reader.readAsArrayBuffer(file);}catch(e){finish();return {error:'Could not read GIF file'};}return {started:true};
  };

  App.importProjectFile = function(file) {
    if(App.projectImportBusy)return {error:'Wait for the current import'};
    if(!file || !Number.isFinite(file.size) || file.size<1 || file.size>Q.PROJECT_BACKUP_MAX_BYTES)return {error:'Project file must be 24 MiB or smaller'};
    App.projectImportBusy=true;Q.UI.progress('Import project','Checking the backup and every cel…',0);const node=document.getElementById('progressCard'),reader=new FileReader();
    function finish(){App.projectImportBusy=false;closeFillProgress(node);}
    reader.onerror=function(){finish();Q.toast('Could not read project file',4000);};
    reader.onload=function(){Q.Store.importProjectBackup(reader.result).then(function(){finish();if(!Q.el('#gallery').classList.contains('hidden'))Q.UI.renderGallery();Q.toast('Project imported as a new artwork',4000);}).catch(function(e){finish();Q.toast('Project import failed: '+(e.message || 'storage error'),6000);});};
    try{reader.readAsText(file,'utf-8');}catch(e){finish();return {error:'Could not read project file'};}
    return {started:true};
  };

  App.exportPng = function (transparent) {
    App.stopPlay();
    const d = App.doc;
    if (!d) return;
    const cv = d.flatten(d.activeFrame, {background: transparent ? false : d.bg});
    const ok = Q.saveBytes(cv.toDataURL('image/png'), 'image/png', 'Qelem-' + Q.stamp() + (transparent ? '-transparent' : '') + '.png');
    Q.toast(ok ? 'PNG saved' : 'Could not save PNG');
  };

  App.exportJpeg = function (quality) {
    App.stopPlay(); const d=App.doc; if(!d) return false;
    if(!Number.isFinite(quality) || quality<0 || quality>1) { Q.toast('Invalid JPEG quality'); return false; }
    try {
      const cv=d.flatten(d.activeFrame,{background:d.bg}), data=cv.toDataURL('image/jpeg',quality);
      if(!data.startsWith('data:image/jpeg;base64,')) { Q.toast('JPEG export is not supported on this device',4000); return false; }
      const ok=Q.saveBytes(data,'image/jpeg','Qelem-'+Q.stamp()+'.jpg'); Q.toast(ok ? 'JPEG saved' : 'Could not save JPEG'); return !!ok;
    } catch(e) { Q.toast('Could not export JPEG on this device',4000); return false; }
  };

  App.exportPngSequence = function (transparent) {
    App.stopPlay();
    const d = App.doc; if (!d) return;
    const stamp = Q.stamp(), total = d.frames.length;
    let index = 0, saved = 0;
    Q.UI.progress('Exporting PNG sequence', 'Preparing frames…', 0);
    function step() {
      try {
        const png = d.flatten(index, {background: transparent ? false : d.bg}).toDataURL('image/png');
        const number = String(index + 1).padStart(3, '0');
        if (Q.saveBytes(png, 'image/png', 'Qelem-' + stamp + '-frame-' + number + (transparent ? '-transparent' : '') + '.png')) saved++;
        index++;
        if (index < total) { Q.UI.progress('Exporting PNG sequence', index + ' / ' + total, index / total); setTimeout(step, 0); }
        else { Q.UI.endProgress(); Q.toast('Saved ' + saved + ' of ' + total + ' PNG frames', 4000); }
      } catch (err) { Q.UI.endProgress(); Q.toast('Sequence stopped after ' + saved + ' frames', 4000); }
    }
    setTimeout(step, 30);
  };

  App.exportStoryboard = function(target,options,signature) {
    const v=App.view,d=App.doc;if(!v || !d || !target || target.doc!==d)return {error:'Artwork changed; reopen storyboard'};
    const initial=App.validateCanvasTarget(target),plan=Q.storyboardPlan(d,options);if(initial.error)return initial;if(plan.error)return plan;
    if(signature!==App.storyboardSignature(d))return {error:'Artwork settings changed; reopen storyboard'};
    v.locked=true;Q.UI.progress('Export storyboard','Preparing labelled frames…',0);const node=document.getElementById('progressCard');
    setTimeout(function(){try{const valid=App.validateCanvasTarget(target,true);if(valid.error || signature!==App.storyboardSignature(d))throw Error('Artwork changed; reopen storyboard');const canvas=Q.renderStoryboard(d,options,1),url=canvas.toDataURL('image/png');if(!url.startsWith('data:image/png;base64,'))throw Error('PNG encoding failed');const ok=Q.saveBytes(url,'image/png','Qelem-'+Q.stamp()+'-storyboard.png');Q.toast(ok ? 'Storyboard exported' : 'Could not save storyboard',4000);}catch(e){Q.toast('Storyboard export failed: '+(e.message || 'not enough memory'),5000);}finally{closeFillProgress(node);if(App.doc===d && App.view===v && !App.playing)v.locked=false;}},40);return {started:true};
  };
  App.storyboardSignature = function(d) {return JSON.stringify({fps:d.fps,bg:d.bg,frames:d.frames.map(f=>[f.duration,f.group,!!f.skipped,f.role || '']),layers:d.layers.map(l=>[l.id,!!l.visible,l.opacity,l.blend,!!l.clipped])});};

  App.exportSpriteSheet = function (columns,scale,transparent) {
    App.stopPlay(); const d=App.doc; if (!d) return;
    if (!Q.spriteSheetLayout(d,columns,scale)) { Q.toast('Sprite sheet is too large or settings are invalid',4000); return; }
    Q.UI.progress('Exporting sprite sheet','Rendering frames…',0);
    setTimeout(function () {
      try {
        if (App.doc!==d) { Q.UI.endProgress(); return; }
        const sheet=Q.renderSpriteSheet(d,columns,scale,transparent);
        const ok=Q.saveBytes(sheet.toDataURL('image/png'),'image/png','Qelem-'+Q.stamp()+'-spritesheet.png');
        Q.UI.endProgress(); Q.toast(ok ? 'Sprite sheet saved' : 'Could not save sprite sheet');
      } catch (err) { Q.UI.endProgress(); Q.toast('Could not create sprite sheet on this device',4000); }
    },40);
  };

  // MediaRecorder MP4 is optional on Android WebView. Never label WebM as MP4.
  App.exportMp4 = function () {
    App.stopPlay();
    const d = App.doc;
    if (!d || d.frames.length < 2) { Q.toast('Add at least two frames first'); return; }
    if (!window.MediaRecorder || !MediaRecorder.isTypeSupported) { Q.toast('MP4 encoding is not supported on this device', 4000); return; }
    const mime = ['video/mp4;codecs=avc1.42E01E', 'video/mp4'].find(function (v) { return MediaRecorder.isTypeSupported(v); });
    if (!mime) { Q.toast('MP4 encoding is not supported on this device', 4000); return; }
    const scale = Math.min(1, 1280 / Math.max(d.width, d.height));
    const w = Math.max(2, Math.floor(d.width * scale / 2) * 2), h = Math.max(2, Math.floor(d.height * scale / 2) * 2);
    const canvas = Q.canvas(w, h), ctx = canvas.getContext('2d');
    if (!canvas.captureStream) { Q.toast('Video capture is not supported on this device', 4000); return; }
    let stream, recorder, timer, finished = false;
    const chunks = [], fps = Q.clamp(d.fps, 1, 30), order=Q.playbackOrder(d);
    if (!order.length) { Q.toast('No included frames in the playback range',4000); return; }
    function cleanup() { clearTimeout(timer); if (stream) stream.getTracks().forEach(function (track) { track.stop(); }); Q.UI.endProgress(); }
    function fail(message) { if (finished) return; finished = true; try { if (recorder && recorder.state !== 'inactive') recorder.stop(); } catch (e) {} cleanup(); Q.toast(message, 4000); }
    function paint(index) {
      ctx.fillStyle = d.bg; ctx.fillRect(0, 0, w, h);
      ctx.save(); ctx.scale(w / d.width, h / d.height); d.compositeCamera(ctx, index); ctx.restore();
    }
    try {
      paint(order[0]); stream = canvas.captureStream(fps);
      recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 4000000 });
      recorder.ondataavailable = function (event) { if (event.data && event.data.size) chunks.push(event.data); };
      recorder.onerror = function () { fail('MP4 encoding failed on this device'); };
      recorder.onstop = function () {
        if (finished) return;
        finished = true; cleanup();
        if (!chunks.length) { Q.toast('MP4 encoder returned no video', 4000); return; }
        const reader = new FileReader();
        reader.onerror = function () { Q.toast('Could not prepare MP4', 4000); };
        reader.onload = function () {
          const ok = Q.saveBytes(reader.result, 'video/mp4', 'Qelem-' + Q.stamp() + '.mp4');
          Q.toast(ok ? 'MP4 saved (Movies/Qalam on Android 10+)' : 'Could not save MP4', 4000);
        };
        reader.readAsDataURL(new Blob(chunks, { type: 'video/mp4' }));
      };
      Q.UI.progress('Exporting MP4', 'Recording one animation loop…', 0);
      recorder.start();
      let position = 0;
      function next() {
        position++;
        if (position >= order.length) { try { recorder.stop(); } catch (err) { fail('MP4 encoder stopped unexpectedly'); } return; }
        paint(order[position]); timer = setTimeout(next, Q.frameDelayMs(d, order[position]));
      }
      timer = setTimeout(next, Q.frameDelayMs(d, order[position]));
    } catch (err) { fail('Could not start MP4 export on this device'); }
  };

  // Read only MP4 metadata (not the potentially huge media payload), and require
  // both video and sound handler tracks before presenting the result as audio MP4.
  Q.mp4HasAudioAndVideo = async function (blob) {
    function read(start,end) {
      return new Promise(function (resolve,reject) {
        const reader=new FileReader(); reader.onload=()=>resolve(reader.result); reader.onerror=()=>reject(new Error('MP4 read failed'));
        reader.readAsArrayBuffer(blob.slice(start,end));
      });
    }
    function header(view,pos,limit) {
      if (pos+8>limit) throw Error('Truncated MP4 box');
      let size=view.getUint32(pos), head=8;
      const type=String.fromCharCode(view.getUint8(pos+4),view.getUint8(pos+5),view.getUint8(pos+6),view.getUint8(pos+7));
      if (size===1) { if (pos+16>limit) throw Error('Truncated extended MP4 box'); size=view.getUint32(pos+8)*4294967296+view.getUint32(pos+12); head=16; }
      else if (size===0) size=limit-pos;
      if (!Number.isSafeInteger(size) || size<head || pos+size>limit) throw Error('Invalid MP4 box size');
      return {type,size,head};
    }
    function children(view,start,end) {
      const result=[]; let pos=start;
      while (pos<end) { if (result.length>=10000) throw Error('Too many MP4 boxes'); const box=header(view,pos,end); result.push({type:box.type,start:pos+box.head,end:pos+box.size}); pos+=box.size; }
      return result;
    }
    let pos=0, count=0, hasFtyp=false, hasTracks=false;
    while (pos<blob.size && count++<10000) {
      // A header can be parsed without reading or copying an mdat payload.
      const hdr=new DataView(await read(pos,Math.min(pos+16,blob.size)));
      if (hdr.byteLength<8) throw Error('Truncated MP4');
      let size=hdr.getUint32(0), head=8;
      const type=String.fromCharCode(hdr.getUint8(4),hdr.getUint8(5),hdr.getUint8(6),hdr.getUint8(7));
      if (size===1) { if (hdr.byteLength<16) throw Error('Truncated MP4'); size=hdr.getUint32(8)*4294967296+hdr.getUint32(12); head=16; }
      else if (size===0) size=blob.size-pos;
      if (!Number.isSafeInteger(size) || size<head || pos+size>blob.size) throw Error('Invalid MP4 size');
      if (type==='ftyp' && size>=head+8) hasFtyp=true;
      if (type==='moov') {
        if (size>16*1024*1024) throw Error('MP4 metadata too large');
        const view=new DataView(await read(pos+head,pos+size)), handlers=[];
        children(view,0,view.byteLength).filter(b=>b.type==='trak').forEach(function (trak) {
          children(view,trak.start,trak.end).filter(b=>b.type==='mdia').forEach(function (mdia) {
            children(view,mdia.start,mdia.end).filter(b=>b.type==='hdlr').forEach(function (handler) {
              if (handler.end-handler.start<12) throw Error('Invalid MP4 handler');
              handlers.push(String.fromCharCode(view.getUint8(handler.start+8),view.getUint8(handler.start+9),view.getUint8(handler.start+10),view.getUint8(handler.start+11)));
            });
          });
        });
        hasTracks=handlers.includes('vide') && handlers.includes('soun');
      }
      pos+=size;
    }
    return pos===blob.size && hasFtyp && hasTracks;
  };

  // Optional AAC-in-MP4 export. The selected forward range is rendered in real
  // time, while one decoded local track is routed into the recorder, not speakers.
  // Reject unsupported paths instead of silently exporting a video without audio.
  App.exportMp4WithAudio = function () {
    App.stopPlay(); const d=App.doc;
    if (App.cancelAudioExport) { Q.toast('An audio export is already in progress',4000); return; }
    if (!d || d.frames.length<2) { Q.toast('Add at least two frames first',4000); return; }
    if (!d.audioTrack || d.audioTrack.muted) { Q.toast('Add and unmute an audio track first',4000); return; }
    if (d.playMode==='pingpong' || d.playMode==='reverse') { Q.toast('Audio MP4 export requires forward playback, not ping-pong or reverse',4000); return; }
    const order=Q.playableFrames(d); if (!order.length) { Q.toast('No included frames in the playback range',4000); return; }
    if (order.reduce((sum,i)=>sum+Q.frameDelayMs(d,i),0)>120000) { Q.toast('Audio MP4 is limited to 120 seconds; shorten the range or holds',4000); return; }
    if (!window.MediaRecorder || !MediaRecorder.isTypeSupported) { Q.toast('MP4 with AAC audio is not supported on this device',4000); return; }
    let mime;
    try { mime=['video/mp4;codecs="avc1.42E01E,mp4a.40.2"','video/mp4;codecs="avc1.4D401F,mp4a.40.2"','video/mp4;codecs="avc1.64001F,mp4a.40.2"'].find(v=>MediaRecorder.isTypeSupported(v)); } catch(e) { Q.toast('MP4 with AAC audio is not supported on this device',4000); return; }
    const AudioCtx=window.AudioContext || window.webkitAudioContext;
    if (!mime || !AudioCtx) { Q.toast('MP4 with AAC audio is not supported on this device',4000); return; }
    const scale=Math.min(1,1280/Math.max(d.width,d.height)), w=Math.max(2,Math.floor(d.width*scale/2)*2), h=Math.max(2,Math.floor(d.height*scale/2)*2);
    let context,stream,source,destination,recorder,timer,guard,finished=false,started=false,completed=false;
    const chunks=[], fps=Q.clamp(d.fps,1,30), offset=Q.audioFrameTime(d,order[0]), track=d.audioTrack;
    function releaseMedia() {
      if (source) { try { source.stop(); } catch(e) {} try { source.disconnect(); } catch(e) {} source=null; }
      if (stream) { try { stream.getTracks().forEach(t=>t.stop()); } catch(e) {} stream=null; }
      if (destination) { try { destination.stream.getTracks().forEach(t=>t.stop()); } catch(e) {} destination=null; }
      if (context) { try { const p=context.close(); if (p && p.catch) p.catch(()=>{}); } catch(e) {} context=null; }
    }
    function cleanup() {
      clearTimeout(timer); clearTimeout(guard); releaseMedia();
      App.cancelAudioExport=null; Q.UI.endProgress();
    }
    function fail(message) {
      if (finished) return; finished=true;
      try { if (recorder && recorder.state!=='inactive') recorder.stop(); } catch(e) {}
      cleanup(); Q.toast(message,4000);
    }
    App.cancelAudioExport=function () { fail('Audio MP4 export cancelled'); };
    Q.UI.progress('Exporting MP4 with audio','Preparing audio…',0,App.cancelAudioExport);
    guard=setTimeout(()=>fail('Audio preparation timed out on this device'),15000);
    try {
      context=new AudioCtx();
      if (!context.createMediaStreamDestination || !context.createBufferSource || !context.decodeAudioData) { fail('Audio export is not supported on this device'); return; }
      const encoded=track.data.slice(track.data.indexOf(',')+1), binary=atob(encoded), bytes=new Uint8Array(binary.length);
      for (let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
      // Resume synchronously from the export-button gesture, before async decoding.
      const resume=context.resume ? context.resume() : Promise.resolve();
      Promise.resolve(resume).then(function () {
        if (finished) return;
        if (context.state && context.state!=='running') { fail('Audio export could not start on this device'); return; }
        context.decodeAudioData(bytes.buffer,function (buffer) {
          if (finished) return;
          if (!buffer || !Number.isFinite(buffer.duration) || buffer.duration<=offset) { fail('Audio ends before this playback range; choose silent export or another range'); return; }
          try {
            const canvas=Q.canvas(w,h), ctx=canvas.getContext('2d');
            if (!canvas.captureStream) { fail('Video capture is not supported on this device'); return; }
            function paint(index) { ctx.fillStyle=d.bg; ctx.fillRect(0,0,w,h); ctx.save(); ctx.scale(w/d.width,h/d.height); d.compositeCamera(ctx,index); ctx.restore(); }
            paint(order[0]); stream=canvas.captureStream(fps);
            const videoTracks=stream.getVideoTracks ? stream.getVideoTracks() : [];
            destination=context.createMediaStreamDestination(); const audioTracks=destination.stream.getAudioTracks();
            if (!stream.addTrack || !videoTracks.length || videoTracks[0].readyState==='ended' || !audioTracks.length || audioTracks[0].readyState==='ended') { fail('Audio capture is not supported on this device'); return; }
            stream.addTrack(audioTracks[0]); source=context.createBufferSource(); source.buffer=buffer; source.connect(destination);
            recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:4000000,audioBitsPerSecond:128000});
            recorder.ondataavailable=function (event) { if (event.data && event.data.size) chunks.push(event.data); };
            recorder.onerror=function () { fail('MP4 audio encoding failed on this device'); };
            recorder.onstart=function () {
              if (finished || started) return; started=true; clearTimeout(guard);
              try {
                if (context.state && context.state!=='running') { fail('Audio export was interrupted'); return; }
                source.start(0,offset); let position=0;
                Q.UI.progress('Exporting MP4 with audio','Recording one forward animation cycle…',0);
                function next() {
                  if (finished) return;
                  try {
                    if (App.doc!==d || (context.state && context.state!=='running') || audioTracks[0].readyState==='ended' || videoTracks[0].readyState==='ended') { fail('Audio export was interrupted'); return; }
                    position++;
                    if (position>=order.length) { completed=true; guard=setTimeout(()=>fail('MP4 encoder did not finish'),15000); try { recorder.stop(); } catch(e) { fail('MP4 encoder stopped unexpectedly'); } return; }
                    paint(order[position]); Q.UI.progress('Exporting MP4 with audio','Recording frame '+(position+1)+' / '+order.length,position/order.length);
                    timer=setTimeout(next,Q.frameDelayMs(d,order[position]));
                  } catch(e) { fail('Could not render MP4 on this device'); }
                }
                timer=setTimeout(next,Q.frameDelayMs(d,order[0]));
              } catch(e) { fail('Could not start audio in MP4 export'); }
            };
            recorder.onstop=function () {
              if (finished) return;
              if (!started || !completed || !chunks.length || (recorder.mimeType && !/^video\/mp4(?:;|$)/i.test(recorder.mimeType))) { fail('MP4 encoding ended unexpectedly; no file saved'); return; }
              clearTimeout(timer); clearTimeout(guard); releaseMedia();
              const blob=new Blob(chunks,{type:'video/mp4'});
              Q.UI.progress('Exporting MP4 with audio','Checking video and audio tracks…',1);
              guard=setTimeout(()=>fail('MP4 track verification timed out; no file saved'),15000);
              Q.mp4HasAudioAndVideo(blob).then(function (valid) {
                if (finished) return;
                if (!valid) { fail('MP4 has no video or audio track; no file saved'); return; }
                finished=true; cleanup();
                const reader=new FileReader(); reader.onerror=function () { Q.toast('Could not prepare MP4',4000); };
                reader.onload=function () { const ok=Q.saveBytes(reader.result,'video/mp4','Qelem-'+Q.stamp()+'-audio.mp4'); Q.toast(ok ? 'MP4 with audio saved (Movies/Qalam on Android 10+)' : 'Could not save MP4',4000); };
                try { reader.readAsDataURL(blob); } catch(e) { Q.toast('Could not prepare MP4',4000); }
              }).catch(function () { fail('Could not verify MP4 audio and video tracks; no file saved'); });
            };
            clearTimeout(guard); guard=setTimeout(()=>fail('MP4 encoder did not start'),15000); recorder.start();
          } catch(e) { fail('Could not start MP4 with audio on this device'); }
        },function () { fail('Could not decode the audio track on this device'); });
      }).catch(function () { fail('Could not start audio export on this device'); });
    } catch(e) { fail('Could not prepare MP4 with audio on this device'); }
  };

  App.exportGif = function (opts) {
    App.stopPlay();
    const d = App.doc;
    if (!d) return;
    opts = opts || {};
    if (d.frames.length < 2) { Q.toast('Add frames to export an animation'); return; }
    const scale = opts.scale || 1;
    const w = Math.max(2, Math.round(d.width * scale));
    const h = Math.max(2, Math.round(d.height * scale));

    const included=Q.playableFrames(d), order=Q.playbackOrder(d);
    if (!order.length) { Q.toast('No included frames in the playback range',4000); return; }
    Q.UI.progress('Rendering animation', 'Building selected playback range…', 0);
    const frames = [];
    for (const i of included) {
      const cv = Q.canvas(w, h);
      const c = cv.getContext('2d');
      c.fillStyle = d.bg;
      c.fillRect(0, 0, w, h);
      c.save();
      c.scale(w / d.width, h / d.height);
      d.compositeCamera(c, i);
      c.restore();
      frames[i] = cv;
    }

    Q.encodeGif(order.map(function (i) { return frames[i]; }), {
      delayCs: Math.round(100 / d.fps),
      delaysCs: order.map(function (i) { return Math.max(2, Math.round(Q.frameDelayMs(d, i) / 10)); }),
      loop: opts.loop == null ? (d.playMode === 'once' ? -1 : 0) : opts.loop,
      background: d.bg,
      onProgress: function (p) {
        Q.UI.progress('Encoding GIF', Math.round(p * 100) + '%', p);
      }
    }).then(function (res) {
      Q.UI.endProgress();
      const name = 'Qelem-' + Q.stamp() + '.gif';
      const ok = Q.saveBytes(res.dataUrl, 'image/gif', name);
      Q.toast(ok ? 'GIF saved to Pictures/Qalam' : 'Could not save the GIF', 2600);
    }).catch(function (err) {
      Q.UI.endProgress();
      Q.fatal(err);
    });
  };

  /* ── start ──────────────────────────────────────────────── */

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', App.init);
  } else {
    App.init();
  }
})();
