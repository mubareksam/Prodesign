/* Selection geometry, paths and lossless pixel flips. */
(function () {
  'use strict';
  const Q = window.Q;
  Q.selectionRect = function (a, b, width, height) {
    const x = Math.max(0, Math.floor(Math.min(a.x,b.x)));
    const y = Math.max(0, Math.floor(Math.min(a.y,b.y)));
    const right = Math.min(width, Math.ceil(Math.max(a.x,b.x)));
    const bottom = Math.min(height, Math.ceil(Math.max(a.y,b.y)));
    return right > x && bottom > y ? { x:x, y:y, w:right-x, h:bottom-y } : null;
  };
  Q.lassoSelection = function (points,width,height) {
    if (!points || points.length<3) return null;
    const xs=points.map(p=>p.x), ys=points.map(p=>p.y);
    const bounds=Q.selectionRect({x:Math.min(...xs),y:Math.min(...ys)},{x:Math.max(...xs),y:Math.max(...ys)},width,height);
    if (!bounds || bounds.w<2 || bounds.h<2) return null;
    bounds.points=points.map(p=>({x:p.x,y:p.y})); return bounds;
  };
  // Preserve the original ellipse when it extends beyond the canvas. Using a
  // native path also avoids constructing hundreds of polygon edges per stamp.
  Q.ellipseSelection = function(a,b,width,height) {
    if(!a || !b || ![a.x,a.y,b.x,b.y].every(Number.isFinite)) return null;
    const rx=Math.abs(b.x-a.x)/2, ry=Math.abs(b.y-a.y)/2;
    if(rx<1 || ry<1) return null;
    const bounds=Q.selectionRect(a,b,width,height);
    if(!bounds || bounds.w<1 || bounds.h<1) return null;
    bounds.shape='ellipse'; bounds.ellipse={cx:(a.x+b.x)/2,cy:(a.y+b.y)/2,rx:rx,ry:ry}; return bounds;
  };
  Q.complexSelection = function(s) { return !!(s && (s.points || s.runs || s.shape==='ellipse')); };
  Q.appendSelectionPath = function (ctx,selection) {
    if (selection.shape==='ellipse' && selection.ellipse) { const e=selection.ellipse; ctx.ellipse(e.cx,e.cy,e.rx,e.ry,0,0,Math.PI*2); }
    else if (selection.runs) { for (const run of selection.runs) ctx.rect(run.x,run.y,run.w,1); }
    else if (selection.points && selection.points.length>=3) {
      ctx.moveTo(selection.points[0].x,selection.points[0].y);
      for (let i=1;i<selection.points.length;i++) ctx.lineTo(selection.points[i].x,selection.points[i].y);
      ctx.closePath();
    } else ctx.rect(selection.x,selection.y,selection.w,selection.h);
  };
  Q.selectionPath = function (ctx,selection) { ctx.beginPath(); Q.appendSelectionPath(ctx,selection); };
  Q.selectionMask = function (selection) {
    if (selection.runs) { const mask=new Uint8Array(selection.w*selection.h); for (const run of selection.runs) mask.fill(1,(run.y-selection.y)*selection.w+run.x-selection.x,(run.y-selection.y)*selection.w+run.x-selection.x+run.w); return mask; }
    if (!selection.points && selection.shape!=='ellipse') return null;
    const canvas=Q.canvas(selection.w,selection.h), ctx=canvas.getContext('2d');
    ctx.translate(-selection.x,-selection.y); Q.selectionPath(ctx,selection); ctx.fillStyle='#000'; ctx.fill();
    const rgba=ctx.getImageData(0,0,selection.w,selection.h).data, mask=new Uint8Array(selection.w*selection.h);
    for (let i=0;i<mask.length;i++) mask[i]=rgba[i*4+3]>=128 ? 1 : 0;
    return mask;
  };
  // Complement an existing selection using the same hard mask as pixel edits.
  // A null selection means "unrestricted" elsewhere, so an empty result must
  // not be represented as null (which would accidentally select everything).
  Q.invertSelection = function (selection,width,height) {
    if (!selection) return {error:'Make a selection first'};
    if (!Number.isInteger(width) || !Number.isInteger(height) || width<1 || height<1 || !Number.isInteger(selection.x) || !Number.isInteger(selection.y) || !Number.isInteger(selection.w) || !Number.isInteger(selection.h) || selection.w<1 || selection.h<1 || selection.x<0 || selection.y<0 || selection.x+selection.w>width || selection.y+selection.h>height) return {error:'Invalid selection'};
    if (width*height>4*1024*1024) return {error:'Canvas exceeds the 4 megapixel inversion limit'};
    if (Q.complexSelection(selection) && selection.w*selection.h>4*1024*1024) return {error:'Selection mask exceeds the 4 megapixel inversion limit'};
    try {
      const mask=Q.selectionMask(selection), runs=[]; let minX=width,minY=height,maxX=0,maxY=0;
      for (let y=0;y<height;y++) {
        let start=-1;
        for (let x=0;x<=width;x++) {
          let selected=false;
          if (x<width && x>=selection.x && x<selection.x+selection.w && y>=selection.y && y<selection.y+selection.h) selected=mask ? !!mask[(y-selection.y)*selection.w+x-selection.x] : true;
          const include=x<width && !selected;
          if (include && start<0) start=x;
          if (!include && start>=0) {
            if (runs.length>=4096) return {error:'Inverted selection is too complex (maximum 4096 runs)'};
            runs.push({x:start,y:y,w:x-start}); minX=Math.min(minX,start); maxX=Math.max(maxX,x); minY=Math.min(minY,y); maxY=y+1; start=-1;
          }
        }
      }
      if (!runs.length) return {error:'Inversion would be empty; selection left unchanged'};
      return {selection:{x:minX,y:minY,w:maxX-minX,h:maxY-minY,runs:runs}};
    } catch(e) { return {error:'Not enough memory to invert selection'}; }
  };

  // Boolean operations create hard run masks; null means unrestricted elsewhere,
  // so refusing empty results avoids accidentally selecting the entire canvas.
  Q.combineSelections = function (base,added,operation,width,height) {
    if(!base || !added) return {error:'Make an existing selection first'};
    if(!['add','subtract','intersect'].includes(operation)) return {error:'Invalid selection operation'};
    const valid=s=>s && [s.x,s.y,s.w,s.h].every(Number.isInteger) && s.x>=0 && s.y>=0 && s.w>0 && s.h>0 && s.x+s.w<=width && s.y+s.h<=height;
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||!valid(base)||!valid(added)) return {error:'Invalid selection bounds'};
    if(width*height>4*1024*1024) return {error:'Canvas exceeds the 4 megapixel selection-combine limit'};
    try {
      const masks=[Q.selectionMask(base),Q.selectionMask(added)], shapes=[base,added];
      function contains(n,x,y) { const s=shapes[n]; return x>=s.x && x<s.x+s.w && y>=s.y && y<s.y+s.h && (!masks[n] || !!masks[n][(y-s.y)*s.w+x-s.x]); }
      const left=operation==='add' ? Math.min(base.x,added.x) : operation==='intersect' ? Math.max(base.x,added.x) : base.x, top=operation==='add' ? Math.min(base.y,added.y) : operation==='intersect' ? Math.max(base.y,added.y) : base.y;
      const right=operation==='add' ? Math.max(base.x+base.w,added.x+added.w) : operation==='intersect' ? Math.min(base.x+base.w,added.x+added.w) : base.x+base.w, bottom=operation==='add' ? Math.max(base.y+base.h,added.y+added.h) : operation==='intersect' ? Math.min(base.y+base.h,added.y+added.h) : base.y+base.h;
      const runs=[]; let minX=width,minY=height,maxX=0,maxY=0;
      for(let y=top;y<bottom;y++) { let start=-1; for(let x=left;x<=right;x++) {
        const include=x<right && (operation==='add' ? contains(0,x,y)||contains(1,x,y) : operation==='intersect' ? contains(0,x,y)&&contains(1,x,y) : contains(0,x,y)&&!contains(1,x,y));
        if(include && start<0) start=x;
        if(!include && start>=0) { if(runs.length>=4096) return {error:'Combined selection is too complex (maximum 4096 runs)'}; runs.push({x:start,y:y,w:x-start}); minX=Math.min(minX,start); maxX=Math.max(maxX,x); minY=Math.min(minY,y); maxY=y+1; start=-1; }
      }}
      if(!runs.length) return {error:'Result would be empty; selection left unchanged'};
      return {selection:{x:minX,y:minY,w:maxX-minX,h:maxY-minY,runs:runs}};
    } catch(e) { return {error:'Not enough memory to combine selections'}; }
  };

  // Convert nontransparent layer pixels to a temporary binary selection.
  Q.selectionFromAlpha = function(image) {
    const w=image.width,h=image.height;
    if(!Number.isInteger(w) || !Number.isInteger(h) || w<1 || h<1 || w*h>4*1024*1024) return {error:'Canvas exceeds the 4 megapixel selection limit'};
    try {
      const region=new Uint8Array(w*h);
      for(let n=0;n<region.length;n++) if(image.data[n*4+3]>0) region[n]=2;
      const result=Q.selectionFromRegion(region,w,h,0,0);
      if(!result) return {error:'Layer has no nontransparent pixels'};
      if(result.error) return {error:'Layer contents are too complex (maximum 4096 runs)'};
      return result;
    } catch(e) { return {error:'Not enough memory to select layer contents'}; }
  };

  Q.selectionFromLuminance = function(image,mode,threshold){
    const w=image.width,h=image.height;if(!Number.isInteger(w)||!Number.isInteger(h)||w<1||h<1||w*h>4*1024*1024||!['highlights','shadows'].includes(mode)||!Number.isInteger(threshold)||threshold<0||threshold>255)return {error:'Invalid selection settings'};
    try{const region=new Uint8Array(w*h),data=image.data;for(let n=0;n<region.length;n++){const i=n*4,l=.2126*data[i]+.7152*data[i+1]+.0722*data[i+2];if(data[i+3]&&(mode==='highlights'?l>=threshold:l<=threshold))region[n]=2;}const result=Q.selectionFromRegion(region,w,h,0,0);if(!result)return {error:'No pixels matched; selection unchanged'};if(result.error)return {error:'Selection too complex (maximum 4096 runs)'};return result;}catch(e){return {error:'Not enough memory to select pixels'};}
  };

  // Hard-edged square-radius dilation/erosion; outside the canvas is unselected.
  // Sliding windows keep the work linear in pixels rather than radius squared.
  Q.resizeSelectionMask = function(selection,width,height,radius,mode) {
    if(!selection) return {error:'Make a selection first'};
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width*height>4*1024*1024) return {error:'Canvas exceeds the 4 megapixel selection limit'};
    if(!Number.isInteger(radius)||radius<1||radius>32||!['grow','shrink'].includes(mode)) return {error:'Choose a radius from 1 to 32 pixels'};
    if(![selection.x,selection.y,selection.w,selection.h].every(Number.isInteger)||selection.x<0||selection.y<0||selection.w<1||selection.h<1||selection.x+selection.w>width||selection.y+selection.h>height) return {error:'Invalid selection'};
    try {
      const original=Q.selectionMask(selection), source=new Uint8Array(width*height), horizontal=new Uint8Array(width*height), result=new Uint8Array(width*height), size=radius*2+1;
      for(let y=0;y<selection.h;y++) for(let x=0;x<selection.w;x++) if(!original || original[y*selection.w+x]) source[(selection.y+y)*width+selection.x+x]=1;
      const accept=n=>mode==='grow' ? n>0 : n===size;
      for(let y=0;y<height;y++) { let count=0; for(let x=0;x<=Math.min(radius,width-1);x++) count+=source[y*width+x]; for(let x=0;x<width;x++) { horizontal[y*width+x]=accept(count)?1:0; if(x-radius>=0) count-=source[y*width+x-radius]; if(x+radius+1<width) count+=source[y*width+x+radius+1]; } }
      for(let x=0;x<width;x++) { let count=0; for(let y=0;y<=Math.min(radius,height-1);y++) count+=horizontal[y*width+x]; for(let y=0;y<height;y++) { result[y*width+x]=accept(count)?2:0; if(y-radius>=0) count-=horizontal[(y-radius)*width+x]; if(y+radius+1<height) count+=horizontal[(y+radius+1)*width+x]; } }
      const out=Q.selectionFromRegion(result,width,height,0,0);
      if(!out) return {error:'Result would be empty; selection left unchanged'};
      if(out.error) return {error:'Result is too complex (maximum 4096 runs)'};
      return {selection:out};
    } catch(e) { return {error:'Not enough memory to resize selection'}; }
  };

  // Square-radius hard border, with canvas exterior treated as unselected.
  // Morphological passes are linear in pixels; no intermediate run limit.
  Q.selectionBorder = function(selection,width,height,radius,side) {
    if(!selection)return {error:'Make a selection first'};
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width*height>4*1024*1024)return {error:'Canvas exceeds the 4 megapixel selection limit'};
    if(!Number.isInteger(radius)||radius<1||radius>32||!['inside','outside','center'].includes(side))return {error:'Choose a radius from 1 to 32 pixels and a valid border side'};
    if(![selection.x,selection.y,selection.w,selection.h].every(Number.isInteger)||selection.x<0||selection.y<0||selection.w<1||selection.h<1||selection.x+selection.w>width||selection.y+selection.h>height)return {error:'Invalid selection'};
    try {
      const original=Q.selectionMask(selection),source=new Uint8Array(width*height),horizontal=new Uint8Array(width*height),region=new Uint8Array(width*height),size=radius*2+1;
      for(let y=0;y<selection.h;y++)for(let x=0;x<selection.w;x++)if(!original || original[y*selection.w+x])source[(selection.y+y)*width+selection.x+x]=1;
      function pass(grow) {
        const accept=n=>grow ? n>0 : n===size;
        for(let y=0;y<height;y++){let count=0;for(let x=0;x<=Math.min(radius,width-1);x++)count+=source[y*width+x];for(let x=0;x<width;x++){horizontal[y*width+x]=accept(count)?1:0;if(x-radius>=0)count-=source[y*width+x-radius];if(x+radius+1<width)count+=source[y*width+x+radius+1];}}
        for(let x=0;x<width;x++){let count=0;for(let y=0;y<=Math.min(radius,height-1);y++)count+=horizontal[y*width+x];for(let y=0;y<height;y++){const n=y*width+x,matched=accept(count);if(grow ? (matched && !source[n]) : (source[n] && !matched))region[n]=2;if(y-radius>=0)count-=horizontal[(y-radius)*width+x];if(y+radius+1<height)count+=horizontal[(y+radius+1)*width+x];}}
      }
      if(side!=='inside')pass(true);if(side!=='outside')pass(false);
      const out=Q.selectionFromRegion(region,width,height,0,0);
      if(!out)return {error:'Border would be empty; selection left unchanged'};
      if(out.error)return {error:'Border is too complex (maximum 4096 runs)'};
      return {selection:out};
    } catch(e) {return {error:'Not enough memory to build selection border'};}
  };

  // Soft coverage for one-off fill/clear; this does not change the selection.
  Q.planFeatherEdit = function(selection,width,height,radius,needsCel) {
    if(!selection)return {error:'Make a selection first'};
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||!Number.isInteger(radius)||radius<1||radius>32)return {error:'Choose a radius from 1 to 32 pixels'};
    if(![selection.x,selection.y,selection.w,selection.h].every(Number.isInteger)||selection.x<0||selection.y<0||selection.w<1||selection.h<1||selection.x+selection.w>width||selection.y+selection.h>height)return {error:'Invalid selection bounds'};
    const x=Math.max(0,selection.x-radius),y=Math.max(0,selection.y-radius),right=Math.min(width,selection.x+selection.w+radius),bottom=Math.min(height,selection.y+selection.h+radius),w=right-x,h=bottom-y,area=w*h;
    if(area>4*1024*1024 || area*48+(needsCel ? width*height*4 : 0)>64*1024*1024)return {error:'Feather edit exceeds 4 MP or estimated 64 MiB temporary memory'};
    return {x:x,y:y,w:w,h:h,radius:radius};
  };
  // Fixed denominator treats pixels outside the canvas/mask as transparent.
  Q.boxBlurCoverage = function(source,w,h,radius) {
    if(!source || source.length!==w*h || !Number.isInteger(radius) || radius<0 || radius>32)throw Error('Invalid mask');
    if(radius===0)return new Uint8Array(source);
    const tmp=new Float32Array(w*h),out=new Uint8Array(w*h),size=2*radius+1;
    for(let y=0;y<h;y++){let sum=0;for(let x=0;x<=Math.min(radius,w-1);x++)sum+=source[y*w+x];for(let x=0;x<w;x++){tmp[y*w+x]=sum/size;if(x-radius>=0)sum-=source[y*w+x-radius];if(x+radius+1<w)sum+=source[y*w+x+radius+1];}}
    for(let x=0;x<w;x++){let sum=0;for(let y=0;y<=Math.min(radius,h-1);y++)sum+=tmp[y*w+x];for(let y=0;y<h;y++){out[y*w+x]=Math.round(sum/size);if(y-radius>=0)sum-=tmp[(y-radius)*w+x];if(y+radius+1<h)sum+=tmp[(y+radius+1)*w+x];}}
    return out;
  };
  Q.featherSelectionCoverage = function(selection,plan) {
    const original=Q.selectionMask(selection),source=new Uint8Array(plan.w*plan.h);
    for(let y=0;y<selection.h;y++)for(let x=0;x<selection.w;x++)if(!original || original[y*selection.w+x])source[(selection.y+y-plan.y)*plan.w+selection.x+x-plan.x]=255;
    return Q.boxBlurCoverage(source,plan.w,plan.h,plan.radius);
  };

  Q.intersectRect = function (a, b) {
    const x=Math.max(a.x,b.x), y=Math.max(a.y,b.y);
    const right=Math.min(a.x+a.w,b.x+b.w), bottom=Math.min(a.y+a.h,b.y+b.h);
    return right > x && bottom > y ? {x:x,y:y,w:right-x,h:bottom-y} : null;
  };
  // Geometry and allocation checks shared by the precision dialog and commit.
  Q.planPreciseTransform = function (src,canvasWidth,canvasHeight,o) {
    if (!src || !o || !Number.isInteger(src.x) || !Number.isInteger(src.y) || !Number.isInteger(src.w) || !Number.isInteger(src.h) || src.w<1 || src.h<1 || src.x<0 || src.y<0 || src.x+src.w>canvasWidth || src.y+src.h>canvasHeight) return {error:'Choose a valid rectangular selection'};
    if (!Number.isInteger(o.dx) || !Number.isInteger(o.dy) || Math.abs(o.dx)>canvasWidth*2 || Math.abs(o.dy)>canvasHeight*2) return {error:'Move offsets must be whole pixels within twice the canvas size'};
    if (!Number.isInteger(o.width) || !Number.isInteger(o.height) || o.width<1 || o.height<1 || o.width>Math.min(8192,canvasWidth*4) || o.height>Math.min(8192,canvasHeight*4)) return {error:'Width and height must be whole pixels within the size limit'};
    if (!Number.isFinite(o.angle) || Math.abs(o.angle)>360 || !['smooth','nearest'].includes(o.resampling)) return {error:'Angle must be between −360° and 360°'};
    const theta=o.angle*Math.PI/180, cos=Math.cos(theta), sin=Math.sin(theta), cx=src.x+src.w/2+o.dx, cy=src.y+src.h/2+o.dy;
    const hw=o.width/2, hh=o.height/2, points=[[-hw,-hh],[hw,-hh],[hw,hh],[-hw,hh]].map(([x,y])=>({x:cx+x*cos-y*sin,y:cy+x*sin+y*cos}));
    function stable(x) { const r=Math.round(x); return Math.abs(x-r)<1e-9 ? r : x; }
    const left=Math.floor(stable(Math.min(...points.map(p=>p.x)))), top=Math.floor(stable(Math.min(...points.map(p=>p.y))));
    const right=Math.ceil(stable(Math.max(...points.map(p=>p.x)))), bottom=Math.ceil(stable(Math.max(...points.map(p=>p.y))));
    const bounds={x:left,y:top,w:right-left,h:bottom-top};
    const union={x:Math.min(src.x,left),y:Math.min(src.y,top),w:Math.max(src.x+src.w,right)-Math.min(src.x,left),h:Math.max(src.y+src.h,bottom)-Math.min(src.y,top)};
    const rect=Q.intersectRect(union,{x:0,y:0,w:canvasWidth,h:canvasHeight});
    if ((src.w*src.h+3*rect.w*rect.h)*4>64*1024*1024) return {error:'Transform needs more than the 64 MiB temporary-memory limit'};
    const angle=((o.angle%360)+360)%360, unchanged=o.dx===0 && o.dy===0 && o.width===src.w && o.height===src.h && angle===0;
    return {src:{...src},cx:cx,cy:cy,theta:theta,bounds:bounds,rect:rect,points:points,clipped:left<0 || top<0 || right>canvasWidth || bottom>canvasHeight,unchanged:unchanged};
  };

  Q.flipImage = function (image, horizontal, vertical) {
    const w=image.width, h=image.height, data=image.data;
    if (!horizontal && !vertical) return;
    // Swap each pair once, in place, preserving RGBA bytes exactly.
    for (let y=0; y<h; y++) for (let x=0; x<w; x++) {
      const targetX=horizontal ? w-1-x : x, targetY=vertical ? h-1-y : y;
      const a=y*w+x, b=targetY*w+targetX;
      if (a >= b) continue;
      for (let channel=0; channel<4; channel++) {
        const i=a*4+channel, j=b*4+channel, value=data[i]; data[i]=data[j]; data[j]=value;
      }
    }
  };
  // A 3×3 piecewise-affine mesh with nearest or premultiplied-alpha bilinear sampling.
  Q.transformGrid = function (r) { return Array.from({length:9},(_,i)=>({x:r.x+(i%3)*r.w/2,y:r.y+Math.floor(i/3)*r.h/2})); };
  Q.transformQuad = function (p) {
    const corners=[p[0],p[2],p[6],p[8]];
    return Array.from({length:9},(_,i)=>{const u=(i%3)/2,v=Math.floor(i/3)/2;return {x:(1-u)*(1-v)*corners[0].x+u*(1-v)*corners[1].x+(1-u)*v*corners[2].x+u*v*corners[3].x,y:(1-u)*(1-v)*corners[0].y+u*(1-v)*corners[1].y+(1-u)*v*corners[2].y+u*v*corners[3].y};});
  };
  Q.meshTriangles = function () { const a=[]; for(let y=0;y<2;y++) for(let x=0;x<2;x++) {const i=y*3+x; a.push([i,i+1,i+4],[i,i+4,i+3]);} return a; };
  Q.planMeshTransform = function (src,pts,w,h,hasFlip) {
    if(!Array.isArray(pts) || pts.length!==9 || pts.some(p=>!p || !Number.isFinite(p.x) || !Number.isFinite(p.y) || Math.abs(p.x)>w*3 || Math.abs(p.y)>h*3)) return {error:'Invalid handles'};
    for(const [i,j,k] of Q.meshTriangles()) {const a=pts[i],b=pts[j],c=pts[k]; if((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)<0.05) return {error:'Handles cross or collapse; move them apart'};}
    const original=Q.transformGrid(src); if(!hasFlip && pts.every((p,i)=>Math.abs(p.x-original[i].x)<0.001 && Math.abs(p.y-original[i].y)<0.001)) return {error:'Nothing changed'};
    const minX=Math.floor(Math.min(src.x,...pts.map(p=>p.x))),minY=Math.floor(Math.min(src.y,...pts.map(p=>p.y))),maxX=Math.ceil(Math.max(src.x+src.w,...pts.map(p=>p.x))),maxY=Math.ceil(Math.max(src.y+src.h,...pts.map(p=>p.y)));
    const rect=Q.intersectRect({x:minX,y:minY,w:maxX-minX,h:maxY-minY},{x:0,y:0,w:w,h:h});
    if(!rect || rect.w*rect.h>2*1024*1024 || src.w*src.h>2*1024*1024 || 16*src.w*src.h+40*rect.w*rect.h>64*1024*1024) return {error:'Transform exceeds the 2 MP or estimated 64 MiB limit; select a smaller area'};
    const bounds=Q.intersectRect({x:Math.floor(Math.min(...pts.map(p=>p.x))),y:Math.floor(Math.min(...pts.map(p=>p.y))),w:Math.ceil(Math.max(...pts.map(p=>p.x)))-Math.floor(Math.min(...pts.map(p=>p.x))),h:Math.ceil(Math.max(...pts.map(p=>p.y)))-Math.floor(Math.min(...pts.map(p=>p.y)))},{x:0,y:0,w:w,h:h});
    return {rect:rect,bounds:bounds};
  };
  Q.rasterMesh = function (source,pts,rect,sampling,flips) {
    const out=new Uint8ClampedArray(rect.w*rect.h*4), sw=source.width,sh=source.height, data=source.data;
    for(const [ia,ib,ic] of Q.meshTriangles()) {
      const a=pts[ia],b=pts[ib],c=pts[ic], det=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
      const x0=Math.max(rect.x,Math.floor(Math.min(a.x,b.x,c.x))),x1=Math.min(rect.x+rect.w,Math.ceil(Math.max(a.x,b.x,c.x))),y0=Math.max(rect.y,Math.floor(Math.min(a.y,b.y,c.y))),y1=Math.min(rect.y+rect.h,Math.ceil(Math.max(a.y,b.y,c.y)));
      for(let y=y0;y<y1;y++) for(let x=x0;x<x1;x++) {
        const dx=x+0.5-a.x,dy=y+0.5-a.y, u=(dx*(c.y-a.y)-dy*(c.x-a.x))/det,v=((b.x-a.x)*dy-(b.y-a.y)*dx)/det;
        if(u< -1e-8 || v< -1e-8 || u+v>1+1e-8) continue;
        let fx=((ia%3)*(1-u-v)+(ib%3)*u+(ic%3)*v)*sw/2, fy=(Math.floor(ia/3)*(1-u-v)+Math.floor(ib/3)*u+Math.floor(ic/3)*v)*sh/2; const di=((y-rect.y)*rect.w+x-rect.x)*4; if(flips && flips.x) fx=sw-fx; if(flips && flips.y) fy=sh-fy;
        if(sampling==='mask') {const sx=Math.min(sw-1,Math.max(0,Math.floor(fx))),sy=Math.min(sh-1,Math.max(0,Math.floor(fy)));out[di+3]=!source.mask || source.mask[sy*sw+sx] ? 255 : 0;}
        else if(sampling!=='smooth') { const sx=Math.min(sw-1,Math.max(0,Math.floor(fx))),sy=Math.min(sh-1,Math.max(0,Math.floor(fy))),si=(sy*sw+sx)*4;out[di]=data[si];out[di+1]=data[si+1];out[di+2]=data[si+2];out[di+3]=data[si+3]; }
        else {
          const xx=Math.max(0,Math.min(sw-1,fx-0.5)),yy=Math.max(0,Math.min(sh-1,fy-0.5)),x0=Math.floor(xx),y0=Math.floor(yy),x1=Math.min(sw-1,x0+1),y1=Math.min(sh-1,y0+1), tx=xx-x0,ty=yy-y0;
          const i00=(y0*sw+x0)*4,i10=(y0*sw+x1)*4,i01=(y1*sw+x0)*4,i11=(y1*sw+x1)*4,w00=(1-tx)*(1-ty)*data[i00+3],w10=tx*(1-ty)*data[i10+3],w01=(1-tx)*ty*data[i01+3],w11=tx*ty*data[i11+3],alpha=w00+w10+w01+w11;
          out[di+3]=alpha;if(alpha>0) for(let ch=0;ch<3;ch++) out[di+ch]=(data[i00+ch]*w00+data[i10+ch]*w10+data[i01+ch]*w01+data[i11+ch]*w11)/alpha;
        }
      }
    }
    return out;
  };
  // Transform a hard selection mask using the same triangles as the artwork.
  // Refuse empty or highly fragmented output before any artwork is modified.
  Q.meshSelection = function (src,mask,pts,rect,flips) {
    const rgba=Q.rasterMesh({width:src.w,height:src.h,mask:mask},pts,rect,'mask',flips),region=new Uint8Array(rect.w*rect.h);
    for(let i=0;i<region.length;i++) if(rgba[i*4+3]) region[i]=2;
    const selection=Q.selectionFromRegion(region,rect.w,rect.h,rect.x,rect.y);
    if(!selection) return {error:'Transformed selection would be empty; move it back on canvas'};
    if(selection.error) return {error:'Transformed selection is too complex (maximum 4096 runs)'};
    if(selection.runs.length===selection.h && selection.runs.every(run=>run.x===selection.x && run.w===selection.w)) delete selection.runs;
    return {selection:selection};
  };

})();
