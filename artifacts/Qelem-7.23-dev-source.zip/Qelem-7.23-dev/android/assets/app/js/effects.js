/* Destructive, undoable pixel effects. All operations preserve the canvas size. */
(function () {
  'use strict';
  const Q = window.Q;

  function boxBlur(data, width, height, radius) {
    // Two sliding-window passes are O(width * height), regardless of radius.
    const temp = new Uint8ClampedArray(data.length);
    // Blur premultiplied channels to avoid dark fringes around transparency.
    for (let i = 0; i < data.length; i += 4) {
      const a = data[i + 3] / 255;
      data[i] *= a; data[i + 1] *= a; data[i + 2] *= a;
    }
    for (let y = 0; y < height; y++) {
      for (let ch = 0; ch < 4; ch++) {
        let sum = 0;
        for (let x = 0; x <= Math.min(width - 1, radius); x++) sum += data[(y * width + x) * 4 + ch];
        for (let x = 0; x < width; x++) {
          const left = Math.max(0, x - radius), right = Math.min(width - 1, x + radius);
          temp[(y * width + x) * 4 + ch] = sum / (right - left + 1);
          if (x - radius >= 0) sum -= data[(y * width + x - radius) * 4 + ch];
          if (x + radius + 1 < width) sum += data[(y * width + x + radius + 1) * 4 + ch];
        }
      }
    }
    for (let x = 0; x < width; x++) {
      for (let ch = 0; ch < 4; ch++) {
        let sum = 0;
        for (let y = 0; y <= Math.min(height - 1, radius); y++) sum += temp[(y * width + x) * 4 + ch];
        for (let y = 0; y < height; y++) {
          const top = Math.max(0, y - radius), bottom = Math.min(height - 1, y + radius);
          data[(y * width + x) * 4 + ch] = sum / (bottom - top + 1);
          if (y - radius >= 0) sum -= temp[((y - radius) * width + x) * 4 + ch];
          if (y + radius + 1 < height) sum += temp[((y + radius + 1) * width + x) * 4 + ch];
        }
      }
    }
    for (let i = 0; i < data.length; i += 4) {
      const alpha = data[i + 3];
      if (alpha) { data[i] = data[i] * 255 / alpha; data[i + 1] = data[i + 1] * 255 / alpha; data[i + 2] = data[i + 2] * 255 / alpha; }
    }
  }

  function motionBlur(data, width, height, radius) {
    const src = new Uint8ClampedArray(data);
    // Premultiplied horizontal moving average, O(width * height).
    for (let i = 0; i < src.length; i += 4) {
      const a = src[i + 3] / 255; src[i] *= a; src[i + 1] *= a; src[i + 2] *= a;
    }
    for (let y = 0; y < height; y++) for (let channel = 0; channel < 4; channel++) {
      let sum = 0;
      for (let x = 0; x <= Math.min(width - 1, radius); x++) sum += src[(y * width + x) * 4 + channel];
      for (let x = 0; x < width; x++) {
        const left = Math.max(0, x - radius), right = Math.min(width - 1, x + radius);
        data[(y * width + x) * 4 + channel] = sum / (right - left + 1);
        if (x - radius >= 0) sum -= src[(y * width + x - radius) * 4 + channel];
        if (x + radius + 1 < width) sum += src[(y * width + x + radius + 1) * 4 + channel];
      }
    }
    for (let i = 0; i < data.length; i += 4) {
      const alpha = data[i + 3];
      if (alpha) { data[i] = data[i] * 255 / alpha; data[i + 1] = data[i + 1] * 255 / alpha; data[i + 2] = data[i + 2] * 255 / alpha; }
    }
  }

  function sharpen(data, width, height, strength) {
    const soft = new Uint8ClampedArray(data);
    boxBlur(soft, width, height, 2);
    for (let i = 0; i < data.length; i += 4) {
      if (!data[i + 3]) continue;
      for (let c = 0; c < 3; c++) data[i+c] += (data[i+c] - soft[i+c]) * strength * 1.5;
    }
  }

  function bloom(data, width, height, strength) {
    const glow = new Uint8ClampedArray(data);
    for (let i = 0; i < glow.length; i += 4) {
      const highlight = Q.clamp((Math.max(glow[i], glow[i+1], glow[i+2]) - 150) / 105, 0, 1);
      glow[i+3] *= highlight;
    }
    boxBlur(glow, width, height, Math.max(1, Math.round(strength * 12)));
    for (let i = 0; i < data.length; i += 4) {
      const a = data[i+3] / 255, g = glow[i+3] / 255 * strength * 0.65;
      const out = a + g * (1 - a);
      if (!out) continue;
      for (let c = 0; c < 3; c++) {
        data[i+c] = (data[i+c] * a + glow[i+c] * g * (1-a)) / out + glow[i+c] * g * a * 0.35;
      }
      data[i+3] = out * 255;
    }
  }

  function glitch(data, width, height, strength) {
    const src = new Uint8ClampedArray(data), shift = Math.max(1, Math.round(strength * 30));
    const band = Math.max(1, Math.round(height / 24));
    for (let y = 0; y < height; y++) {
      const offset = (Math.floor(y / band) % 3 - 1) * shift;
      for (let x = 0; x < width; x++) {
        const from = (y * width + Q.clamp(x + offset, 0, width - 1)) * 4, to = (y * width + x) * 4;
        data[to] = src[from]; data[to+1] = src[from+1]; data[to+2] = src[from+2]; data[to+3] = src[from+3];
      }
    }
  }

  function pixelate(data,width,height,size) {
    // Each block averages premultiplied colour to avoid dark transparent fringes.
    for (let y=0;y<height;y+=size) for (let x=0;x<width;x+=size) {
      const right=Math.min(width,x+size), bottom=Math.min(height,y+size);
      let alpha=0,r=0,g=0,b=0,count=0;
      for (let yy=y;yy<bottom;yy++) for (let xx=x;xx<right;xx++) {
        const i=(yy*width+xx)*4,a=data[i+3]; alpha+=a; r+=data[i]*a; g+=data[i+1]*a; b+=data[i+2]*a; count++;
      }
      const outA=alpha/count, outR=alpha ? r/alpha : 0, outG=alpha ? g/alpha : 0, outB=alpha ? b/alpha : 0;
      for (let yy=y;yy<bottom;yy++) for (let xx=x;xx<right;xx++) {
        const i=(yy*width+xx)*4; data[i]=outR; data[i+1]=outG; data[i+2]=outB; data[i+3]=outA;
      }
    }
  }

  Q.applyPixelEffect = function (image, type, amount) {
    const data = image.data, w = image.width, h = image.height;
    const strength = Q.clamp(Number(amount) || 0, 0, 1);
    if (!strength) return image;
    if (type === 'blur') {
      // Three box passes provide a bounded, Gaussian-like soft blur. This is
      // an approximation, not an exact Gaussian kernel.
      const radius=Math.max(1,Math.round(strength*9));
      boxBlur(data,w,h,radius); boxBlur(data,w,h,radius); boxBlur(data,w,h,radius);
      return image;
    }
    if (type === 'motion') { motionBlur(data, w, h, Math.max(1, Math.round(strength * 32))); return image; }
    if (type === 'sharpen') { sharpen(data, w, h, strength); return image; }
    if (type === 'bloom') { bloom(data, w, h, strength); return image; }
    if (type === 'glitch') { glitch(data, w, h, strength); return image; }
    if (type === 'pixelate') { pixelate(data,w,h,Math.max(2,Math.round(2+strength*30))); return image; }
    const supported = ['grayscale', 'invert', 'sepia', 'brightness', 'saturation', 'contrast', 'hue', 'noise', 'threshold', 'halftone', 'chromatic', 'posterize', 'solarize'];
    const original = type === 'chromatic' ? new Uint8ClampedArray(data) : null;
    if (supported.indexOf(type) < 0) throw new Error('Unknown effect');
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      const gray = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      let nr = r, ng = g, nb = b;
      if (type === 'grayscale') { nr = ng = nb = gray; }
      else if (type === 'invert') { nr = 255-r; ng = 255-g; nb = 255-b; }
      else if (type === 'sepia') { nr = .393*r+.769*g+.189*b; ng = .349*r+.686*g+.168*b; nb = .272*r+.534*g+.131*b; }
      else if (type === 'brightness') { nr = r + 100; ng = g + 100; nb = b + 100; }
      else if (type === 'saturation') { nr = gray + (r-gray)*2; ng = gray + (g-gray)*2; nb = gray + (b-gray)*2; }
      else if (type === 'contrast') { nr=(r-128)*2+128; ng=(g-128)*2+128; nb=(b-128)*2+128; }
      else if (type === 'hue') { const hsv=Q.rgbToHsv(r,g,b); const rgb=Q.hsvToRgb(hsv[0]+180*strength,hsv[1],hsv[2]); data[i]=rgb[0]; data[i+1]=rgb[1]; data[i+2]=rgb[2]; continue; }
      else if (type === 'chromatic') {
        const pixel=i/4, x=pixel%w, y=Math.floor(pixel/w), shift=Math.max(1,Math.round(strength*12));
        nr=original[(y*w+Math.max(0,x-shift))*4]; nb=original[(y*w+Math.min(w-1,x+shift))*4+2];
      }
      else if (type === 'halftone') {
        const pixel=i/4, x=pixel%w, y=Math.floor(pixel/w), matrix=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];
        nr = ng = nb = gray >= (matrix[(y%4)*4+(x%4)]+0.5)*16 ? 255 : 0;
      }
      else if (type === 'posterize') { nr=Math.round(r/85)*85; ng=Math.round(g/85)*85; nb=Math.round(b/85)*85; }
      else if (type === 'solarize') { nr=r>=128 ? 255-r : r; ng=g>=128 ? 255-g : g; nb=b>=128 ? 255-b : b; }
      else if (type === 'threshold') { nr = ng = nb = gray >= 128 ? 255 : 0; }
      else if (type === 'noise') { const n = (Math.random() - .5) * 160; nr = r+n; ng = g+n; nb = b+n; }
      data[i] = r + (nr-r)*strength;
      data[i+1] = g + (ng-g)*strength;
      data[i+2] = b + (nb-b)*strength;
    }
    return image;
  };
  // Three-stop luminance gradient map; transparent pixels and alpha are untouched.
  Q.gradientMap = function (image,colors,strength,mask) {
    if(!Array.isArray(colors) || colors.length!==3 || colors.some(c=>!Array.isArray(c) || c.length!==3 || c.some(n=>!Number.isInteger(n) || n<0 || n>255)) || !Number.isFinite(strength) || strength<0 || strength>1) throw new Error('Invalid gradient map');
    const lut=new Uint8ClampedArray(256*3);
    for(let n=0;n<256;n++) {const t=n/255*2,i=t<1 ? 0 : 1,f=t-i;for(let c=0;c<3;c++)lut[n*3+c]=colors[i][c]*(1-f)+colors[i+1][c]*f;}
    const d=image.data,w=image.width,h=image.height;let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let n=0;n<w*h;n++) {const i=n*4;if(!d[i+3] || (mask && !mask[n]) || strength===0)continue;const l=Math.round(0.2126*d[i]+0.7152*d[i+1]+0.0722*d[i+2])*3;
      const r=Math.round(d[i]+(lut[l]-d[i])*strength),g=Math.round(d[i+1]+(lut[l+1]-d[i+1])*strength),b=Math.round(d[i+2]+(lut[l+2]-d[i+2])*strength);if(r===d[i] && g===d[i+1] && b===d[i+2])continue;
      d[i]=r;d[i+1]=g;d[i+2]=b;const x=n%w,y=Math.floor(n/w);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
    }
    return maxX<0 ? null : {x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1};
  };
  // RGB-axis colour offsets, weighted by original luminance. Alpha is unchanged.
  Q.validColorBalance = function(settings) {
    return !!settings && ['shadows','midtones','highlights'].every(k=>Array.isArray(settings[k]) && settings[k].length===3 && settings[k].every(v=>Number.isInteger(v) && v>=-100 && v<=100));
  };
  Q.applyColorBalance = function(image,settings,mask) {
    if(!Q.validColorBalance(settings))throw Error('Invalid colour balance');
    const d=image.data,w=image.width,h=image.height;let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let n=0;n<w*h;n++) {const i=n*4;if(!d[i+3] || (mask && !mask[n]))continue;
      const l=(.2126*d[i]+.7152*d[i+1]+.0722*d[i+2])/255,shadow=Math.max(0,1-2*l),highlight=Math.max(0,2*l-1),mid=1-shadow-highlight;
      const red=Math.round(Q.clamp(d[i]+1.275*(settings.shadows[0]*shadow+settings.midtones[0]*mid+settings.highlights[0]*highlight),0,255));
      const green=Math.round(Q.clamp(d[i+1]+1.275*(settings.shadows[1]*shadow+settings.midtones[1]*mid+settings.highlights[1]*highlight),0,255));
      const blue=Math.round(Q.clamp(d[i+2]+1.275*(settings.shadows[2]*shadow+settings.midtones[2]*mid+settings.highlights[2]*highlight),0,255));
      if(red===d[i] && green===d[i+1] && blue===d[i+2])continue;
      d[i]=red;d[i+1]=green;d[i+2]=blue;const x=n%w,y=Math.floor(n/w);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
    }
    return maxX<0 ? null : {x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1};
  };
  // Independent one-shot tonal adjustments, operating on straight RGB with unchanged alpha.
  Q.validTonalAdjustment = function(type,values) {
    const integer=(n,min,max)=>Number.isInteger(n)&&n>=min&&n<=max;
    if(!values || typeof values!=='object')return false;
    if(type==='levels')return integer(values.black,0,254)&&integer(values.white,1,255)&&values.black<values.white&&integer(values.gamma,25,400);
    if(type==='vibrance')return integer(values.amount,-100,100);
    if(type==='temperature')return integer(values.warmth,-100,100)&&integer(values.tint,-100,100);
    return false;
  };
  Q.applyTonalAdjustment = function(image,type,values,mask) {
    if(!Q.validTonalAdjustment(type,values))throw Error('Invalid adjustment settings');
    let lut=null;if(type==='levels'){lut=new Uint8Array(256);for(let x=0;x<256;x++)lut[x]=Math.round(255*Math.pow(Q.clamp((x-values.black)/(values.white-values.black),0,1),100/values.gamma));}
    const d=image.data,w=image.width,h=image.height;let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let n=0;n<w*h;n++){const i=n*4;if(!d[i+3] || (mask && !mask[n]))continue;const r=d[i],g=d[i+1],b=d[i+2];let nr,ng,nb;
      if(type==='levels'){nr=lut[r];ng=lut[g];nb=lut[b];}
      else if(type==='temperature'){nr=r+values.warmth*.75;ng=g+values.tint*.75;nb=b-values.warmth*.75;}
      else {const l=.2126*r+.7152*g+.0722*b,s=(Math.max(r,g,b)-Math.min(r,g,b))/255,a=values.amount/100,f=a>=0 ? 1+1.5*a*(1-s) : 1+a;nr=l+(r-l)*f;ng=l+(g-l)*f;nb=l+(b-l)*f;}
      nr=Math.round(Q.clamp(nr,0,255));ng=Math.round(Q.clamp(ng,0,255));nb=Math.round(Q.clamp(nb,0,255));if(nr===r&&ng===g&&nb===b)continue;
      d[i]=nr;d[i+1]=ng;d[i+2]=nb;const x=n%w,y=Math.floor(n/w);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
    }
    return maxX<0 ? null : {x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1};
  };
  // Square/Chebyshev alpha dilation. Two linear-time sliding maximum passes.
  Q.outlineAlpha = function(source,output,radius,color,opacity) {
    const w=source.width,h=source.height,n=w*h;if(!Number.isInteger(radius)||radius<1||radius>32||!Array.isArray(color)||color.length!==3||color.some(v=>!Number.isInteger(v)||v<0||v>255)||!Number.isFinite(opacity)||opacity<=0||opacity>1||output.width!==w||output.height!==h)throw Error('Invalid outline settings');
    const src=source.data,dst=output.data,temp=new Uint8Array(n),deque=new Int32Array(Math.max(w,h));let changed=false;
    for(let y=0;y<h;y++){let head=0,tail=0,next=0;for(let x=0;x<w;x++){const stop=Math.min(w-1,x+radius);while(next<=stop){const a=src[(y*w+next)*4+3];while(tail>head && src[(y*w+deque[tail-1])*4+3]<=a)tail--;deque[tail++]=next++;}while(tail>head && deque[head]<x-radius)head++;temp[y*w+x]=src[(y*w+deque[head])*4+3];}}
    for(let x=0;x<w;x++){let head=0,tail=0,next=0;for(let y=0;y<h;y++){const stop=Math.min(h-1,y+radius);while(next<=stop){const a=temp[next*w+x];while(tail>head && temp[deque[tail-1]*w+x]<=a)tail--;deque[tail++]=next++;}while(tail>head && deque[head]<y-radius)head++;const i=(y*w+x)*4,alpha=Math.round(Math.max(0,temp[deque[head]*w+x]-src[i+3])*opacity);if(alpha){dst[i]=color[0];dst[i+1]=color[1];dst[i+2]=color[2];dst[i+3]=alpha;changed=true;}}}
    return changed;
  };
  // Offset raw alpha first, then box-blur with transparent pixels beyond canvas.
  Q.softShadowPixels = function(source,output,options) {
    const w=source.width,h=source.height,o=options;
    if(!o || !['shadow','glow'].includes(o.kind) || !Number.isInteger(o.blur)||o.blur<0||o.blur>32||!Number.isInteger(o.dx)||!Number.isInteger(o.dy)||Math.abs(o.dx)>128||Math.abs(o.dy)>128 || (o.kind==='glow' && (o.dx!==0 || o.dy!==0)) || !Array.isArray(o.color)||o.color.length!==3||o.color.some(v=>!Number.isInteger(v)||v<0||v>255)||!Number.isFinite(o.opacity)||o.opacity<=0||o.opacity>1||output.width!==w||output.height!==h)throw Error('Invalid shadow settings');
    const alpha=new Uint8Array(w*h),src=source.data,dst=output.data;
    for(let y=0;y<h;y++){const sy=y-o.dy;if(sy<0||sy>=h)continue;for(let x=0;x<w;x++){const sx=x-o.dx;if(sx>=0&&sx<w)alpha[y*w+x]=src[(sy*w+sx)*4+3];}}
    const blurred=Q.boxBlurCoverage(alpha,w,h,o.blur);let changed=false;
    for(let n=0;n<w*h;n++){const a=Math.round(blurred[n]*o.opacity);if(a){const i=n*4;dst[i]=o.color[0];dst[i+1]=o.color[1];dst[i+2]=o.color[2];dst[i+3]=a;changed=true;}}
    return changed;
  };
  Q.validateShapeLayer = function(o,w,h){
    const color=c=>Array.isArray(c)&&c.length===3&&c.every(v=>Number.isInteger(v)&&v>=0&&v<=255);
    if(!o||!['rectangle','ellipse','polygon','star'].includes(o.kind)||!Number.isInteger(o.x)||!Number.isInteger(o.y)||o.x<0||o.x>w||o.y<0||o.y>h||!Number.isInteger(o.width)||!Number.isInteger(o.height)||o.width<1||o.height<1||o.width>w*2||o.height>h*2||!Number.isInteger(o.angle)||o.angle< -180||o.angle>180||!Number.isInteger(o.sides)||o.sides<3||o.sides>12||!Number.isInteger(o.inner)||o.inner<10||o.inner>90||!Number.isInteger(o.strokeWidth)||o.strokeWidth<1||o.strokeWidth>128||typeof o.fill!=='boolean'||typeof o.stroke!=='boolean'||(!o.fill&&!o.stroke)||!color(o.fillColor)||!color(o.strokeColor)||!Number.isFinite(o.opacity)||o.opacity<=0||o.opacity>1)return 'Choose valid shape settings; enable fill or stroke.';
    return null;
  };
  Q.drawShapeLayer = function(ctx,o){
    ctx.save();ctx.translate(o.x,o.y);ctx.rotate(o.angle*Math.PI/180);ctx.globalAlpha=o.opacity;ctx.beginPath();
    const rx=o.width/2,ry=o.height/2;
    if(o.kind==='rectangle')ctx.rect(-rx,-ry,o.width,o.height);
    else if(o.kind==='ellipse')ctx.ellipse(0,0,rx,ry,0,0,2*Math.PI);
    else {const count=o.kind==='star'?o.sides*2:o.sides;for(let i=0;i<count;i++){const t=-Math.PI/2+i*2*Math.PI/count,ratio=o.kind==='star'&&i%2?o.inner/100:1,x=Math.cos(t)*rx*ratio,y=Math.sin(t)*ry*ratio;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.closePath();}
    if(o.fill){ctx.fillStyle=Q.rgba(o.fillColor,1);ctx.fill();}if(o.stroke){ctx.strokeStyle=Q.rgba(o.strokeColor,1);ctx.lineWidth=o.strokeWidth;ctx.lineJoin='round';ctx.stroke();}ctx.restore();
  };
  Q.validateTileLayer = function(o){return !!o&&['repeat','offset'].includes(o.kind)&&Number.isInteger(o.scale)&&o.scale>=10&&o.scale<=100&&Number.isInteger(o.dx)&&o.dx>=-4096&&o.dx<=4096&&Number.isInteger(o.dy)&&o.dy>=-4096&&o.dy<=4096&&['smooth','nearest'].includes(o.resampling);};
  Q.drawTileLayer = function(ctx,source,w,h,o){
    const scale=o.kind==='offset'?100:o.scale,tw=Math.max(1,Math.round(w*scale/100)),th=Math.max(1,Math.round(h*scale/100));let tile=source;
    if(tw!==source.width||th!==source.height){tile=Q.canvas(tw,th);const c=tile.getContext('2d');c.imageSmoothingEnabled=o.resampling==='smooth';c.drawImage(source,0,0,tw,th);}
    const pattern=ctx.createPattern(tile,'repeat');if(!pattern)throw Error('Pattern unavailable on this device');ctx.save();ctx.imageSmoothingEnabled=o.resampling==='smooth';ctx.translate(o.dx,o.dy);ctx.fillStyle=pattern;ctx.fillRect(-o.dx,-o.dy,w,h);ctx.restore();
  };
  Q.PROCEDURAL_PATTERNS=[['grid','Square grid'],['dots','Dot grid'],['checker','Checkerboard'],['horizontal','Horizontal stripes'],['vertical','Vertical stripes'],['diagonal','Diagonal stripes'],['crosshatch','Crosshatch'],['isometric','Isometric grid'],['brick','Brickwork']];
  Q.validProceduralPattern = function(o){const color=c=>Array.isArray(c)&&c.length===3&&c.every(v=>Number.isInteger(v)&&v>=0&&v<=255);return !!o&&Q.PROCEDURAL_PATTERNS.some(p=>p[0]===o.kind)&&Number.isInteger(o.spacing)&&o.spacing>=8&&o.spacing<=256&&Number.isInteger(o.weight)&&o.weight>=1&&o.weight<=24&&o.weight<=o.spacing&&color(o.color)&&color(o.background)&&typeof o.useBackground==='boolean'&&Number.isFinite(o.opacity)&&o.opacity>0&&o.opacity<=1&&['current','all'].includes(o.scope);};
  Q.proceduralPatternTile = function(o){
    if(!Q.validProceduralPattern(o))throw Error('Invalid pattern settings');const s=o.spacing,k=s*2,cv=Q.canvas(k,k),c=cv.getContext('2d');
    if(o.useBackground){c.fillStyle=Q.rgba(o.background,1);c.fillRect(0,0,k,k);}c.strokeStyle=Q.rgba(o.color,1);c.fillStyle=Q.rgba(o.color,1);c.lineWidth=o.weight;
    if(o.kind==='checker'){c.fillRect(0,0,s,s);c.fillRect(s,s,s,s);}
    else if(o.kind==='dots'){for(let y=0;y<2;y++)for(let x=0;x<2;x++){c.beginPath();c.arc((x+.5)*s,(y+.5)*s,o.weight/2,0,Math.PI*2);c.fill();}}
    else {c.beginPath();const h=()=>{for(let i=0;i<=2;i++){c.moveTo(0,i*s);c.lineTo(k,i*s);}},v=()=>{for(let i=0;i<=2;i++){c.moveTo(i*s,0);c.lineTo(i*s,k);}},diagonals=(reverse,slope)=>{for(let n=-4;n<=6;n++){const b=n*s;c.moveTo(0,b);c.lineTo(k,b+(reverse?-1:1)*slope*k);}};
      if(o.kind==='grid'){h();v();}else if(o.kind==='horizontal')h();else if(o.kind==='vertical')v();else if(o.kind==='diagonal')diagonals(false,1);else if(o.kind==='crosshatch'){diagonals(false,1);diagonals(true,1);}else if(o.kind==='isometric'){h();diagonals(false,.5);diagonals(true,.5);}else if(o.kind==='brick'){h();for(let row=0;row<2;row++)for(let n=-1;n<=2;n++){const x=(n+(row%2)*.5)*s;c.moveTo(x,row*s);c.lineTo(x,(row+1)*s);}}c.stroke();}
    return cv;
  };
  Q.fillProceduralPattern = function(ctx,w,h,o){const tile=Q.proceduralPatternTile(o),p=ctx.createPattern(tile,'repeat');if(!p)throw Error('Pattern unavailable');ctx.save();ctx.globalAlpha=o.opacity;ctx.fillStyle=p;ctx.fillRect(0,0,w,h);ctx.restore();};
  Q.paletteChart = function(colors,columns,labels){
    if(!Array.isArray(colors)||colors.length<1||colors.length>24||colors.some(c=>typeof c!=='string'||!/^#[0-9a-f]{6}$/i.test(c))||!Number.isInteger(columns)||columns<1||columns>6||typeof labels!=='boolean')throw Error('Invalid palette chart settings');
    const size=128,cellH=labels?96:72,rows=Math.ceil(colors.length/columns),cv=Q.canvas(columns*size,rows*cellH),c=cv.getContext('2d');c.fillStyle='#ffffff';c.fillRect(0,0,cv.width,cv.height);c.font='12px sans-serif';c.textAlign='center';c.textBaseline='middle';colors.forEach((hex,i)=>{const x=i%columns*size,y=Math.floor(i/columns)*cellH;c.fillStyle=hex;c.fillRect(x+4,y+4,size-8,labels?64:64);if(labels){c.fillStyle='#222222';c.fillText(hex.toUpperCase(),x+size/2,y+82);}});return cv;
  };
  Q.alphaBounds = function(image,threshold,padding){
    if(!Number.isInteger(threshold)||threshold<1||threshold>255||!Number.isInteger(padding)||padding<0||padding>128)throw Error('Invalid trim settings');const d=image.data,w=image.width,h=image.height;let x0=w,y0=h,x1=-1,y1=-1;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(d[(y*w+x)*4+3]>=threshold){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);}
    if(x1<0)return null;x0=Math.max(0,x0-padding);y0=Math.max(0,y0-padding);x1=Math.min(w-1,x1+padding);y1=Math.min(h-1,y1+padding);return {x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};
  };
  Q.channelImage = function(image,out,channel){
    if(!['red','green','blue','luminance','alpha'].includes(channel)||out.width!==image.width||out.height!==image.height)throw Error('Invalid channel');const s=image.data,d=out.data;for(let i=0;i<s.length;i+=4){const n=channel==='red'?s[i]:channel==='green'?s[i+1]:channel==='blue'?s[i+2]:channel==='alpha'?s[i+3]:Math.round(.2126*s[i]+.7152*s[i+1]+.0722*s[i+2]);d[i]=d[i+1]=d[i+2]=n;d[i+3]=channel==='alpha'?255:s[i+3];}
  };
  Q.imageHistogram = function(image,mask){
    const bins={red:new Uint32Array(256),green:new Uint32Array(256),blue:new Uint32Array(256),luminance:new Uint32Array(256),alpha:new Uint32Array(256)},d=image.data;let selected=0,visible=0,sum=0;
    for(let n=0;n<image.width*image.height;n++){if(mask&&!mask[n])continue;const i=n*4,a=d[i+3];selected++;bins.alpha[a]++;if(!a)continue;const l=Math.round(.2126*d[i]+.7152*d[i+1]+.0722*d[i+2]);bins.red[d[i]]++;bins.green[d[i+1]]++;bins.blue[d[i+2]]++;bins.luminance[l]++;visible++;sum+=l;}
    return {bins:bins,selected:selected,visible:visible,mean:visible?sum/visible:null};
  };
  Q.validAlphaTool = function(kind,o){const color=c=>Array.isArray(c)&&c.length===3&&c.every(v=>Number.isInteger(v)&&v>=0&&v<=255);return !!o&&(kind==='key'?color(o.color)&&Number.isInteger(o.tolerance)&&o.tolerance>=0&&o.tolerance<=255&&Number.isInteger(o.softness)&&o.softness>=0&&o.softness<=255:kind==='threshold'&&Number.isInteger(o.threshold)&&o.threshold>=1&&o.threshold<=255);};
  Q.applyAlphaTool = function(image,kind,o,mask){
    if(!Q.validAlphaTool(kind,o))throw Error('Invalid alpha settings');const d=image.data,w=image.width,h=image.height;let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let n=0;n<w*h;n++){if(mask&&!mask[n])continue;const i=n*4,a=d[i+3];let next;if(kind==='threshold')next=a>=o.threshold?255:0;else {const distance=Math.max(Math.abs(d[i]-o.color[0]),Math.abs(d[i+1]-o.color[1]),Math.abs(d[i+2]-o.color[2])),coverage=o.softness?Q.clamp((distance-o.tolerance)/o.softness,0,1):(distance<=o.tolerance?0:1);next=Math.round(a*coverage);}if(next===a)continue;d[i+3]=next;const x=n%w,y=Math.floor(n/w);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}
    return maxX<0?null:{x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1};
  };
  Q.studioEditOptionsValid = function(kind,o){
    if(!o)return false;if(kind==='contrast'||kind==='levels')return Number.isInteger(o.clip)&&o.clip>=0&&o.clip<=10;
    if(kind==='palette'||kind==='dither')return Array.isArray(o.palette)&&o.palette.length>=2&&o.palette.length<=24&&o.palette.every(c=>Array.isArray(c)&&c.length===3&&c.every(v=>Number.isInteger(v)&&v>=0&&v<=255))&&Number.isInteger(o.strength)&&o.strength>=0&&o.strength<=100;
    if(kind==='mask')return typeof o.invert==='boolean';return false;
  };
  Q.applyStudioEdit = function(image,kind,o,mask,source,offsetX,offsetY){
    if(!Q.studioEditOptionsValid(kind,o)||(kind==='mask'&&(!source||source.width!==image.width||source.height!==image.height)))throw Error('Invalid studio edit');
    const w=image.width,h=image.height,d=image.data;let lut=null;
    if(kind==='contrast'||kind==='levels'){const bins=[new Uint32Array(256),new Uint32Array(256),new Uint32Array(256)],total=[0,0,0];for(let n=0;n<w*h;n++){const i=n*4;if(!d[i+3]||(mask&&!mask[n]))continue;for(let j=0;j<(kind==='contrast'?1:3);j++){const value=kind==='contrast'?Math.round(.2126*d[i]+.7152*d[i+1]+.0722*d[i+2]):d[i+j];bins[j][value]++;total[j]++;}}lut=[];for(let c=0;c<(kind==='contrast'?1:3);c++){const count=total[c],limit=Math.floor(count*o.clip/100);let lo=0,hi=255,sum=0;for(;lo<255;lo++){sum+=bins[c][lo];if(sum>limit)break;}sum=0;for(;hi>0;hi--){sum+=bins[c][hi];if(sum>limit)break;}lut[c]=count&&hi>lo?{lo,hi}:null;}}
    const bayer=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let n=0;n<w*h;n++){const i=n*4,a=d[i+3];if(!a||(mask&&!mask[n]))continue;let r=d[i],g=d[i+1],b=d[i+2],alpha=a;
      if(kind==='contrast'||kind==='levels'){const m=[r,g,b];for(let c=0;c<3;c++){const item=lut[kind==='contrast'?0:c];if(item)m[c]=Math.round(Q.clamp((m[c]-item.lo)*255/(item.hi-item.lo),0,255));}r=m[0];g=m[1];b=m[2];}
      else if(kind==='palette'||kind==='dither'){const x=(n%w)+(offsetX||0),y=Math.floor(n/w)+(offsetY||0),j=kind==='dither'?((bayer[((y%4+4)%4)*4+(x%4+4)%4]+.5)/16-.5)*128*o.strength/100:0;let best=Infinity,p=o.palette[0];for(const c of o.palette){const dr=Q.clamp(r+j,0,255)-c[0],dg=Q.clamp(g+j,0,255)-c[1],db=Q.clamp(b+j,0,255)-c[2],dist=dr*dr+dg*dg+db*db;if(dist<best){best=dist;p=c;}}r=p[0];g=p[1];b=p[2];}
      else if(kind==='mask'){const m=source.data[i+3];alpha=Math.round(a*(o.invert?255-m:m)/255);}
      if(r===d[i]&&g===d[i+1]&&b===d[i+2]&&alpha===a)continue;d[i]=r;d[i+1]=g;d[i+2]=b;d[i+3]=alpha;const x=n%w,y=Math.floor(n/w);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
    }return maxX<0?null:{x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1};
  };
  // Fixed-input, piecewise-linear curves; master is applied before RGB channels.
  Q.validToneCurves = function(curves) {
    return !!curves && ['master','red','green','blue'].every(k=>Array.isArray(curves[k]) && curves[k].length===5 && curves[k].every(v=>Number.isInteger(v) && v>=0 && v<=255));
  };
  Q.toneCurveLut = function(values) {
    const xs=[0,64,128,192,255],lut=new Uint8Array(256);let segment=0;
    for(let x=0;x<=255;x++){while(segment<3 && x>xs[segment+1])segment++;const t=(x-xs[segment])/(xs[segment+1]-xs[segment]);lut[x]=Math.round(values[segment]*(1-t)+values[segment+1]*t);}
    return lut;
  };
  Q.applyToneCurves = function(image,curves,mask) {
    if(!Q.validToneCurves(curves))throw Error('Invalid tone curves');
    const master=Q.toneCurveLut(curves.master),channels=['red','green','blue'].map(k=>Q.toneCurveLut(curves[k]));
    const d=image.data,w=image.width,h=image.height;let minX=w,minY=h,maxX=-1,maxY=-1;
    for(let n=0;n<w*h;n++){const i=n*4;if(!d[i+3] || (mask && !mask[n]))continue;
      const red=channels[0][master[d[i]]],green=channels[1][master[d[i+1]]],blue=channels[2][master[d[i+2]]];
      if(red===d[i] && green===d[i+1] && blue===d[i+2])continue;
      d[i]=red;d[i+1]=green;d[i+2]=blue;const x=n%w,y=Math.floor(n/w);minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);
    }
    return maxX<0 ? null : {x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1};
  };
  // Offline representative sample: previews use the same pixel effect engine,
  // but deliberately do not claim to be a live preview of the artwork.
  Q.effectPreviewCanvas = function (type) {
    const cv=Q.canvas(64,48), c=cv.getContext('2d');
    const g=c.createLinearGradient(0,0,64,48); g.addColorStop(0,'#45b9c7'); g.addColorStop(0.5,'#eac48c'); g.addColorStop(1,'#b43f72'); c.fillStyle=g; c.fillRect(0,0,64,48);
    c.fillStyle='#fbe5b6'; c.beginPath(); c.arc(45,13,8,0,Math.PI*2); c.fill();
    c.fillStyle='#28395d'; c.beginPath(); c.moveTo(0,41); c.lineTo(21,19); c.lineTo(38,40); c.lineTo(50,28); c.lineTo(64,42); c.lineTo(64,48); c.lineTo(0,48); c.closePath(); c.fill();
    c.fillStyle='#f58542'; c.fillRect(4,36,11,5);
    const image=c.getImageData(0,0,64,48); Q.applyPixelEffect(image,type,0.75); c.putImageData(image,0,0); return cv;
  };
})();
