# ProDesign · Qalam

Developed by **Qmer**. An offline painting and frame-animation studio for Android, modelled on Procreate —
brushes, layers, a colour wheel, a frame timeline with onion skin, Procreate's gesture
vocabulary, and PNG/GIF export. No account, no ads, no network permission.

**Download:** [`Qalam-2.9.apk`](../artifacts/Qalam-2.9.apk) (~276 KB)

| | |
|---|---|
| Package | `com.qalam.studio` |
| Version | 2.9 (versionCode 20) |
| Requires | Android 8.0+ (minSdk 26), built for targetSdk 33 |
| Permissions | `VIBRATE` only — no internet, no storage, no location |
| Signing | APK Signature Scheme v1 + v2, self-signed with a public test key |
| SHA-256 | `0a5c7b2d72d149cdde48d1fd9ed257224b35e535fda1aac11aa2d8fd707d0354` |

## Install

1. Download `Qalam-2.9.apk` to the phone (or copy it over USB).
2. Open it from the file manager. Android will ask you to allow installs from that
   app the first time ("Install unknown apps") — allow it, then install.
3. Open **Qalam**.

Because the APK is self-signed, Android shows "installed from an unknown source"
once. That is expected for any app that doesn't come through the Play Store.

## What's inside

**Canvas** — 2048², portrait, landscape, 1920×1080, 1280² animation and 1080×1920
story presets and custom sizes from 64 to 4096 pixels per side; full-screen canvas with two-finger pan, pinch zoom and twist rotate.

**Selection & transform** — temporary rectangle or freehand lasso mask for brushes, erasers, fill
and effects; fill, clear, flips, 180° rotation, numeric move and scale, and copy to
new layer on the current frame. Pixel edits are undoable; selection outlines are not.
Transforms currently require a rectangle; there is no feathering, live transform preview or free rotation.

**Brushes** — 20 presets, including: Studio pen, Inking pen, Monoline, Technical pencil,
6B pencil, Marker, Airbrush, Charcoal, Watercolour, Hard eraser, Soft eraser. Stylus
pressure drives width and opacity; speed drives taper; translucency accumulates so a
stroke never darkens where it crosses itself.

**Layers** — add, duplicate, reorder, merge down, clear, delete, rename; per-layer
opacity and 16 blend modes (Normal, Multiply, Screen, Overlay, Darken, Lighten, Color
dodge/burn, Hard/Soft light, Difference, Exclusion, Hue, Saturation, Color, Luminosity);
live thumbnails, visibility toggles, per-layer edit locking, alpha lock and non-destructive clipping masks. Clipped layers use Normal blend and share the nearest unclipped base. Merge is blocked until clipping is disabled. Import PNG, JPEG, WebP or first-frame GIF as a new layer in the current frame (file and decoded-size limits apply). The Android picker still needs device testing.

**Colour** — HSB wheel with value/saturation square, HEX entry, 24 swatches and the
12 most recent colours.

**Animation** — frames live on the layer stack; add/duplicate/delete frames, scrub the
timeline, play at 1–30 fps with frame holds, and configurable onion skins.

**Gestures**

| Gesture | Action |
|---|---|
| One finger / stylus | Paint |
| Two fingers drag | Pan |
| Two fingers pinch / twist | Zoom / rotate |
| Three-finger tap | Undo |
| Four-finger tap | Redo |
| Long-press the canvas | Eyedropper |
| Hold still at the end of a stroke | QuickShape (snap to line or ellipse) |
| Pen down, then a finger | Finger is ignored — palm rejection |

**Animation workflow** — choose a playback range for preview, GIF and MP4; batch
label, hold, reverse, duplicate, skip or include a frame range with undo. Onion skins
have independent directional counts, colour, layer and stacking options. Skipped frames
are omitted from playback and GIF/MP4, but retained in PNG sequences and sprite sheets.
Labels are not nested groups. A saved motion guide can generate translated raster cels along its path with easing; the guide overlay itself does not appear in exports. Two-pose transform generation also interpolates movement, scale and rotation around a chosen pivot with easing. Both tools replace cels on the current layer within a chosen range after confirmation and can be undone; neither is a live keyframe track. A single imported audio track (2 MiB) supports forward preview and optional AAC-in-MP4 export on compatible WebViews. Audio export is capped at 120 seconds, does not support ping-pong and has not been tested on a physical device; verify saved playback. PNG/GIF remain silent. Cycle timing is displayed on the timeline. Copy a cel
across frames or delete a frame range with confirmation and undo; cel copying is
limited to 64 MiB of new pixel data per operation.
PNG sprite sheets include every frame once, without timing metadata.

**Saving & export** — everything autosaves on the device (≈2.5 s after a change, and
when the app goes to the background). Background colour is configurable; PNG and PNG
sequence exports can omit it and preserve transparency. GIF animation export (50/100/150 %
scale, loop count) are written to `Pictures/Qalam`; MP4 export is available only on WebViews that support it. Undo history holds 36 steps.

## Documentation

- [`docs/qalam.md`](qalam.md) — the full guide: install, panel tour, gestures,
  export, architecture, known limits and roadmap.
- [`docs/procreate-analysis.md`](procreate-analysis.md) — the Procreate study the
  app was built from: canvas model, Brush Studio, layers, colour, selections, guides,
  gestures, Animation Assist, export, stylus handling — mapped to Android, with a
  shipped / approximated / not-yet matrix for this app.

## About this repository

This repository contains the app source, build tools, built APK and documentation. `docs/qalam.md` §6
describes the project layout (a WebView app in plain HTML/CSS/JS packaged without
Gradle or the Android SDK, built with `aapt2` + `apktool` + a v1/v2 signer) for anyone
who wants to reproduce or extend it.

Qalam is an independent app inspired by Procreate's interaction model. Procreate is a
trademark of Savage Interactive; there is no affiliation.
