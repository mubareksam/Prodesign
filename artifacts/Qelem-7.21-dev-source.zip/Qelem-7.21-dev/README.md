# Qelem 7.21-dev

A development build, **not an official public release**. The repository root remains the public Qelem 1.4 source.

## New features in 7.21

**Procedural pattern library** — Under **Actions → Create & edit → Pattern library** (also in Add to layers), create nine original patterns: square grid, dots, checkerboard, horizontal or vertical stripes, diagonal stripes, crosshatch, isometric grid and brickwork. Choose spacing, line weight/dot size, colour, optional background and opacity. The pattern is a raster layer above the artwork; it ignores the selection. Choose the current frame or all frames, with independent cels. Checkerboard blocks use spacing, not line weight. Previews are approximate. Limit 4 MP canvas and estimated 64 MiB new buffers (template plus copies), plus existing artwork, history and device overhead. Large all-frame jobs may pause or fail.

**Palette chart** — Open **Actions → Create & edit → Palette chart**, **Add to layers → Palette chart**, or the button in Saved palette. Turn the selected device-local saved palette into a white-background chart with 1–6 columns and optional HEX labels. Export a flat PNG or add a fitted raster chart layer on the current frame. The dialog snapshots the palette at opening; reopen after changing colours. Fitting to a small canvas can make labels unreadable. PNG charts are not importable palette files. Native PNG saving uses the existing image path and requires device verification. Palette chart layer creation is limited to 4 MP and estimated 64 MiB at 16 bytes per canvas pixel, plus existing artwork and overhead.

**Split exposure into frames** — Open **Actions → Animation → Split exposure into frames**, or Frames tools in the timeline. Convert the current held frame into independent one-tick frames, preserving total ticks, layer pixels, frame label and skip status. All cels are copied independently, and one undo restores the original. Pinned frames are refused. Clear playback range and all camera/layer motion keys (including disabled keys) first, because frame-indexed settings cannot be remapped safely. Limit 60 total frames and estimated 64 MiB new cel buffers, plus artwork, undo and device overhead. Large splits can pause or fail. The total number of ticks stays the same; this is not interpolation or automatic in-betweening.

The three tools do not replace source artwork, but pattern and chart layers are raster rather than live editable objects. All layer creation and exposure splitting are undoable. Physical Android touch, performance, memory behaviour and export still need testing.

## New drawing and pattern tools in 7.20

Open these from **Actions → Create & edit**, or **Layers → Add to layers**:

- **Shape maker:** Make a rectangle, ellipse, polygon (3–12 vertices), or star (3–12 points and adjustable inner radius). Set centre, size, rotation, fill, stroke, colour and opacity. It creates a raster shape, not a re-editable vector; its preview is approximate. The current selection is ignored. Shapes are clipped at the canvas edge; differing width and height stretch polygons and stars.
- **Repeat pattern:** Scale the active cel to 10–100% and tile it across the canvas; adjust offsets and choose nearest-neighbour or smooth resampling. The entire cel is the source tile, not a selected area. Scaling rounds to whole pixel tile dimensions; seams and transparent edges can remain visible.
- **Wraparound offset:** Move the active cel with pixels wrapping across the canvas boundaries. Half-canvas offset helps bring a tile's edges to the centre for inspection. This does **not** automatically make the artwork seamless; paint the seams yourself after creating the offset layer.

Each tool creates an editable raster layer **above all existing layers**, on the current frame only, and is undoable. Source artwork is unchanged; other frames on the new layer are blank. Both tile tools use raw active-cel pixels and ignore selection, source opacity, blend and clipping; the source must be visible and have a cel. The shape tool does not need a source cel. Canvas-size limit 4 MP and estimated 64 MiB new buffers at 32 bytes per canvas pixel, so the memory limit can be reached below 4 MP. Existing artwork, history, encoding and device overhead need extra memory. Previews are downscaled and can differ at pixel boundaries. Jobs may pause or fail on limited devices. Android touch and memory behaviour require physical-device testing.

## New tools in 7.19

**Shadow and glow layers:** Open **Actions → Create & edit → Shadow layer** or **Glow layer**. Choose a colour, opacity and box-blur radius (0–32 px); shadow also offers X/Y offset (−128 to +128 px). Each uses the active cel's raw alpha and creates an independent raster layer **above all layers**, on the current frame only; move it below the artwork if desired. The source is unchanged and creation is undoable. The effect ignores the selection and source layer opacity, blend and clipping. Offset is applied before blur; pixels are clipped at canvas edges. It is a simple box blur, not a realistic light simulation. Partly transparent or fully covering glows may overlap artwork when above it. A hidden or empty source is refused; locked sources can be read because they are not edited. A no-pixel result adds nothing.

**Export layer or selection PNG:** Open **Actions → Export → Export layer or selection PNG**. Export the full active layer, the selected area of the active layer, or the selected area of the visible-layer composite as a transparent PNG. Raw layer modes ignore that layer's visibility, opacity, blend and clipping. Selection exports crop to its bounds and make pixels outside a complex hard selection transparent. The visible composite honours static layer visibility, opacity, blending and clipping, but excludes the canvas background, camera/layer animation motion and pinned frames. The exported image is a flat PNG, not editable layers. Android uses the existing image-save path (`Pictures/Qalam`); verify the output on a device.

Both tools operate on the current frame, with approximate previews for the new effect layers. They limit the canvas to 4 MP and an estimated 64 MiB at 32 bytes per canvas pixel (so the memory cap can be reached below 4 MP), plus existing artwork, undo history, encoding and other device overhead. Large jobs may pause or fail on limited devices. Export does not edit the artwork. Android touch, memory use and native file saving require physical-device testing.

## New tools in 7.18

**Levels, Vibrance, Temperature & Tint:** Open **Actions → Add → Effects** and choose the tool. Levels remaps RGB black/white points and gamma; Vibrance boosts muted colours more than saturated colours or reduces saturation; Temperature & Tint shifts red against blue and green against magenta. Each has reset and an approximate active-cel before/after preview. These are independent, original approximations, not Procreate's exact algorithms; Vibrance is not skin-tone-aware and Temperature is not calibrated camera white balance.

All three edit the active raster cel and current hard selection, preserve alpha, respect alpha lock and are undoable. They are destructive and their settings cannot be re-edited as an adjustment layer. Hidden, locked or empty layers are refused. If the document, frame, selection or history changes, reopen the dialog. Limit 4 MP affected bounds and estimated 64 MiB temporary buffers, plus existing artwork, history and device overhead. Processing can pause or fail on limited devices.

**Outline layer:** Open **Actions → Add → Outline layer**. Choose width (1–32 pixels), colour and opacity. Qelem uses the active cel's raw alpha to create a square-distance outer outline on a **new layer above all existing layers**, only on the current frame. The source is unchanged; undo removes the new layer. Other frames remain blank on the new layer, and it saves and exports as normal raster art. It ignores selection, source layer opacity, blend and clipping; partly transparent edges can overlap the source, and it clips at the canvas edge. It is square-cornered rather than a vector stroke, and its preview is approximate. Hidden or empty source layers are refused; locked layers can be read because the source is not edited. Limit 4 MP and estimated 64 MiB new buffers at 32 bytes per canvas pixel (so the memory cap can be reached below 4 MP), plus existing artwork, history and device overhead. Empty/no-fit outlines create no layer. Large images may pause or fail.

## Colour Balance

Open **Actions → Add → Effects → Colour Balance** (or the Effects button). Independently adjust the cyan–red, magenta–green and yellow–blue axes for shadows, midtones and highlights. Each tonal range retains its own settings; reset one range or all, and toggle **Show original** for comparison.

The adjustment operates on the **active raster cel** and current hard selection, preserves alpha and respects alpha lock, and can be undone in one step. The preview is downsampled and shows only that cel, not composite layers. Settings are not retained for later editing: this is a **destructive pixel adjustment**, not a non-destructive adjustment layer. Tonal weights overlap according to original pixel luminance; the sliders add or subtract from RGB channels and can change brightness. This is an independent approximation, not a reproduction of Procreate's colour engine.

Show and unlock the layer first. Changes in artwork, frame, selection or history while the dialog is open require reopening it. Limit: 4 MP affected bounds and an estimated 64 MiB of temporary buffers; existing pixels, undo history and device overhead require additional memory. Processing may pause or fail on a constrained device.

## Brush library and paper textures

Qelem now has **71 built-in original presets**, including 43 new pencil, ink, calligraphy, paint, airbrush and texture variants. Use the Brush tray's search and category filters. Brush Studio adds tip roundness and fixed tip angle; duplicate a preset to save a custom profile. Existing custom profiles without tip settings load as round. Old preset IDs remain unchanged. The underlying brushes share Qelem's three simple stamping engines: preset names are descriptive, not reproductions of Procreate brushes. This is **not complete Procreate brush parity**, does not import Procreate brush files, and does not use Procreate or Canva proprietary assets. Fixed tip angle does not track stylus tilt or stroke direction.

Open **Actions → Add → Paper & canvas textures** for eight original procedural patterns. Choose colour, strength, scale and current frame or all frames. This creates a transparent raster texture layer at the top, initially using Multiply. It affects the full canvas regardless of the selection; all-frames mode makes separate cels. It is undoable, can be edited/hidden/changed like any layer, is saved in the project and appears in exports. It is an overlay, **not** realistic interaction between brush paint and canvas; colours and transparency may alter results, including over transparent artwork. The preview shows light paper, not the actual artwork. Limits: 8 megapixels and estimated 64 MiB for the new template and copied cels, plus existing artwork, history and device overhead. Large jobs may pause or fail on limited devices. No Canva-specific designs or assets are included.

## Animation colour effects

Open **Actions → Animation → Animation colour effects**, or open the timeline's Frames tools and choose **Animation colour effects**. Choose an inclusive frame range, one of ten colour effects, and start/end strengths. Four easing presets shape the strength ramp across frame numbers. You can include or exclude skipped frames and inspect an approximate before/after preview on any frame.

The effect changes the raw cels on the active layer, **not an editable adjustment layer**. Existing nonempty cels in the range are processed; blank cels remain blank, other layers and frame timing are untouched. The current hard selection applies to all processed cels. The supported colour effects preserve alpha and work with alpha lock; a locked or hidden layer is refused. The preview is downsampled and shows only the raw cel, without layer compositing, clipping or animation motion. The effect ramp is based on frame numbers, not frame holds. In a single-frame range the start strength is used.

Confirm before applying. Cels are prepared before committing so a failed allocation or changed target cancels without partial edits. One undo restores every changed cel. No-op cels do not create a history entry. A 4 MP affected-area limit and estimated 64 MiB **new-buffer** limit apply; original cels, undo history, canvas and device overhead need extra memory, so processing may pause or fail on constrained devices.

## Storyboard PNG export

Open **Actions → Export → Export storyboard**. Create a labelled visual contact sheet for an inclusive source-frame range, choosing the grid columns, tile size and whether to include skipped frames. The sheet prints frame numbers, hold ticks, approximate seconds and frame labels; a live low-resolution preview is provided. It is a static PNG for review, not an animation or a sprite atlas. It shows source frames in timeline order with the canvas background, ignoring playback range, layer/camera motion and pinned overlays. Static background/foreground-role frames are shown individually if in range. Limit 4096 pixels per side and 8 MP output; large or clipping-heavy documents may require significant extra memory and can pause or fail. PNG export uses the existing image path (`Pictures/Qalam` on Android 10+); verify the file on a device.

## Animation import studio

- In the gallery choose **Import GIF** to turn a GIF into editable animation cels. Frames are fully composited snapshots on one raster layer; GIFs do not contain recoverable source layers. GIF transparency, partial rectangles, local/global palettes, interlacing and disposal methods 0–3 are decoded. A missing loop extension becomes one-shot playback; a loop extension enables continuous looping. Finite repeat counts become continuous loops. Plain-text graphic blocks and reserved disposal methods are refused.
- Choose the project FPS (1–30). Each GIF delay rounds to the nearest tick, minimum one tick; a GIF zero delay is treated as 0.1 seconds. A delay longer than 60 ticks is rejected; choose a lower FPS to import it. Very short delays therefore may play more slowly. The canvas background defaults to white; transparent cel pixels remain transparent. GIF pixel-aspect metadata and GIF comments are not preserved.
- **Import sprite sheet** slices a PNG, JPEG or WebP grid left to right, top to bottom. Choose rows, columns, how many frames to use, FPS and ticks per frame. Tile dimensions must divide the sheet exactly; no margins, spacing or atlas metadata. Alpha is preserved. Animated image formats used as a sheet contribute only the decoded first image, not their animation.
- Both create a **new editable artwork**, with a gallery thumbnail, without overwriting existing art. Every frame can be edited normally; import itself is not an undo step because it creates a separate project. File type is checked from bytes for sprite sheets, even if a provider supplies a generic MIME type. Storage failures and ID collisions do not replace existing artwork.

Limits for each import: **10 MiB input**, **2 megapixel canvas/sheet**, max **4096 pixels per side**, **60 frames** and **64 MiB of decoded frame pixels**. Browser decoding, snapshots, the source image, PNG serialization, thumbnails and application overhead use additional memory; devices can pause or fail below these limits. GIFs with unusually large per-frame compressed data or excessive LZW codes are rejected to bound processing. File reads and initial browser image decode are not streamed and sprite-sheet size is checked after decoding. Import only trusted files. Android file pickers, provider compatibility, memory behavior and actual playback require physical-device testing.

## Editable project backup and restore

- **Export:** Open artwork → **Actions → Export project backup → Export project**. This uses the live document, including edits not yet autosaved. Android 10+ writes JSON to `Downloads/Qelem`; browser mode starts a download. Finish strokes and playback first.
- **Import:** In the gallery, tap **Import project → Choose project file**. A successful import creates a new artwork; it never replaces the original. It starts unfiled. The optional gallery preview is a static thumbnail of the active frame, without playback transforms; opening and saving refreshes it.
- **Checks:** File format/version, CRC32 checksum, project structure, metadata, cel PNG dimensions and actual image decoding are checked before one atomic insert. Corruption, duplicate cel coordinates, collisions and storage failures are rejected. CRC32 is an accidental-corruption check, **not authentication**: do not trust backups from unknown sources. Import only files you trust.

The JSON includes editable raster layers and animation cels, frame timing, background, layer properties, guides, layer/camera motion settings and the single embedded audio track. It excludes undo history, temporary selections, gallery collections and pins, palettes, custom brushes, reference images and global preferences. This is a Qelem-specific backup, **not PSD or Procreate interchange**. Audio playback and format support still depend on the device. Test restoration on a separate device before relying on a backup.

Limits: file at most **24 MiB**, at most **512 nonempty cels**, estimated decoded cel memory **128 MiB** (`width × height × 4 × nonempty cels`), and canvas sides at most 4096 px. Existing artwork, PNG compression, base64 strings, thumbnail compositing and device overhead require additional memory, so a smaller project may still pause or fail; the UI is not streamed. File picker contents are read into memory. Native backup export requires Android 10 / API 29 or later; Android 8–9 can still use the app but cannot export this format. Android picker/provider compatibility, written downloads, memory pressure, audio and touch have **not been tested on a physical device**. Desktop tests are not a substitute.

## Provenance and testing

7.21 builds on local 7.20 (APK SHA-256 `79f9cbb9fcdd4b1204d711e79f02d0ee1f7e2799fb980175426e17974dddd8b5`). The original 7.1 development source archive was not preserved. 7.2 was reconstructed from the published 7.1 APK (SHA-256 `aec84370a66da9c9a1e6e25d2912c5c00047121557c96c8e8759d98eb8e02b3e`) using extracted web assets and apktool-decoded native code and resources. Android code is recovered smali, not original Java source. The inherited toolchain and tests came from 6.3 and were updated; they are not the unavailable full original 7.1 test suite.

Package and internal storage keys are unchanged; version code 82 is newer than 7.20-dev's 81. APKs use the same publicly available test signing key as earlier builds, **not a secure production key**. Back up artwork before installing or downgrading. Older builds may drop project metadata, Android normally blocks downgrades, and uninstalling can erase artwork. Previous image and movie export paths `Pictures/Qalam` and `Movies/Qalam` remain unchanged. See [feature status](FEATURE-STATUS.md) for major gaps.

## Build and test

```sh
bash tools/fetch-toolchain.sh
(cd tools/tests && npm test)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node pattern_library_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node palette_chart_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node split_exposure_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node shape_maker_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node tile_tools_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node shadow_glow_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node partial_png_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node tonal_adjustments_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node outline_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node color_balance_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node brush_expansion_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node textures_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node animation_effects_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node storyboard_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node gif_import_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node sheet_import_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node project_backup_browser.mjs)
# Earlier browser suites: soft_edit, selection_border, orientation, resize,
# curves, assist, collections, exposure and ui_layout (each *_browser.mjs).
bash tools/build.sh
```

Build output: `artifacts/Qelem-7.21-dev.apk`. The bootstrap installs Node dependencies and the Android packaging toolchain. Apktool assembles the recovered smali directly; original Java source is unavailable.
