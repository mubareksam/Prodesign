# Qelem 1.0 — historical source

This is the original 1.0 snapshot (commit `b26caa8`) rebuilt for the retrospective Qelem 1.0 release. Display branding, About credit, exported file/folder names and build output name were updated. The undo and redo gestures use three- and four-finger taps rather than the original two- and three-finger taps; the original feature set and known New canvas issue remain. The Android package and storage identifiers remain unchanged for compatibility. This historical build has not been tested on a physical device.

Build using `tools/fetch-toolchain.sh`, install the signing dependencies with `npm ci` in `tools/apksign`, then run `tools/build.sh`. The bundled signing key is public and unsuitable for trusted production releases.
