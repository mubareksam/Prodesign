/* Qalam — project persistence (IndexedDB, with a localStorage fallback for
 * WebView builds where IndexedDB is restricted).
 */
(function () {
  'use strict';
  const Q = window.Q;
  const DB_NAME = 'qalam-studio';
  const DB_VER = 1;
  const STORE = 'projects';
  const LS_KEY = 'qalam-projects';
  const LS_META = 'qalam-meta';

  let dbPromise = null;
  let useLocal = false;
  let mode = 'idb';

  function openDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve, reject) {
      let req;
      try { req = indexedDB.open(DB_NAME, DB_VER); } catch (e) { reject(e); return; }
      req.onupgradeneeded = function (ev) {
        const db = ev.target.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: 'id' });
        }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error('indexedDB error')); };
      req.onblocked = function () { reject(new Error('indexedDB blocked')); };
    });
    return dbPromise;
  }

  function tx(mode2, fn) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        const t = db.transaction(STORE, mode2);
        const store = t.objectStore(STORE);
        let result;
        try { result = fn(store); } catch (e) { reject(e); return; }
        t.oncomplete = function () { resolve(result && result.__req ? result.__req.result : result); };
        t.onerror = function () { reject(t.error); };
        t.onabort = function () { reject(t.error || new Error('aborted')); };
      });
    });
  }

  function lsAll() {
    try { return JSON.parse(localStorage.getItem(LS_KEY) || '{}'); } catch (e) { return {}; }
  }
  function lsPut(rec) {
    const all = lsAll();
    all[rec.id] = rec;
    localStorage.setItem(LS_KEY, JSON.stringify(all));
  }
  function lsDel(id) {
    const all = lsAll();
    delete all[id];
    localStorage.setItem(LS_KEY, JSON.stringify(all));
  }

  const Store = {
    mode: function () { return mode; },

    init: function () {
      return openDb().then(function () {
        mode = 'idb';
        return mode;
      }).catch(function () {
        useLocal = true;
        mode = 'local';
        return mode;
      });
    },

    list: function () {
      if (useLocal) {
        const all = lsAll();
        return Promise.resolve(Object.keys(all).map(function (k) {
          const r = all[k];
          return { id: r.id, name: r.name, updated: r.updated, thumb: r.thumb, w: r.w, h: r.h, frames: r.frameCount };
        }).sort(function (a, b) { return b.updated - a.updated; }));
      }
      return tx('readonly', function (store) {
        const out = [];
        const req = store.openCursor();
        const holder = { __req: { result: out } };
        req.onsuccess = function (ev) {
          const cur = ev.target.result;
          if (cur) {
            const r = cur.value;
            out.push({ id: r.id, name: r.name, updated: r.updated, thumb: r.thumb, w: r.w, h: r.h, frames: r.frameCount });
            cur.continue();
          }
        };
        return holder;
      }).then(function (out) {
        return out.sort(function (a, b) { return b.updated - a.updated; });
      });
    },

    save: function (doc, thumbUrl) {
      const rec = serialize(doc, thumbUrl);
      if (useLocal) {
        try {
          lsPut(rec);
          return Promise.resolve(rec);
        } catch (e) {
          Q.toast('Storage full — export your work');
          return Promise.reject(e);
        }
      }
      return tx('readwrite', function (store) { store.put(rec); return rec; });
    },

    load: function (id) {
      const get = useLocal
        ? Promise.resolve(lsAll()[id])
        : tx('readonly', function (store) {
          const req = store.get(id);
          return { __req: req };
        });
      return get.then(function (rec) {
        if (!rec) return null;
        return deserialize(rec);
      });
    },

    // Duplicate the last saved record, including every cel and future metadata,
    // without decoding/re-rendering it. add() refuses an ID collision.
    duplicate: function(id) {
      function copy(r) { return {...r,id:Q.uid(),name:String(r.name || 'Untitled').slice(0,59)+' copy',updated:Date.now()}; }
      if(useLocal) {
        try { const all=lsAll(), original=all[id]; if(!original) return Promise.reject(new Error('Artwork not found')); const rec=copy(original); if(Object.prototype.hasOwnProperty.call(all,rec.id)) return Promise.reject(new Error('Artwork ID collision')); all[rec.id]=rec; localStorage.setItem(LS_KEY,JSON.stringify(all)); return Promise.resolve(rec.id); }
        catch(e) { return Promise.reject(e); }
      }
      return openDb().then(db=>new Promise((resolve,reject)=>{
        const t=db.transaction(STORE,'readwrite'), store=t.objectStore(STORE), get=store.get(id); let newId=null;
        get.onsuccess=function(){ if(!get.result) { t.abort(); return; } const rec=copy(get.result); newId=rec.id; store.add(rec); };
        t.oncomplete=()=>resolve(newId); t.onabort=()=>reject(t.error || new Error('Artwork not found or copy failed')); t.onerror=()=>{};
      }));
    },

    remove: function (id) {
      if (useLocal) { lsDel(id); return Promise.resolve(); }
      return tx('readwrite', function (store) { store.delete(id); return true; });
    },

    meta: function (key, value) {
      if (arguments.length === 1) {
        try { return JSON.parse(localStorage.getItem(LS_META) || '{}')[key]; } catch (e) { return undefined; }
      }
      try {
        const all = JSON.parse(localStorage.getItem(LS_META) || '{}');
        all[key] = value;
        localStorage.setItem(LS_META, JSON.stringify(all));
      } catch (e) { /* ignore */ }
      return value;
    }
  };

  function serialize(doc, thumbUrl) {
    const cels = [];
    for (let fi = 0; fi < doc.frames.length; fi++) {
      const f = doc.frames[fi];
      for (let li = 0; li < f.cels.length; li++) {
        const cel = f.cels[li];
        if (!cel) continue;
        cels.push([fi, li, cel.toDataURL('image/png')]);
      }
    }
    return {
      id: doc.id,
      name: doc.name,
      w: doc.width,
      h: doc.height,
      fps: doc.fps,
      bg: doc.bg,
      onion: doc.onion,
      onionAlpha: doc.onionAlpha,
      onionFrames: doc.onionFrames,
      onionPrevFrames: doc.onionPrevFrames, onionNextFrames: doc.onionNextFrames,
      onionLoop: doc.onionLoop, onionIncludeSkipped: doc.onionIncludeSkipped, onionLayerOnly: doc.onionLayerOnly,
      onionOriginalColor: doc.onionOriginalColor, onionAbove: doc.onionAbove,
      onionPrevColor: doc.onionPrevColor,
      onionNextColor: doc.onionNextColor,
      frameDurations: doc.frames.map(function (f) { return f.duration || 1; }),
      frameGroups: doc.frames.map(function (f) { return f.group || ''; }),
      frameSkipped: doc.frames.map(function (f) { return !!f.skipped; }),
      frameRoles: doc.frames.map(function (f) { return f.role || ''; }),
      playMode: doc.playMode,
      playRange: doc.playRange ? {...doc.playRange} : null,
      guide: doc.guide,
      motionGuide:doc.motionGuide, motionGuideVisible:doc.motionGuideVisible,
      audioTrack:doc.audioTrack, cameraEnabled:doc.cameraEnabled, cameraKeys:doc.cameraKeys.map(k=>({...k})),
      solo:doc.solo ? {target:doc.solo.target,visibility:doc.solo.visibility.map(v=>({...v}))} : null,
      frameCount: doc.frames.length,
      layers: doc.layers.map(function (l) {
        return { id: l.id, name: l.name, visible: l.visible, opacity: l.opacity, blend: l.blend, tag:Q.layerTag(l.tag), assisted: !!l.assisted, locked: !!l.locked, alphaLocked: !!l.alphaLocked, clipped: !!l.clipped, reference: !!l.reference, motionEnabled:!!l.motionEnabled, motionKeys:(l.motionKeys || []).map(k=>({...k})) };
      }),
      activeFrame: doc.activeFrame,
      activeLayer: doc.activeLayer,
      cels: cels,
      updated: Date.now(),
      thumb: thumbUrl || null
    };
  }

  function loadImage(dataUrl) {
    return new Promise(function (resolve, reject) {
      let done = false;
      const img = new Image();
      const timer = setTimeout(function () {
        if (done) return;
        done = true;
        reject(new Error('cel image timed out'));
      }, 4000);
      img.onload = function () {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(img);
      };
      img.onerror = function () {
        if (done) return;
        done = true;
        clearTimeout(timer);
        reject(new Error('bad cel image'));
      };
      img.src = dataUrl;
    });
  }

  function deserialize(rec) {
    const doc = new Q.Doc({ id: rec.id, name: rec.name, width: rec.w, height: rec.h, fps: rec.fps, bg: rec.bg, onion: rec.onion, onionAlpha: rec.onionAlpha, onionFrames: rec.onionFrames, onionPrevFrames: rec.onionPrevFrames, onionNextFrames: rec.onionNextFrames, onionLoop: rec.onionLoop, onionIncludeSkipped: rec.onionIncludeSkipped, onionLayerOnly: rec.onionLayerOnly, onionOriginalColor: rec.onionOriginalColor, onionAbove: rec.onionAbove, onionPrevColor: rec.onionPrevColor, onionNextColor: rec.onionNextColor, playMode: rec.playMode, playRange: rec.playRange, guide: rec.guide, motionGuide:rec.motionGuide, motionGuideVisible:rec.motionGuideVisible, cameraEnabled:rec.cameraEnabled, cameraKeys:rec.cameraKeys, audioTrack:rec.audioTrack });
    doc.layers = (rec.layers || []).map(function (l) {
      return { id: l.id || Q.uid(), name: l.name || 'Layer', visible: l.visible !== false, opacity: l.opacity == null ? 1 : l.opacity, blend: l.blend || 'source-over', tag:Q.layerTag(l.tag), assisted: !!l.assisted, locked: !!l.locked, alphaLocked: !!l.alphaLocked, clipped: !!l.clipped, reference: !!l.reference, motionEnabled:!!l.motionEnabled, motionKeys:Q.sanitizeLayerMotion(l,doc.width,doc.height) };
    });
    if (!doc.layers.length) doc.layers = [Q.makeLayer('Layer 1')];
    let hasReference=false;doc.layers.forEach(function(l){if(l.reference){if(hasReference)l.reference=false;else hasReference=true;}});
    if (rec.solo && typeof rec.solo.target==='string' && Array.isArray(rec.solo.visibility)) {
      const ids=new Set(doc.layers.map(l=>l.id)), seen=new Set(), visibility=[];
      rec.solo.visibility.slice(0,Math.max(1024,doc.layers.length)).forEach(v=>{ if(v && typeof v.id==='string' && ids.has(v.id) && !seen.has(v.id) && typeof v.visible==='boolean') { visibility.push({id:v.id,visible:v.visible}); seen.add(v.id); } });
      if(visibility.length) doc.solo={target:rec.solo.target,visibility:visibility};
    }

    const frames = [], rolesSeen=new Set();
    for (let i = 0; i < (rec.frameCount || 1); i++) {
      const cels = [];
      for (let j = 0; j < doc.layers.length; j++) cels.push(null);
      const candidate=(rec.frameRoles || [])[i], role=(candidate==='background' || candidate==='foreground') && !rolesSeen.has(candidate) ? candidate : ''; if(role) rolesSeen.add(role);
      frames.push({ role:role, cels: cels, duration: Q.clamp(Math.round((rec.frameDurations || [])[i]) || 1, 1, 60), group: String((rec.frameGroups || [])[i] || '').slice(0,32), skipped: !!(rec.frameSkipped || [])[i] });
    }
    doc.frames = frames;
    doc.normalizePlayRange(); doc.normalizeCameraKeys();
    doc.activeFrame = Q.clamp(rec.activeFrame || 0, 0, frames.length - 1);
    doc.activeLayer = Q.clamp(rec.activeLayer || 0, 0, doc.layers.length - 1);
    doc.history = new Q.History(doc);

    const jobs = (rec.cels || []).map(function (entry) {
      return loadImage(entry[2]).then(function (img) {
        const fi = entry[0], li = entry[1];
        if (!doc.frames[fi]) return;
        const cv = Q.canvas(doc.width, doc.height);
        cv.getContext('2d').drawImage(img, 0, 0, doc.width, doc.height);
        doc.frames[fi].cels[li] = cv;
      }).catch(function () { /* skip a broken cel */ });
    });

    return Promise.all(jobs).then(function () { return doc; });
  }

  // Versioned, self-contained JSON backup. CRC32 is accidental-corruption
  // detection only, not authentication. Never overwrite an existing project.
  const BACKUP_LIMIT=24*1024*1024, BACKUP_CEL_MEMORY=128*1024*1024;
  Q.PROJECT_BACKUP_MAX_BYTES=BACKUP_LIMIT;
  function crcString(text) {
    let crc=0xffffffff;
    for(let i=0;i<text.length;i++){const u=text.charCodeAt(i);for(const byte of [u&255,u>>>8]){crc^=byte;for(let n=0;n<8;n++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}}
    return ((crc^0xffffffff)>>>0).toString(16).padStart(8,'0');
  }
  function pngHeader(url,w,h) {
    if(typeof url!=='string' || !url.startsWith('data:image/png;base64,') || url.length>BACKUP_LIMIT)return false;
    const data=url.slice(22);if(data.length%4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(data))return false;
    try{const b=atob(data.slice(0,32));if(b.length<24 || ![137,80,78,71,13,10,26,10].every((v,i)=>b.charCodeAt(i)===v) || b.slice(12,16)!=='IHDR')return false;
      const num=i=>((b.charCodeAt(i)*16777216)+(b.charCodeAt(i+1)<<16)+(b.charCodeAt(i+2)<<8)+b.charCodeAt(i+3));return num(16)===w && num(20)===h;
    }catch(e){return false;}
  }
  function validateBackupRecord(r) {
    const fail=message=>({error:message});
    if(!r || typeof r!=='object' || !Number.isInteger(r.w)||!Number.isInteger(r.h)||r.w<1||r.h<1||r.w>4096||r.h>4096)return fail('Invalid canvas dimensions');
    if(typeof r.name!=='string'||r.name.length>200 || !Number.isInteger(r.fps)||r.fps<1||r.fps>30 || !Q.hexToRgb(r.bg))return fail('Invalid project metadata');
    if(!Number.isInteger(r.frameCount)||r.frameCount<1||r.frameCount>60||!Array.isArray(r.layers)||r.layers.length<1||r.layers.length>128 || !Number.isInteger(r.activeFrame)||r.activeFrame<0||r.activeFrame>=r.frameCount || !Number.isInteger(r.activeLayer)||r.activeLayer<0||r.activeLayer>=r.layers.length)return fail('Invalid frame or layer count');
    const flags=['onion','onionLoop','onionIncludeSkipped','onionLayerOnly','onionOriginalColor','onionAbove','motionGuideVisible','cameraEnabled'];if(flags.some(k=>typeof r[k]!=='boolean') || !Number.isFinite(r.onionAlpha) || r.onionAlpha<0 || r.onionAlpha>1 || ![r.onionFrames,r.onionPrevFrames,r.onionNextFrames].every(n=>Number.isInteger(n)&&n>=0&&n<=4) || !Q.hexToRgb(r.onionPrevColor) || !Q.hexToRgb(r.onionNextColor))return fail('Invalid onion settings');
    if(!['loop','once','pingpong','reverse'].includes(r.playMode) || (r.playRange!==null && (!r.playRange || !Number.isInteger(r.playRange.start) || !Number.isInteger(r.playRange.end) || r.playRange.start<0 || r.playRange.end<r.playRange.start || r.playRange.end>=r.frameCount)))return fail('Invalid playback settings');
    if(!Array.isArray(r.frameDurations)||!Array.isArray(r.frameGroups)||!Array.isArray(r.frameSkipped)||!Array.isArray(r.frameRoles)||[r.frameDurations,r.frameGroups,r.frameSkipped,r.frameRoles].some(a=>a.length!==r.frameCount)||r.frameDurations.some(v=>!Number.isInteger(v)||v<1||v>60)||r.frameGroups.some(v=>typeof v!=='string'||v.length>32)||r.frameSkipped.some(v=>typeof v!=='boolean')||r.frameRoles.some(v=>!['','background','foreground'].includes(v))||['background','foreground'].some(role=>r.frameRoles.filter(v=>v===role).length>1))return fail('Invalid frame metadata');
    const ids=new Set();let refs=0;
    for(const l of r.layers){if(!l || typeof l.id!=='string'||!l.id||l.id.length>128||ids.has(l.id)||typeof l.name!=='string'||l.name.length>200||!Number.isFinite(l.opacity)||l.opacity<0||l.opacity>1||!Q.BLEND_MODES.some(v=>v[0]===l.blend)||!Q.LAYER_TAGS.includes(l.tag))return fail('Invalid layer metadata');ids.add(l.id);if(['visible','assisted','locked','alphaLocked','clipped','reference','motionEnabled'].some(k=>typeof l[k]!=='boolean'))return fail('Invalid layer flags');if(l.reference)refs++;if(!Array.isArray(l.motionKeys)||l.motionKeys.length>60||l.motionKeys.some(k=>!Q.validLayerMotionKey(k,r.w,r.h)||k.frame>=r.frameCount)||new Set(l.motionKeys.map(k=>k.frame)).size!==l.motionKeys.length)return fail('Invalid layer motion keys');}
    if(refs>1)return fail('More than one reference layer');
    if(!r.guide || typeof r.guide!=='object'||!['off','grid','isometric','perspective1','perspective2','perspective3','symmetry'].includes(r.guide.type)||!['off','vertical','horizontal','quadrant','radial'].includes(r.guide.symmetry)||!Number.isFinite(r.guide.spacing)||!Number.isFinite(r.guide.horizon)||!Number.isFinite(r.guide.spread))return fail('Invalid drawing guide');
    if(!Array.isArray(r.motionGuide)||r.motionGuide.length>512||r.motionGuide.some(p=>!p||!Number.isFinite(p.x)||!Number.isFinite(p.y)||p.x<0||p.y<0||p.x>r.w||p.y>r.h))return fail('Invalid animation guide');
    if(!Array.isArray(r.cameraKeys)||r.cameraKeys.length>60||r.cameraKeys.some(k=>!Q.validCameraKey(k,r.w,r.h)||k.frame>=r.frameCount)||new Set(r.cameraKeys.map(k=>k.frame)).size!==r.cameraKeys.length)return fail('Invalid camera keys');
    if(r.audioTrack!==null && !Q.validAudioTrack(r.audioTrack))return fail('Invalid audio track');
    if(r.solo!==null && (!r.solo || !ids.has(r.solo.target) || !Array.isArray(r.solo.visibility) || r.solo.visibility.length>r.layers.length || r.solo.visibility.some(v=>!v||!ids.has(v.id)||typeof v.visible!=='boolean') || new Set(r.solo.visibility.map(v=>v.id)).size!==r.solo.visibility.length))return fail('Invalid solo metadata');
    const scale=320/Math.max(r.w,r.h),tw=Math.max(1,Math.round(r.w*scale)),th=Math.max(1,Math.round(r.h*scale));
    if(r.thumb!==null && (typeof r.thumb!=='string' || r.thumb.length>1024*1024 || !pngHeader(r.thumb,tw,th)))return fail('Invalid gallery preview');
    if(!Array.isArray(r.cels)||r.cels.length>512 || r.cels.length*r.w*r.h*4>BACKUP_CEL_MEMORY)return fail('Project exceeds the 128 MiB decoded-cel limit');
    const coords=new Set();for(const e of r.cels){if(!Array.isArray(e)||e.length!==3||!Number.isInteger(e[0])||!Number.isInteger(e[1])||e[0]<0||e[0]>=r.frameCount||e[1]<0||e[1]>=r.layers.length||!pngHeader(e[2],r.w,r.h))return fail('Invalid cel PNG');const key=e[0]+':'+e[1];if(coords.has(key))return fail('Duplicate cel');coords.add(key);}
    return {};
  }
  // Insert only; never replace existing projects, even on an ID collision.
  Store.insertNewDocument = async function(doc,thumb) {
    const r=serialize(doc,thumb);if(!/^[a-z0-9]{1,40}$/.test(r.id))throw Error('Could not create project ID');
    if(useLocal){try{const raw=localStorage.getItem(LS_KEY),all=raw===null ? {} : JSON.parse(raw);if(!all || Array.isArray(all) || typeof all!=='object' || Object.prototype.hasOwnProperty.call(all,r.id))throw Error();all[r.id]=r;localStorage.setItem(LS_KEY,JSON.stringify(all));}catch(e){throw Error('Could not save new project; existing artwork was not changed');}return r.id;}
    await tx('readwrite',function(store){store.add(r);return true;});return r.id;
  };
  Store.makeProjectBackup = function(doc) {
    const celCount=doc.frames.reduce((n,f)=>n+f.cels.filter(Boolean).length,0);
    if(celCount>512 || celCount*doc.width*doc.height*4>BACKUP_CEL_MEMORY)throw Error('Project exceeds 512 cels or the 128 MiB decoded-cel limit');
    let thumb=null;try{thumb=doc.thumbnail(doc.activeFrame,320).toDataURL('image/png');}catch(e){/* The preview is optional; preserve the editable artwork. */}
    const r=serialize(doc,thumb),valid=validateBackupRecord(r);if(valid.error)throw Error(valid.error);
    const payload=JSON.stringify(r),bundle=JSON.stringify({format:'qelem-project',version:1,checksum:crcString(payload),project:r}),bytes=new TextEncoder().encode(bundle);
    if(bytes.length>BACKUP_LIMIT)throw Error('Project exceeds the 24 MiB backup limit');return bytes;
  };
  Store.importProjectBackup = async function(text) {
    if(typeof text!=='string'||text.length>BACKUP_LIMIT)throw Error('Project file exceeds the 24 MiB limit');
    let bundle;try{bundle=JSON.parse(text);}catch(e){throw Error('Invalid project JSON');}
    if(!bundle || bundle.format!=='qelem-project' || bundle.version!==1 || !/^[0-9a-f]{8}$/.test(bundle.checksum || '') || crcString(JSON.stringify(bundle.project))!==bundle.checksum)throw Error('Unsupported or damaged project backup');
    const r=bundle.project,valid=validateBackupRecord(r);if(valid.error)throw Error(valid.error);
    // Validate every encoded cel before storing anything; never silently drop one.
    for(const e of r.cels){let img;try{img=await loadImage(e[2]);}catch(err){throw Error('A cel PNG could not be decoded');}if((img.naturalWidth||img.width)!==r.w || (img.naturalHeight||img.height)!==r.h)throw Error('Cel dimensions do not match canvas');}
    if(r.thumb){try{await loadImage(r.thumb);}catch(err){throw Error('Gallery preview could not be decoded');}}
    const id=Q.uid();if(!/^[a-z0-9]{1,40}$/.test(id))throw Error('Could not create project ID');r.id=id;r.updated=Date.now();
    if(useLocal){let all;try{const raw=localStorage.getItem(LS_KEY);all=raw===null ? {} : JSON.parse(raw);if(!all || Array.isArray(all) || typeof all!=='object')throw Error();if(Object.prototype.hasOwnProperty.call(all,id))throw Error('Project ID collision');all[id]=r;localStorage.setItem(LS_KEY,JSON.stringify(all));}catch(e){throw Error('Could not save imported project; existing artwork was not changed');}return id;}
    await tx('readwrite',function(store){store.add(r);return true;});return id;
  };
  Q.backupCrc=crcString;

  Q.Store = Store;
})();
