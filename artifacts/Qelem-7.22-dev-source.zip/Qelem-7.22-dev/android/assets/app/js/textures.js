/* Original, deterministic procedural paper/canvas textures; no external assets. */
(function(){
  'use strict';const Q=window.Q,S=128;
  Q.PAPER_TEXTURES=[['cotton','Cotton paper'],['coldpress','Cold press'],['rough','Rough paper'],['canvas','Canvas weave'],['linen','Fine linen'],['speckle','Speckled paper'],['parchment','Mottled parchment'],['crosshatch','Crosshatch']];
  function hash(x,y,seed){let n=Math.imul((x+1)^seed,0x45d9f3b)^Math.imul(y+7,0x27d4eb2d);n^=n>>>16;n=Math.imul(n,0x7feb352d);n^=n>>>15;return (n>>>0)/4294967295;}
  function noise(x,y,grid,seed){const px=x*grid/S,py=y*grid/S,ix=Math.floor(px),iy=Math.floor(py),u=px-ix,v=py-iy,fx=u*u*(3-2*u),fy=v*v*(3-2*v),h=(a,b)=>hash((a+grid)%grid,(b+grid)%grid,seed),top=h(ix,iy)*(1-fx)+h(ix+1,iy)*fx,bot=h(ix,iy+1)*(1-fx)+h(ix+1,iy+1)*fx;return top*(1-fy)+bot*fy;}
  Q.makePaperTile=function(type,color,strength){
    if(!Q.PAPER_TEXTURES.some(t=>t[0]===type) || !Array.isArray(color) || color.length!==3 || color.some(v=>!Number.isInteger(v)||v<0||v>255) || !Number.isFinite(strength)||strength<0||strength>1)throw Error('Invalid texture settings');
    const cv=Q.canvas(S,S),ctx=cv.getContext('2d'),im=ctx.createImageData(S,S),d=im.data;
    for(let y=0;y<S;y++)for(let x=0;x<S;x++){
      const fine=hash(x,y,13),a=noise(x,y,16,27),b=noise(x,y,8,53),c=noise(x,y,32,61),vx=(1+Math.cos(2*Math.PI*x/8))/2,hy=(1+Math.cos(2*Math.PI*y/8))/2;let v=0;
      if(type==='cotton')v=.16*fine+.28*a;
      else if(type==='coldpress')v=.16*fine+.65*Math.pow(a,2);
      else if(type==='rough')v=.3*fine+.5*a+.2*b;
      else if(type==='canvas')v=.22*fine+.42*vx+.42*hy;
      else if(type==='linen')v=.12*fine+.22*c+.44*Math.pow(vx,4)+.28*Math.pow(hy,4);
      else if(type==='speckle')v=.08*a+(fine>.88 ? .88 : 0);
      else if(type==='parchment')v=.15*fine+.65*b;
      else v=.12*fine+.48*Math.pow((1+Math.cos(2*Math.PI*(x+y)/16))/2,6)+.32*Math.pow((1+Math.cos(2*Math.PI*(x-y)/16))/2,6);
      const i=(y*S+x)*4;d[i]=color[0];d[i+1]=color[1];d[i+2]=color[2];d[i+3]=Math.round(255*Q.clamp(v,0,1)*strength);
    }
    ctx.putImageData(im,0,0);return cv;
  };
  Q.fillPaperTexture=function(ctx,tile,width,height,scale){if(![.5,1,2,4].includes(scale))throw Error('Invalid texture scale');const pattern=ctx.createPattern(tile,'repeat');if(!pattern)throw Error('Texture pattern unavailable');ctx.save();ctx.scale(scale,scale);ctx.fillStyle=pattern;ctx.fillRect(0,0,width/scale,height/scale);ctx.restore();};
})();
