/* PNG contact sheet for animation frames; one tile per source frame. */
(function () {
  'use strict';
  const Q=window.Q;
  Q.spriteSheetLayout=function (doc,columns,scale) {
    const count=doc.frames.length;
    if (!Number.isInteger(columns) || columns<1 || columns>count || !Number.isFinite(scale) || scale<0.01 || scale>1) return null;
    const tileW=Math.max(1,Math.round(doc.width*scale)), tileH=Math.max(1,Math.round(doc.height*scale));
    const rows=Math.ceil(count/columns), width=tileW*columns, height=tileH*rows;
    if (width>8192 || height>8192 || width*height>16777216) return null;
    return {columns:columns,rows:rows,tileW:tileW,tileH:tileH,width:width,height:height};
  };
  Q.renderSpriteSheet=function (doc,columns,scale,transparent) {
    const l=Q.spriteSheetLayout(doc,columns,scale); if (!l) throw new Error('Invalid sprite sheet dimensions');
    const canvas=Q.canvas(l.width,l.height), ctx=canvas.getContext('2d');
    doc.frames.forEach(function (_,i) {
      const x=(i%l.columns)*l.tileW, y=Math.floor(i/l.columns)*l.tileH;
      ctx.save(); ctx.beginPath(); ctx.rect(x,y,l.tileW,l.tileH); ctx.clip();
      ctx.translate(x,y); ctx.scale(l.tileW/doc.width,l.tileH/doc.height);
      if (!transparent) { ctx.fillStyle=doc.bg; ctx.fillRect(0,0,doc.width,doc.height); }
      doc.composite(ctx,i); ctx.restore();
    });
    return canvas;
  };
  // A labelled source-frame contact sheet, separate from the unlabelled sprite atlas.
  Q.storyboardPlan=function(doc,options) {
    if(!doc || !options || !Number.isInteger(options.start) || !Number.isInteger(options.end) || options.start<0 || options.end<options.start || options.end>=doc.frames.length || !Number.isInteger(options.columns) || options.columns<1 || options.columns>6 || ![160,240,320].includes(options.tileWidth) || typeof options.includeSkipped!=='boolean')return {error:'Choose a valid range and layout'};
    const frames=[];for(let i=options.start;i<=options.end;i++)if(options.includeSkipped || !doc.frames[i].skipped)frames.push(i);
    if(!frames.length)return {error:'No frames match this range'};
    const columns=Math.min(options.columns,frames.length),rows=Math.ceil(frames.length/columns),cellW=options.tileWidth,cellH=Math.round(cellW*0.82),width=columns*cellW,height=rows*cellH;
    if(width>4096 || height>4096 || width*height>8*1024*1024)return {error:'Storyboard exceeds 4096 pixels per side or 8 MP; reduce range or tile size'};
    return {frames,columns,rows,cellW,cellH,width,height};
  };
  Q.renderStoryboard=function(doc,options,scale) {
    const plan=Q.storyboardPlan(doc,options);if(plan.error)throw Error(plan.error);if(!Number.isFinite(scale) || scale<=0 || scale>1)throw Error('Invalid storyboard scale');
    const canvas=Q.canvas(plan.width*scale,plan.height*scale),c=canvas.getContext('2d');c.scale(canvas.width/plan.width,canvas.height/plan.height);c.fillStyle='#22242a';c.fillRect(0,0,plan.width,plan.height);
    const margin=8, header=24, footer=29, innerW=plan.cellW-margin*2, innerH=plan.cellH-header-footer;
    plan.frames.forEach(function(fi,pos){const f=doc.frames[fi],x=(pos%plan.columns)*plan.cellW,y=Math.floor(pos/plan.columns)*plan.cellH;c.fillStyle='#353840';c.fillRect(x+3,y+3,plan.cellW-6,plan.cellH-6);
      c.save();c.beginPath();c.rect(x+margin,y+header,innerW,innerH);c.clip();c.fillStyle=doc.bg;c.fillRect(x+margin,y+header,innerW,innerH);
      const fit=Math.min(innerW/doc.width,innerH/doc.height),w=doc.width*fit,h=doc.height*fit;c.translate(x+margin+(innerW-w)/2,y+header+(innerH-h)/2);c.scale(fit,fit);doc.composite(c,fi);c.restore();
      c.fillStyle='#f7f7f7';c.font='bold 12px sans-serif';c.textBaseline='middle';c.fillText('Frame '+(fi+1)+(f.skipped?' · skipped':'')+(f.role?' · '+f.role:''),x+margin,y+13,innerW);
      c.font='11px sans-serif';c.fillStyle='#f4cb60';const ticks=f.duration || 1,seconds=ticks/Q.clamp(doc.fps,1,30);c.fillText(ticks+' ticks · '+seconds.toFixed(2)+' s'+(f.group ? ' · '+f.group : ''),x+margin,y+plan.cellH-15,innerW);
    });return canvas;
  };
})();
