/* Bounded GIF87a/89a frame importer. Frames are flattened RGBA snapshots. */
(function () {
  'use strict';
  const Q=window.Q, MAX_FILE=10*1024*1024, MAX_FRAMES=60, MAX_PIXELS=2*1024*1024, MAX_DECODED=64*1024*1024;
  Q.GIF_IMPORT_MAX_BYTES=MAX_FILE;
  function bad(message){throw new Error(message);}
  function unpack(data,min,count) {
    if(min<2 || min>8)bad('Invalid GIF LZW code size');
    const clear=1<<min,end=clear+1,prefix=new Int16Array(4096),suffix=new Uint8Array(4096),stack=new Uint8Array(4097),out=new Uint8Array(count);
    let next=end+1,size=min+1,bit=0,old=-1,first=0,written=0,sawEnd=false,sawClear=false,codes=0;
    function code(){if(bit+size>data.length*8)bad('Truncated GIF image data');let n=0;for(let i=0;i<size;i++)n|=((data[(bit+i)>>3]>>((bit+i)&7))&1)<<i;bit+=size;return n;}
    while(bit+size<=data.length*8){
      if(++codes>count*4+8192)bad('GIF image has too many LZW codes');
      let k=code();
      if(k===clear){size=min+1;next=end+1;old=-1;sawClear=true;continue;}
      if(!sawClear)bad('GIF image has no LZW reset');
      if(k===end){sawEnd=true;break;}
      if(k>next || k>=4096 || (k===next && old<0))bad('Invalid GIF LZW code');
      const incoming=k;let n=0;
      if(k===next){stack[n++]=first;k=old;}
      while(k>=clear){if(k>=next || n>=4096)bad('Invalid GIF LZW dictionary');stack[n++]=suffix[k];k=prefix[k];}
      if(k>=clear)bad('Invalid GIF pixel');first=k;stack[n++]=first;
      if(written+n>count)bad('GIF contains too many pixels');
      while(n)out[written++]=stack[--n];
      if(old>=0 && next<4096){prefix[next]=old;suffix[next]=first;next++;if(next===(1<<size) && size<12)size++;}
      old=incoming;
    }
    if(!sawEnd || written!==count)bad('Incomplete GIF image data');
    return out;
  }
  Q.parseGif = function(bytes,fps) {
    if(!(bytes instanceof Uint8Array) || bytes.length>MAX_FILE || bytes.length<13)bad('GIF must be 10 MiB or smaller');
    if(!Number.isInteger(fps)||fps<1||fps>30)bad('Choose FPS from 1 to 30');
    let p=0;const need=n=>{if(p+n>bytes.length)bad('Truncated GIF');};
    const u8=()=>{need(1);return bytes[p++];}, u16=()=>{const a=u8(),b=u8();return a+(b<<8);};
    const str=n=>{need(n);let s='';for(let i=0;i<n;i++)s+=String.fromCharCode(bytes[p++]);return s;};
    const palette=n=>{need(n*3);const a=bytes.slice(p,p+n*3);p+=n*3;return a;};
    const subblocks=()=>{const parts=[];let total=0;for(;;){const n=u8();if(!n)break;need(n);parts.push(bytes.subarray(p,p+n));total+=n;p+=n;}const out=new Uint8Array(total);let o=0;for(const part of parts){out.set(part,o);o+=part.length;}return out;};
    const signature=str(6);if(signature!=='GIF87a' && signature!=='GIF89a')bad('Not a GIF87a/89a file');
    const width=u16(),height=u16(),packed=u8(),background=u8();u8();
    if(!width || !height || width>4096 || height>4096 || width*height>MAX_PIXELS)bad('GIF canvas exceeds the 2 megapixel limit');
    const global=(packed&128) ? palette(1<<((packed&7)+1)) : null,frames=[];
    let gce={delay:0,transparent:null,disposal:0},trailer=false,loopCount=null;
    while(p<bytes.length){const kind=u8();
      if(kind===0x3b){trailer=true;break;}
      if(kind===0x21){const label=u8();if(label===0xf9){if(u8()!==4)bad('Invalid GIF control block');const flags=u8(),delay=u16(),trans=u8();if(u8()!==0)bad('Invalid GIF control terminator');const disposal=(flags>>2)&7;if(disposal>3)bad('Unsupported GIF disposal method');gce={delay:delay,transparent:(flags&1)?trans:null,disposal:disposal};}
        else if(label===0x01)bad('GIF plain-text frames are not supported');
        else {const ext=subblocks();if(label===0xff && ext.length>=14){const id=String.fromCharCode.apply(null,ext.subarray(0,11));if((id==='NETSCAPE2.0' || id==='ANIMEXTS1.0') && ext[11]===1)loopCount=ext[12]+(ext[13]<<8);}}continue;}
      if(kind!==0x2c)bad('Invalid GIF block');
      const x=u16(),y=u16(),w=u16(),h=u16(),flags=u8();if(!w||!h||x+w>width||y+h>height)bad('GIF frame is outside its canvas');
      const colors=(flags&128) ? palette(1<<((flags&7)+1)) : global;if(!colors)bad('GIF frame has no colour table');
      if(gce.transparent!==null && gce.transparent>=colors.length/3)bad('Invalid GIF transparency index');
      const min=u8(),data=subblocks(),delay=gce.delay||10,hold=Math.max(1,Math.round(delay*fps/100));
      if(data.length>w*h*4+65536)bad('GIF frame data is unusually large');
      if(hold>60)bad('Frame delay exceeds 60 ticks; choose a lower FPS');
      frames.push({x,y,w,h,colors,min,data,interlaced:!!(flags&64),transparent:gce.transparent,disposal:gce.disposal,hold,delay});gce={delay:0,transparent:null,disposal:0};
      if(frames.length>MAX_FRAMES || frames.length*width*height*4>MAX_DECODED)bad('GIF exceeds 60 frames or 64 MiB of decoded frames');
    }
    if(!trailer || !frames.length)bad('GIF is incomplete or has no images');
    return {width,height,background,global,frames,fps,loopCount};
  };
  Q.decodeGifFrames = async function(gif,onFrame) {
    const w=gif.width,h=gif.height,frames=gif.frames,screen=new Uint8ClampedArray(w*h*4);
    function fillRect(f,color){for(let y=f.y;y<f.y+f.h;y++)for(let x=f.x;x<f.x+f.w;x++){const i=(y*w+x)*4;screen[i]=color[0];screen[i+1]=color[1];screen[i+2]=color[2];screen[i+3]=color[3];}}
    function background(f){if(f.transparent!==null || !gif.global || gif.background>=gif.global.length/3)return [0,0,0,0];const i=gif.background*3;return [gif.global[i],gif.global[i+1],gif.global[i+2],255];}
    fillRect({x:0,y:0,w,h},background(frames[0]));let previous=null;
    for(let fi=0;fi<frames.length;fi++){
      const f=frames[fi];if(previous){if(previous.frame.disposal===2)fillRect(previous.frame,background(previous.frame));else if(previous.frame.disposal===3)screen.set(previous.saved);}
      const saved=f.disposal===3 ? screen.slice() : null,indices=unpack(f.data,f.min,f.w*f.h),rows=[];
      if(f.interlaced){for(const [start,step] of [[0,8],[4,8],[2,4],[1,2]])for(let y=start;y<f.h;y+=step)rows.push(y);}else for(let y=0;y<f.h;y++)rows.push(y);
      for(let y=0;y<f.h;y++)for(let x=0;x<f.w;x++){const index=indices[y*f.w+x];if(index===f.transparent)continue;if(index>=f.colors.length/3)bad('GIF pixel exceeds its colour table');const a=((f.y+rows[y])*w+f.x+x)*4,b=index*3;screen[a]=f.colors[b];screen[a+1]=f.colors[b+1];screen[a+2]=f.colors[b+2];screen[a+3]=255;}
      await onFrame(screen,fi,f);previous={frame:f,saved};await new Promise(resolve=>setTimeout(resolve,0));
    }
  };
})();
