# Qelem 7.16-dev

A development build, **not an official public release**. The repository root remains the public Qelem 1.4 source.

## Brush library and paper textures

Qelem now has **71 built-in original presets**, including 43 new pencil, ink, calligraphy, paint, airbrush and texture variants. Use the Brush tray's search and category filters. Brush Studio adds tip roundness and fixed tip angle; duplicate a preset to save a custom profile. Existing custom profiles without tip settings load as round. Old preset IDs remain unchanged. The underlying brushes share Qelem's three simple stamping engines: preset names are descriptive, not reproductions of Procreate brushes. This is **not complete Procreate brush parity**, does not import Procreate brush files, and does not use Procreate or Canva proprietary assets. Fixed tip angle does not track stylus tilt or stroke direction.

Open **Actions → Add → Paper & canvas textures** for eight original procedural patterns. Choose colour, strength, scale and current frame or all frames. This creates a transparent raster texture layer at the top, initially using Multiply. It affects the full canvas regardless of the selection; all-frames mode makes separate cels. It is undoable, can be edited/hidden/changed like any layer, is saved in the project and appears in exports. It is an overlay, **not** realistic interaction between brush paint and canvas; colours and transparency may alter results, including over transparent artwork. The preview shows light paper, not the actual artwork. Limits: 8 megapixels and estimated 64 MiB for the new template and copied cels, plus existing artwork, history and device overhead. Large jobs may pause or fail on limited devices. No Canva-specific designs or assets are included.

## Animation colour effects

Open **Actions → Animation → Animation colour effects**, or open the timeline's Frames tools and choose **Animation colour effects**. Choose an inclusive frame range, one of ten colour effects, and start/end strengths. Four easing presets shape the strength ramp across frame numbers. You can include or exclude skipped frames and inspect an approximate before/after preview on any frame.

The effect changes the raw cels on the active layer, **not an editable adjustment layer**. Existing nonempty cels in the range are processed; blank cels remain blank, other layers and frame timing are untouched. The current hard selection applies to all processed cels. The supported colour effects preserve alpha and work with alpha lock; a locked or hidden layer is refused. The preview is downsampled and shows only the raw cel, without layer compositing, clipping or animation motion. The effect ramp is based on frame numbers, not frame holds. In a single-frame range the start strength is used.

Confirm before applying. Cels are prepared before committing so a failed allocation or changed target cancels without partial edits. One undo restores every changed cel. No-op cels do not create a history entry. A 4 MP affected-area limit and estimated 64 MiB **new-buffer** limit apply; original cels, undo history, canvas and device overhead need extra memory, so processing may pause or fail on constrained devices.

## Storyboard PNG export

Open **Actions → Export → Export storyboard**. Create a labelled visual contact sheet for an inclusive source-frame range, choosing the grid columns, tile size and whether to include skipped frames. The sheet prints frame numbers, hold ticks, approximate seconds and frame labels; a live low-resolution preview is provided. It is a static PNG for review, not an animation or a sprite atlas. It shows source frames in timeline order with the canvas background, ignoring playback range, layer/camera motion and pinned overlays. Static background/foreground-role frames are shown individually if in range. Limit 4096 pixels per side and 8 MP output; large or clipping-heavy documents may require significant extra memory and can pause or fail. PNG export uses the existing image path (`Pictures/Qalam` on Android 10+); verify the file on a device.

## Animation import studio

- In the gallery choose **Import GIF** to turn a GIF into editable animation cels. Frames are fully composited snapshots on one raster layer; GIFs do not contain recoverable source layers. GIF transparency, partial rectangles, local/global palettes, interlacing and disposal methods 0–3 are decoded. A missing loop extension becomes one-shot playback; a loop extension enables continuous looping. Finite repeat counts become continuous loops. Plain-text graphic blocks and reserved disposal methods are refused.
- Choose the project FPS (1–30). Each GIF delay rounds to the nearest tick, minimum one tick; a GIF zero delay is treated as 0.1 seconds. A delay longer than 60 ticks is rejected; choose a lower FPS to import it. Very short delays therefore may play more slowly. The canvas background defaults to white; transparent cel pixels remain transparent. GIF pixel-aspect metadata and GIF comments are not preserved.
- **Import sprite sheet** slices a PNG, JPEG or WebP grid left to right, top to bottom. Choose rows, columns, how many frames to use, FPS and ticks per frame. Tile dimensions must divide the sheet exactly; no margins, spacing or atlas metadata. Alpha is preserved. Animated image formats used as a sheet contribute only the decoded first image, not their animation.
- Both create a **new editable artwork**, with a gallery thumbnail, without overwriting existing art. Every frame can be edited normally; import itself is not an undo step because it creates a separate project. File type is checked from bytes for sprite sheets, even if a provider supplies a generic MIME type. Storage failures and ID collisions do not replace existing artwork.

Limits for each import: **10 MiB input**, **2 megapixel canvas/sheet**, max **4096 pixels per side**, **60 frames** and **64 MiB of decoded frame pixels**. Browser decoding, snapshots, the source image, PNG serialization, thumbnails and application overhead use additional memory; devices can pause or fail below these limits. GIFs with unusually large per-frame compressed data or excessive LZW codes are rejected to bound processing. File reads and initial browser image decode are not streamed and sprite-sheet size is checked after decoding. Import only trusted files. Android file pickers, provider compatibility, memory behavior and actual playback require physical-device testing.

## Editable project backup and restore

- **Export:** Open artwork → **Actions → Export project backup → Export project**. This uses the live document, including edits not yet autosaved. Android 10+ writes JSON to `Downloads/Qelem`; browser mode starts a download. Finish strokes and playback first.
- **Import:** In the gallery, tap **Import project → Choose project file**. A successful import creates a new artwork; it never replaces the original. It starts unfiled. The optional gallery preview is a static thumbnail of the active frame, without playback transforms; opening and saving refreshes it.
- **Checks:** File format/version, CRC32 checksum, project structure, metadata, cel PNG dimensions and actual image decoding are checked before one atomic insert. Corruption, duplicate cel coordinates, collisions and storage failures are rejected. CRC32 is an accidental-corruption check, **not authentication**: do not trust backups from unknown sources. Import only files you trust.

The JSON includes editable raster layers and animation cels, frame timing, background, layer properties, guides, layer/camera motion settings and the single embedded audio track. It excludes undo history, temporary selections, gallery collections and pins, palettes, custom brushes, reference images and global preferences. This is a Qelem-specific backup, **not PSD or Procreate interchange**. Audio playback and format support still depend on the device. Test restoration on a separate device before relying on a backup.

Limits: file at most **24 MiB**, at most **512 nonempty cels**, estimated decoded cel memory **128 MiB** (`width × height × 4 × nonempty cels`), and canvas sides at most 4096 px. Existing artwork, PNG compression, base64 strings, thumbnail compositing and device overhead require additional memory, so a smaller project may still pause or fail; the UI is not streamed. File picker contents are read into memory. Native backup export requires Android 10 / API 29 or later; Android 8–9 can still use the app but cannot export this format. Android picker/provider compatibility, written downloads, memory pressure, audio and touch have **not been tested on a physical device**. Desktop tests are not a substitute.

## Provenance and testing

7.16 builds on local 7.15 (APK SHA-256 `387e6db185110e18dd63927f472c7a923d6734cfaf8fefa12304d39f1cb1db60`). The original 7.1 development source archive was not preserved. 7.2 was reconstructed from the published 7.1 APK (SHA-256 `aec84370a66da9c9a1e6e25d2912c5c00047121557c96c8e8759d98eb8e02b3e`) using extracted web assets and apktool-decoded native code and resources. Android code is recovered smali, not original Java source. The inherited toolchain and tests came from 6.3 and were updated; they are not the unavailable full original 7.1 test suite.

Package and internal storage keys are unchanged; version code 77 is newer than 7.15-dev's 76. APKs use the same publicly available test signing key as earlier builds, **not a secure production key**. Back up artwork before installing or downgrading. Older builds may drop project metadata, Android normally blocks downgrades, and uninstalling can erase artwork. Previous image and movie export paths `Pictures/Qalam` and `Movies/Qalam` remain unchanged. See [feature status](FEATURE-STATUS.md) for major gaps.

## Build and test

```sh
bash tools/fetch-toolchain.sh
(cd tools/tests && npm test)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node brush_expansion_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node textures_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node animation_effects_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node storyboard_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node gif_import_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node sheet_import_browser.mjs)
(cd tools/tests && CHROMIUM_PATH=/path/to/chromium node project_backup_browser.mjs)
# Earlier browser suites: soft_edit, selection_border, orientation, resize,
# curves, assist, collections, exposure and ui_layout (each *_browser.mjs).
bash tools/build.sh
```

Build output: `artifacts/Qelem-7.16-dev.apk`. The bootstrap installs Node dependencies and the Android packaging toolchain. Apktool assembles the recovered smali directly; original Java source is unavailable.
